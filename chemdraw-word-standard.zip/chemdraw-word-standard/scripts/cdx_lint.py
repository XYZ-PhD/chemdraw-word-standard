"""Public CLI name. Reads CDXML only; binary CDX must be exported by ChemDraw first."""
import sys
from lint_cdxml import main

if __name__=='__main__':sys.exit(main())
