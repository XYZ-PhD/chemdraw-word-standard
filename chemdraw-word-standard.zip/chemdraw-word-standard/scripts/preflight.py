"""Check task storage and registered native applications without opening user documents."""
import argparse
import json
import os
from pathlib import Path
import platform
import shutil
import sys
from temp_probe import probe_temp_parent


def registered(progid):
    if os.name!='nt':return False
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT,progid+'\\CLSID') as key:
            return bool(winreg.QueryValueEx(key,None)[0])
    except OSError:return False


def inspect_environment(temp_parent=None):
    storage=probe_temp_parent(temp_parent)
    word=registered('Word.Application')
    chem=next((x for x in ['ChemDraw_x64.Application','ChemDraw.Application'] if registered(x)),None)
    return {'platform':platform.platform(),'python':platform.python_version(),'temporary_storage':str(storage),
            'temp_probe':'created_written_read_deleted','word_registered':word,'chemdraw_progid':chem,
            'powershell':shutil.which('powershell'),'pdftoppm':shutil.which('pdftoppm'),'libreoffice':shutil.which('soffice'),
            'delivery_capability':'word_and_native_candidate' if word and chem else 'native_candidate' if chem else 'cdxml_candidate',
            'boundary':'Registration is not an application/license/activation test. Candidate capabilities become verified only after actual save/reopen and applicable Word/PDF checks.'}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--temp-dir',type=Path);p.add_argument('--output',type=Path)
    a=p.parse_args()
    try:
        report=inspect_environment(a.temp_dir)
        payload=json.dumps(report,ensure_ascii=False,indent=2)
        if a.output:
            if a.output.exists():raise ValueError('Preflight output already exists; use a new report path')
            a.output.write_text(payload,encoding='utf-8')
        print(payload);return 0
    except (OSError,ValueError,RuntimeError) as e:
        print(json.dumps({'verification':'environment_unavailable','error':str(e)},ensure_ascii=False));return 2


if __name__=='__main__':sys.exit(main())
