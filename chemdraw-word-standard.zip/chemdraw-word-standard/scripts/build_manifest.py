"""Write manifest.sha256.json (schema 2) for a release directory. Maintenance use only.

Run after every file of the release is final. The manifest does not hash itself;
record the ZIP hash separately in the release evidence.
"""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
from verify_manifest import NORMALIZATION, digest, release_files, verify


def build(root, baseline_backup_sha256=None):
    root = Path(root).resolve()
    version = (root / 'VERSION').read_text(encoding='utf-8').strip()
    if not version:
        raise ValueError('VERSION is empty')
    manifest = {'schema_version': 2, 'version': version,
                'created_utc': datetime.now(timezone.utc).isoformat(),
                'algorithm': 'SHA-256', 'normalization': NORMALIZATION,
                'files': {rel: digest(root / rel, rel, 2) for rel in release_files(root)}}
    if baseline_backup_sha256:
        manifest['baseline_backup_sha256'] = baseline_backup_sha256
    (root / 'manifest.sha256.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return verify(root)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('skill_directory', type=Path)
    p.add_argument('--baseline-backup-sha256', help='SHA-256 of the backed-up installed package this release started from')
    a = p.parse_args()
    try:
        r = build(a.skill_directory, a.baseline_backup_sha256)
        print(json.dumps(r, ensure_ascii=False, indent=2))
        return 0 if r['verification'] == 'passed' else 1
    except (OSError, ValueError) as e:
        print(json.dumps({'verification': 'invalid_input', 'error': str(e)}, ensure_ascii=False))
        return 2


if __name__ == '__main__':
    sys.exit(main())
