"""Read-only verification of a complete skill release, including unlisted files."""
import argparse
import hashlib
import json
from pathlib import Path
import sys


def verify(root):
    root=Path(root).resolve()
    m=json.loads((root/'manifest.sha256.json').read_text(encoding='utf-8'))
    if m.get('schema_version')!=1 or not isinstance(m.get('files'),dict):raise ValueError('Invalid manifest schema')
    if m.get('version')!=(root/'VERSION').read_text(encoding='utf-8').strip():raise ValueError('Version mismatch')
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and p!=root/'manifest.sha256.json'}
    expected=set(m['files'])
    problems=[]
    if actual!=expected:problems.append({'file_set_mismatch':{'missing':sorted(expected-actual),'unlisted':sorted(actual-expected)}})
    for rel,wanted in m['files'].items():
        path=(root/rel).resolve()
        if not path.is_relative_to(root):raise ValueError('Manifest path escapes the skill directory')
        if path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest()!=wanted:problems.append({'hash_mismatch':rel})
    return {'version':m['version'],'files_checked':len(expected),'verification':'failed' if problems else 'passed','problems':problems,
            'boundary':'Integrity relative to this manifest only. The manifest itself is authenticated by the separately recorded package hash.'}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('skill_directory',type=Path);a=p.parse_args()
    try:
        r=verify(a.skill_directory);print(json.dumps(r,ensure_ascii=False,indent=2));return 1 if r['problems'] else 0
    except (OSError,ValueError,TypeError,KeyError) as e:
        print(json.dumps({'verification':'invalid_input','error':str(e)},ensure_ascii=False));return 2


if __name__=='__main__':sys.exit(main())
