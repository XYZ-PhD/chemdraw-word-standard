"""Read-only verification of a complete skill release, including unlisted files.

Schema 2 hashes documentation files (.md, .yaml, .yml, .txt and VERSION) after
normalizing CRLF/CR line endings to LF, because skill sync tools may rewrite the
line endings of SKILL.md. Every other file, including CDXML/CDX, JSON and
scripts, is hashed as raw bytes: CDXML role files bind to exact source bytes.
Schema 1 manifests (raw bytes for every file) are still verified as before.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

NORMALIZED_SUFFIXES = {'.md', '.yaml', '.yml', '.txt'}
NORMALIZED_NAMES = {'VERSION'}
NORMALIZATION = ('Line endings CRLF/CR -> LF before SHA-256 for .md/.yaml/.yml/.txt and VERSION; '
                 'all other files are hashed as raw bytes.')


def normalized(rel):
    path = Path(rel)
    return path.suffix.lower() in NORMALIZED_SUFFIXES or path.name in NORMALIZED_NAMES


def digest(path, rel, schema):
    data = Path(path).read_bytes()
    if schema >= 2 and normalized(rel):
        data = re.sub(rb'\r\n|\r', b'\n', data)
    return hashlib.sha256(data).hexdigest()


def release_files(root):
    root = Path(root).resolve()
    return sorted(p.relative_to(root).as_posix() for p in root.rglob('*')
                  if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'
                  and p != root / 'manifest.sha256.json')


def verify(root):
    root=Path(root).resolve()
    m=json.loads((root/'manifest.sha256.json').read_text(encoding='utf-8'))
    schema=m.get('schema_version')
    if schema not in (1,2) or not isinstance(m.get('files'),dict):raise ValueError('Invalid manifest schema')
    if m.get('version')!=(root/'VERSION').read_text(encoding='utf-8').strip():raise ValueError('Version mismatch')
    actual=set(release_files(root))
    expected=set(m['files'])
    problems=[]
    if actual!=expected:problems.append({'file_set_mismatch':{'missing':sorted(expected-actual),'unlisted':sorted(actual-expected)}})
    for rel,wanted in m['files'].items():
        path=(root/rel).resolve()
        if not path.is_relative_to(root):raise ValueError('Manifest path escapes the skill directory')
        if path.is_file() and digest(path,rel,schema)!=wanted:problems.append({'hash_mismatch':rel})
    return {'version':m['version'],'schema_version':schema,'files_checked':len(expected),
            'verification':'failed' if problems else 'passed','problems':problems,
            'normalization':NORMALIZATION if schema>=2 else 'raw bytes for every file',
            'boundary':'Integrity relative to this manifest only. The manifest itself is authenticated by the separately recorded package hash.'}


def main():
    p=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('skill_directory',type=Path);a=p.parse_args()
    try:
        r=verify(a.skill_directory);print(json.dumps(r,ensure_ascii=False,indent=2));return 1 if r['problems'] else 0
    except (OSError,ValueError,TypeError,KeyError) as e:
        print(json.dumps({'verification':'invalid_input','error':str(e)},ensure_ascii=False));return 2


if __name__=='__main__':sys.exit(main())
