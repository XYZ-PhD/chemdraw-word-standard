import hashlib,json
from pathlib import Path
import tempfile
import unittest
from temp_probe import probe_temp_parent
from verify_manifest import verify
from build_manifest import build


class ManifestTests(unittest.TestCase):
    def test_modified_and_unlisted_files_are_both_detected(self):
        with tempfile.TemporaryDirectory(dir=probe_temp_parent()) as folder:
            root=Path(folder);(root/'VERSION').write_text('2.0.0',encoding='utf-8');(root/'asset').write_bytes(b'correct')
            files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.iterdir()}
            (root/'manifest.sha256.json').write_text(json.dumps({'schema_version':1,'version':'2.0.0','files':files}),encoding='utf-8')
            self.assertEqual(verify(root)['verification'],'passed')
            (root/'asset').write_bytes(b'changed');(root/'extra').write_bytes(b'unlisted')
            r=verify(root);self.assertEqual(r['verification'],'failed');self.assertEqual(len(r['problems']),2)

    def test_manifest_cannot_reference_an_external_path(self):
        with tempfile.TemporaryDirectory(dir=probe_temp_parent()) as folder:
            root=Path(folder);(root/'VERSION').write_text('2.0.0',encoding='utf-8')
            (root/'manifest.sha256.json').write_text(json.dumps({'schema_version':1,'version':'2.0.0','files':{'../external':'hash'}}),encoding='utf-8')
            with self.assertRaises(ValueError):verify(root)

    def test_schema2_tolerates_doc_line_endings_but_not_cdxml_bytes(self):
        with tempfile.TemporaryDirectory(dir=probe_temp_parent()) as folder:
            root=Path(folder);(root/'VERSION').write_text('2.1.0',encoding='utf-8')
            (root/'SKILL.md').write_bytes(b'---\r\nname: x\r\n---\r\nbody\r\n')
            (root/'a.cdxml').write_bytes(b'<CDXML>\r\n</CDXML>\r\n')
            self.assertEqual(build(root)['verification'],'passed')
            # A sync tool rewriting SKILL.md line endings must not look like tampering.
            (root/'SKILL.md').write_bytes(b'---\nname: x\n---\r\nbody\r\n')
            self.assertEqual(verify(root)['verification'],'passed')
            # Content changes in docs and line-ending changes in CDXML are both detected.
            (root/'SKILL.md').write_bytes(b'---\nname: y\n---\nbody\n')
            (root/'a.cdxml').write_bytes(b'<CDXML>\n</CDXML>\n')
            r=verify(root);self.assertEqual(r['verification'],'failed')
            self.assertEqual(sorted(x['hash_mismatch'] for x in r['problems']),['SKILL.md','a.cdxml'])


if __name__=='__main__':unittest.main(verbosity=2)
