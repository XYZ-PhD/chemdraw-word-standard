import hashlib,json
from pathlib import Path
import tempfile
import unittest
from temp_probe import probe_temp_parent
from verify_manifest import verify


class ManifestTests(unittest.TestCase):
    def test_modified_and_unlisted_files_are_both_detected(self):
        with tempfile.TemporaryDirectory(dir=probe_temp_parent()) as folder:
            root=Path(folder);(root/'VERSION').write_text('2.0.0',encoding='utf-8');(root/'asset').write_bytes(b'correct')
            files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.iterdir()}
            (root/'manifest.sha256.json').write_text(json.dumps({'schema_version':1,'version':'2.0.0','files':files}),encoding='utf-8')
            self.assertEqual(verify(root)['verification'],'passed')
            (root/'asset').write_bytes(b'changed');(root/'extra').write_bytes(b'unlisted')
            r=verify(root);self.assertEqual(r['verification'],'failed');self.assertEqual(len(r['problems']),2)

    def test_manifest_cannot_reference_an_external_path(self):
        with tempfile.TemporaryDirectory(dir=probe_temp_parent()) as folder:
            root=Path(folder);(root/'VERSION').write_text('2.0.0',encoding='utf-8')
            (root/'manifest.sha256.json').write_text(json.dumps({'schema_version':1,'version':'2.0.0','files':{'../external':'hash'}}),encoding='utf-8')
            with self.assertRaises(ValueError):verify(root)


if __name__=='__main__':unittest.main(verbosity=2)
