import subprocess
import sys
import unittest
from unittest.mock import patch
from run_native import execute


class LauncherTests(unittest.TestCase):
    def test_successful_child_output_and_exit_code(self):
        r=execute([sys.executable,'-B','-c','print("native stub")'],5)
        self.assertEqual(r['exit_code'],0);self.assertIn('native stub',r['stdout'])

    def test_child_failure_is_not_hidden(self):
        r=execute([sys.executable,'-B','-c','raise SystemExit(7)'],5)
        self.assertEqual(r['exit_code'],7);self.assertEqual(r['runner_status'],'failed')

    def test_timeout_does_not_claim_apps_were_closed(self):
        with patch('run_native.subprocess.run',side_effect=subprocess.TimeoutExpired(['stub'],1,output=b'last stage')):
            r=execute(['stub'],1)
        self.assertEqual(r['runner_status'],'timeout');self.assertIn('NOT terminated',r['boundary'])

    def test_invalid_timeout_rejected_before_launch(self):
        with self.assertRaises(ValueError):execute(['not-run'],0)


if __name__=='__main__':unittest.main(verbosity=2)
