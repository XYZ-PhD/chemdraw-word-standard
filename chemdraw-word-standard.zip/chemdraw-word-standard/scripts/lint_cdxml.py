"""Read-only, rule-by-rule CDXML lint. Does not validate Word/OLE/PDF or all chemistry."""
import argparse
import json
import math
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET
from cdxml_model import Drawing, element_number, label_text, native_me, order, safe_report, summarize


def item(key,status,reason,**values):
    return dict(object_id=key,status=status,reason=reason,**values)


def number_format(drawing,text,key):
    raw=label_text(text)
    match=re.fullmatch(r'([0-9][A-Za-z0-9]*|[A-Za-z]+[0-9]+)(?:, ([0-9]+(?:\.[0-9]+)?%))?',raw)
    if not match:
        if re.fullmatch(r'([0-9][A-Za-z0-9]*|[A-Za-z]+[0-9]+), \S.*\S',raw) and '%' in raw:
            return item(key,'pending','Yield qualifiers or other unsupported notation must be preserved and reviewed',text=raw)
        return item(key,'failed','Expected number only, or number + comma + one ASCII space + yield; qualifiers require a declared reviewed format',text=raw)
    runs=drawing.runs(text)
    chars=[(c,r) for r in runs for c in r['text']]
    end=len(match.group(1))+(1 if match.group(2) else 0)
    if len(chars)!=len(raw): return item(key,'pending','Unsupported text representation')
    for i,(c,r) in enumerate(chars):
        if not c.isspace() and (r['font']!='Arial' or r['size'] is None or not math.isfinite(r['size']) or abs(r['size']-10)>0.01):
            return item(key,'failed','Number/yield font or size differs from Arial 10 pt',text=raw)
        if i<end and (not r['face']&1 or r['color']!=(0.0,0.0,0.0)):
            return item(key,'failed','Number and comma must be bold black',text=raw)
        if i>end and r['face']&1:
            return item(key,'failed','Yield must use regular weight',text=raw)
    return item(key,'passed','Declared compound label format verified',text=raw)


def lint(drawing,roles=None,bond_length=14.4,bond_tolerance=0.15):
    if not all(math.isfinite(x) and x>0 for x in (bond_length,bond_tolerance)):
        raise ValueError('Bond target and tolerance must be positive finite numbers')
    roles=roles or {}
    if not isinstance(roles,dict): raise ValueError('Roles must be an object')
    for field in ('number_ids','ordinary_text_ids','test_label_ids'):
        value=roles.get(field,[])
        if not isinstance(value,list) or any(not isinstance(x,str) for x in value) or len(set(value))!=len(value):
            raise ValueError(field+' must be a list of distinct string IDs')
    number_ids=set(roles.get('number_ids',[])); ordinary=set(roles.get('ordinary_text_ids',[]))|number_ids
    excluded=roles.get('excluded_fragments',{})
    if not isinstance(excluded,dict) or any(not isinstance(v,str) or not v.strip() for v in excluded.values()):
        raise ValueError('Excluded fragments require explicit review reasons')
    if set(excluded)-set(drawing.fragments): raise ValueError('Unknown excluded fragment')
    for key in ordinary|set(roles.get('test_label_ids',[])):
        if key not in drawing.objects or drawing.objects[key].tag!='t': raise ValueError('Unknown standalone text ID: '+str(key))
        parent=drawing.parents.get(drawing.objects[key])
        if parent is not None and parent.tag=='n':raise ValueError('Atom labels cannot be declared standalone captions: '+key)
    lengths=[]; fonts=[]; methyl=[]; numbering=[]
    for pair,b in drawing.bonds.items():
        a,z=tuple(pair); fid=drawing.nodes[a]['fragment']; key=b.get('id') or a+'-'+z
        if element_number(drawing.nodes[a]['node'])!=6 or element_number(drawing.nodes[z]['node'])!=6: continue
        reason=excluded.get(fid) or drawing.special_fragment(fid)
        if reason:
            lengths.append(item(key,'pending',reason));continue
        if any('Wedge' in x.get('Display','') for x in drawing.fragments[fid].findall('b')):
            lengths.append(item(key,'pending','Stereochemical fragment requires length/projection review'));continue
        length=math.dist(drawing.nodes[a]['point'],drawing.nodes[z]['point'])
        lengths.append(item(key,'passed' if abs(length-bond_length)<=bond_tolerance else 'failed',
                            'Ordinary visible C-C center distance',actual_pt=length,target_pt=bond_length,tolerance_pt=bond_tolerance))
    for key,t,atom in drawing.texts:
        if not atom:
            if key in number_ids: numbering.append(number_format(drawing,t,key))
            elif key not in ordinary and key not in roles.get('test_label_ids',[]) and re.match(r'^[A-Za-z]*\d',label_text(t)):
                numbering.append(item(key,'pending','Numeric-looking caption requires compound-number role confirmation',text=label_text(t)))
        if not atom and key not in ordinary and key not in roles.get('test_label_ids',[]):
            fonts.append(item(key,'pending','Standalone caption role is not declared'));continue
        for index,r in enumerate(drawing.runs(t,atom)):
            if not r['text'].strip(): continue
            auto=(r['face']&96) in (32,64)
            size=r['size']
            if r['font'] is None or size is None:
                status,why='pending','Unresolved font table or inherited size'
            elif not math.isfinite(size) or size<=0 or r['font']!='Arial':
                status,why='failed','Invalid size or non-Arial font'
            elif (auto and size<=10.01) or abs(size-10)<=0.01:
                status,why='passed','Chemical superscript/subscript exception' if auto else 'Arial 10 pt actual text run'
            else:
                status,why='failed','Actual text run differs from the baseline'
            fonts.append(item(key,status,why,run=index,text=r['text'],font=r['font'],size_pt=size))
    for key,data in drawing.nodes.items():
        n=data['node']; text=n.find('t'); raw=label_text(text) if text is not None else ''
        ns=drawing.adjacency[key]
        if raw=='Me':
            valid=native_me(n) and len(ns)==1 and order(drawing.bonds[frozenset((key,ns[0]))])==1
            methyl.append(item(key,'passed' if valid else 'failed','Native CH3 nickname graph' if valid else 'Me label lacks a valid native CH3 attachment'));continue
        if re.fullmatch(r'C[DT]3',raw):
            methyl.append(item(key,'pending','Isotopic hydrogen encoding requires native semantic review; do not replace with Me'));continue
        if n.get('NodeType','Element')!='Element':
            methyl.append(item(key,'pending','Other nickname/query requires semantic review'));continue
        if element_number(n)!=6 or len(ns)!=1: continue
        bond=drawing.bonds[frozenset((key,ns[0]))]
        if order(bond)!=1: continue  # Alkene/alkyne/nitrile carbon is not methyl.
        if n.get('Isotope','0')!='0' or n.get('Charge','0')!='0' or n.get('Radical','0')!='0':
            methyl.append(item(key,'not_applicable','Isotope/charge/radical carbon must retain its identity'));continue
        other=drawing.nodes[ns[0]]['node']
        if element_number(other) not in (6,7,8,9,14,15,16,17,35,53):
            methyl.append(item(key,'pending','Terminal carbon in unsupported chemical environment'));continue
        if n.get('NumHydrogens','3')!='3':
            methyl.append(item(key,'pending','Terminal carbon hydrogen count is not ordinary CH3'));continue
        methyl.append(item(key,'failed','Ordinary terminal CH3 must be shown as native Me'))
    return {'bond_lengths':summarize(lengths),'text_styles':summarize(fonts),
            'methyl_representation':summarize(methyl),'number_formats':summarize(numbering)}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('cdxml',type=Path);p.add_argument('--roles',type=Path);p.add_argument('--output',type=Path)
    p.add_argument('--bond-length',type=float,default=14.4);p.add_argument('--bond-tolerance',type=float,default=0.15)
    a=p.parse_args()
    try:
        drawing,sha=Drawing.read(a.cdxml)
        roles=json.loads(a.roles.read_text(encoding='utf-8-sig')) if a.roles else {}
        if a.roles and (not isinstance(roles,dict) or roles.get('source_sha256')!=sha):
            raise ValueError('Roles must be an object bound to this exact CDXML source_sha256')
        checks=lint(drawing,roles,a.bond_length,a.bond_tolerance)
        report={'schema_version':1,'source_sha256':sha,'checks':checks,
                'boundary':'Rule-specific CDXML evidence only; no whole-document, Word cache, OLE, PDF or complete chemical correctness conclusion.'}
        safe_report(report,a.output,[a.cdxml]+([a.roles] if a.roles else []))
        return 1 if any(c['status']=='failed' for c in checks.values()) else 3 if any(c['status']=='pending' for c in checks.values()) else 0
    except (OSError,ValueError,TypeError,KeyError,ET.ParseError) as e:
        print(json.dumps({'verification':'invalid_input','error':str(e)},ensure_ascii=False));return 2


if __name__=='__main__':sys.exit(main())
