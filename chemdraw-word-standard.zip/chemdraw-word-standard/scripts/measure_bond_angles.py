#!/usr/bin/env python3
"""Read-only CDXML angle measurements and source-bound coverage audits."""
import argparse
import hashlib
import itertools
import json
import math
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


def visible_fragments(element):
    if element.tag == 'n':
        return  # Exclude hidden nickname expansion fragments.
    if element.tag == 'fragment':
        yield element
    for child in element:
        yield from visible_fragments(child)


def number(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(name + ' must be a finite number')
    return float(value)


def angle_options(expected, tolerance):
    tolerance = number(tolerance, 'Tolerance')
    if tolerance < 0:
        raise ValueError('Tolerance must be nonnegative')
    if expected is not None:
        expected = number(expected, 'Expected angle')
        if not 0 < expected <= 180:
            raise ValueError('Expected minor angle must be in (0, 180] degrees')
    return expected, tolerance


def graph(root, scope=None):
    fragments = list(visible_fragments(root))
    ids = [f.get('id') for f in fragments]
    if any(not i or i == '0' for i in ids) or len(set(ids)) != len(ids):
        raise ValueError('Visible fragment IDs must be unique and nonzero')
    if scope is None:
        scope = ids
    if not isinstance(scope, list) or any(not isinstance(i, str) for i in scope):
        raise ValueError('scope_fragments must be a list of fragment ID strings')
    if not scope or len(set(scope)) != len(scope) or set(scope) - set(ids):
        raise ValueError('Empty, duplicate or unknown fragment scope')
    nodes, adjacency = {}, {}
    for fragment in fragments:
        fid = fragment.get('id')
        if fid not in scope:
            continue
        local = {}
        for node in fragment.findall('n'):
            key = node.get('id')
            if not key or key == '0' or key in nodes:
                raise ValueError('Missing, zero or duplicate visible atom ID: ' + str(key))
            parts = node.get('p', '').split()
            if len(parts) != 2:
                raise ValueError('Missing or invalid 2D coordinates at atom ' + key)
            point = tuple(float(v) for v in parts)
            if not all(math.isfinite(v) for v in point):
                raise ValueError('Nonfinite coordinates at atom ' + key)
            local[key] = node
            nodes[key] = {'node': node, 'point': point, 'fragment': fid}
            adjacency[key] = []
        seen = set()
        for bond in fragment.findall('b'):
            a, b = bond.get('B'), bond.get('E')
            if a not in local or b not in local or a == b:
                raise ValueError('Invalid bond endpoints in fragment ' + fid)
            pair = frozenset((a, b))
            if pair in seen:
                raise ValueError('Duplicate bonded atom pair in fragment ' + fid)
            seen.add(pair)
            pa, pb = nodes[a]['point'], nodes[b]['point']
            length = math.hypot(pb[0]-pa[0], pb[1]-pa[1])
            if not math.isfinite(length) or length == 0:
                raise ValueError('Zero or nonfinite bond length: ' + a + '-' + b)
            adjacency[a].append(b)
            adjacency[b].append(a)
    return nodes, adjacency, scope


def measure_center(nodes, adjacency, center, expected=None, tolerance=1.0):
    expected, tolerance = angle_options(expected, tolerance)
    if center not in nodes:
        raise ValueError('Visible atom ID not found in scope: ' + str(center))
    targets = adjacency[center]
    if len(targets) < 2:
        raise ValueError('At least two bonded neighbors are needed: ' + center)
    if expected is not None and len(targets) not in (2, 3):
        raise ValueError('A common expected angle supports two- or three-neighbor centers only')
    x, y = nodes[center]['point']
    neighbors = []
    for other in targets:
        ox, oy = nodes[other]['point']
        vector = (ox-x, oy-y)
        neighbors.append({'id': other, 'vector': vector, 'bond_length_pt': math.hypot(*vector)})
    angles = []
    for a, b in itertools.combinations(neighbors, 2):
        # Separate normalization avoids overflowing/underflowing a product of lengths.
        ax, ay = (v/a['bond_length_pt'] for v in a['vector'])
        bx, by = (v/b['bond_length_pt'] for v in b['vector'])
        value = math.degrees(math.atan2(abs(ax*by-ay*bx), ax*bx+ay*by))
        if not math.isfinite(value):
            raise ValueError('Angle could not be calculated at atom ' + center)
        angles.append({'neighbors': [a['id'], b['id']], 'angle_deg': value})
    angles.sort(key=lambda a: a['angle_deg'])
    item = {'center': center, 'fragment': nodes[center]['fragment'], 'neighbors': neighbors, 'angles': angles}
    if expected is not None:
        item.update(expected_angle_deg=expected, tolerance_deg=tolerance,
                    within_tolerance=all(abs(a['angle_deg']-expected) <= tolerance for a in angles))
    return item


def measure(root, centers, expected=None, tolerance=1.0):
    """Compatibility API for explicitly selected geometry and centers."""
    nodes, adjacency, _ = graph(root)
    if not centers or len(set(centers)) != len(centers):
        raise ValueError('Select distinct, nonempty center IDs')
    return [measure_center(nodes, adjacency, c, expected, tolerance) for c in centers]


def inventory(root, source_hash, scope=None):
    nodes, adjacency, scope = graph(root, scope)
    candidates = [key for key in nodes if len(adjacency[key]) >= 2]
    return {'schema_version': 1, 'source_sha256': source_hash, 'scope_fragments': scope,
            'verification': 'inventory_only',
            'candidate_context': {key: {'fragment': nodes[key]['fragment'],
                'element': nodes[key]['node'].get('Element', '6'),
                'node_type': nodes[key]['node'].get('NodeType', 'Element'),
                'neighbors': adjacency[key]} for key in candidates},
            'entries': {key: {'method': 'pending'} for key in candidates},
            'non_angle_atoms': [key for key in nodes if len(adjacency[key]) < 2]}


def audit_plan(root, source_hash, plan):
    if plan.get('schema_version') != 1 or plan.get('source_sha256') != source_hash:
        raise ValueError('Plan schema or source hash mismatch; regenerate the inventory')
    if 'scope_fragments' not in plan:
        raise ValueError('Plan must explicitly state scope_fragments')
    inv = inventory(root, source_hash, plan['scope_fragments'])
    entries = plan.get('entries')
    if not isinstance(entries, dict) or set(entries) - set(inv['entries']):
        raise ValueError('Plan entries must name candidate centers in the stated scope')
    nodes, adjacency, _ = graph(root, plan['scope_fragments'])
    records = []
    for key in inv['entries']:
        entry = entries.get(key, {'method': 'pending'})
        if not isinstance(entry, dict):
            raise ValueError('Invalid plan entry at atom ' + key)
        method = entry.get('method')
        if method == 'angle':
            if entry.get('expected_angle_deg') is None:
                raise ValueError('Angle entry needs an expected angle: ' + key)
            result = measure_center(nodes, adjacency, key, entry['expected_angle_deg'], entry.get('tolerance_deg', 1.0))
            result.update(method='angle', status='passed' if result['within_tolerance'] else 'failed')
        elif method == 'manual':
            if entry.get('status') not in ('passed', 'failed', 'pending'):
                raise ValueError('Manual entry needs passed, failed or pending status: ' + key)
            reason, evidence = entry.get('reason'), entry.get('evidence')
            if not isinstance(reason, str) or not reason.strip():
                raise ValueError('Manual review requires a reason: ' + key)
            if entry['status'] != 'pending' and (not isinstance(evidence, str) or not evidence.strip()):
                raise ValueError('Completed manual review requires evidence: ' + key)
            result = {'center': key, 'method': method, 'status': entry['status'], 'reason': reason, 'evidence': evidence}
        elif method == 'pending':
            result = {'center': key, 'method': method, 'status': 'pending'}
        else:
            raise ValueError('Unknown review method at atom ' + key)
        records.append(result)
    counts = {s: sum(r['status'] == s for r in records) for s in ('passed', 'failed', 'pending')}
    outcome = ('no_angle_centers' if not records else 'failed' if counts['failed'] else
               'incomplete' if counts['pending'] else 'passed_in_scope')
    return {'source_sha256': source_hash, 'scope_fragments': inv['scope_fragments'], 'verification': outcome,
            'coverage': {'candidate_centers': len(records), **counts,
                'manual_reviews': sum(r['method'] == 'manual' for r in records),
                'pending_centers': [r['center'] for r in records if r['status'] == 'pending'],
                'non_angle_atoms': inv['non_angle_atoms']}, 'centers': records,
            'boundary': 'Angle coverage in the stated fragments only. Manual reviews are supplied evidence, not automatic chemical validation.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('cdxml', type=Path)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument('--centers', nargs='+', help='Measure only these explicitly selected atom IDs')
    modes.add_argument('--inventory', action='store_true', help='Create an unresolved, source-bound review plan')
    modes.add_argument('--plan', type=Path, help='Audit coverage using a completed inventory JSON')
    parser.add_argument('--fragments', nargs='+', help='Explicit fragment scope for inventory or selected measurements')
    parser.add_argument('--expected-angle', type=float)
    parser.add_argument('--tolerance', type=float, default=1.0)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    try:
        angle_options(args.expected_angle, args.tolerance)
        if args.expected_angle is not None and not args.centers:
            raise ValueError('--expected-angle applies only to --centers; plans set angles per entry')
        if args.plan and args.fragments:
            raise ValueError('Plan already specifies its fragment scope')
        if args.output and any(args.output.resolve() == p.resolve() or
                (args.output.exists() and p.exists() and args.output.samefile(p))
                for p in [args.cdxml] + ([args.plan] if args.plan else [])):
            raise ValueError('Output must not replace the input or review plan')
        data = args.cdxml.read_bytes()
        source_hash = hashlib.sha256(data).hexdigest()
        root = ET.fromstring(data)
        if root.tag != 'CDXML':
            raise ValueError('Expected a CDXML document')
        if args.inventory:
            report = inventory(root, source_hash, args.fragments)
        elif args.plan:
            plan = json.loads(args.plan.read_text(encoding='utf-8-sig'))
            if not isinstance(plan, dict):
                raise ValueError('Plan must be a JSON object')
            report = audit_plan(root, source_hash, plan)
        else:
            nodes, adjacency, scope = graph(root, args.fragments)
            if len(set(args.centers)) != len(args.centers):
                raise ValueError('Duplicate selected center IDs')
            records = [measure_center(nodes, adjacency, c, args.expected_angle, args.tolerance) for c in args.centers]
            candidates = {key for key in nodes if len(adjacency[key]) >= 2}
            report = {'source_sha256': source_hash, 'scope_fragments': scope, 'centers': records,
                'verification': 'measured_only' if args.expected_angle is None else
                    ('selected_centers_passed' if all(r['within_tolerance'] for r in records) else 'failed'),
                'coverage': {'selected_centers': args.centers, 'unselected_centers': sorted(candidates-set(args.centers))},
                'boundary': 'Selected-center result only; use --inventory and --plan for coverage validation.'}
        report['source'] = str(args.cdxml.resolve())
        payload = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)
        if args.output:
            args.output.write_text(payload, encoding='utf-8')
        print(payload)
        return 1 if report['verification'] == 'failed' else 3 if report['verification'] == 'incomplete' else 0
    except (ValueError, TypeError, KeyError, OSError, ET.ParseError) as error:
        print(json.dumps({'verification': 'invalid_input', 'error': str(error)}, ensure_ascii=False))
        return 2


if __name__ == '__main__':
    sys.exit(main())
