"""Read-only DOCX OLE/cache inventory; presence does not prove native editability."""
import argparse
import hashlib
import json
import posixpath
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import zipfile
from cdxml_model import safe_report

NS={'o':'urn:schemas-microsoft-com:office:office','v':'urn:schemas-microsoft-com:vml',
    'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
    'p':'http://schemas.openxmlformats.org/package/2006/relationships'}


def inspect(path):
    objects=[]
    with zipfile.ZipFile(path) as z:
        names=set(z.namelist())
        for name in sorted(names):
            if not name.startswith('word/') or not name.endswith('.xml') or '/_rels/' in name:continue
            root=ET.fromstring(z.read(name))
            oles=root.findall('.//o:OLEObject',NS)
            if not oles:continue
            relpath=posixpath.join(posixpath.dirname(name),'_rels',posixpath.basename(name)+'.rels')
            rels={r.get('Id'):r.attrib for r in ET.fromstring(z.read(relpath))} if relpath in names else {}
            shapes={s.get('id'):s for s in root.findall('.//v:shape',NS)}
            for ole in oles:
                item={'part':name,'shape_id':ole.get('ShapeID'),'prog_id':ole.get('ProgID'),'type':ole.get('Type')}
                def resource(rid):
                    rel=rels.get(rid,{})
                    if rel.get('TargetMode')=='External':return {'external':True,'status':'failed'}
                    target=rel.get('Target','')
                    member=posixpath.normpath(target.lstrip('/') if target.startswith('/') else posixpath.join(posixpath.dirname(name),target))
                    if member not in names:return {'status':'failed','reason':'missing internal relationship target'}
                    data=z.read(member)
                    return {'member':member,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'status':'passed' if data else 'failed'}
                item['embedded_storage']=resource(ole.get('{'+NS['r']+'}id'))
                shape=shapes.get(ole.get('ShapeID'))
                image=shape.find('v:imagedata',NS) if shape is not None else None
                item['cache']=resource(image.get('{'+NS['r']+'}id')) if image is not None else {'status':'pending','reason':'No supported VML cache association'}
                item['presence_status']='failed' if item['type']!='Embed' or item['embedded_storage']['status']=='failed' or item['cache']['status']=='failed' else 'pending' if item['cache']['status']=='pending' else 'passed'
                objects.append(item)
    return {'docx_sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),'objects':objects,'object_count':len(objects),
            'boundary':'Package presence and hashes only; embedded payloads, cache semantics, activation and PDF/page rendering are not validated.'}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('docx',type=Path);p.add_argument('--output',type=Path);a=p.parse_args()
    try:
        report=inspect(a.docx);safe_report(report,a.output,[a.docx])
        return 1 if any(o['presence_status']=='failed' for o in report['objects']) else 3 if not report['objects'] or any(o['presence_status']=='pending' for o in report['objects']) else 0
    except (OSError,ValueError,KeyError,ET.ParseError,zipfile.BadZipFile) as e:
        print(json.dumps({'verification':'invalid_input','error':str(e)},ensure_ascii=False));return 2


if __name__=='__main__':sys.exit(main())
