"""Read-only physical-size comparison. Never substitutes for native/cache/page verification."""
import argparse
import json
import math
from pathlib import Path
import sys
from cdxml_model import safe_report,summarize


def compare_sizes(inserted,reopened,absolute_pt=0.2,relative=0.002):
    for name,x in [('absolute_pt',absolute_pt),('relative',relative)]:
        if isinstance(x,bool) or not isinstance(x,(float,int)) or not math.isfinite(x) or x<0:
            raise ValueError(name+' must be a finite nonnegative number')
    records=[]
    original={str(x['Figure']):x for x in inserted}
    current={str(x['Figure']):x for x in reopened}
    if len(original)!=len(inserted) or len(current)!=len(reopened) or not original or set(original)!=set(current):
        raise ValueError('Distinct matching nonempty object IDs are required')
    for key,a in original.items():
        b=current[key];axes=[]
        for axis in ('WidthPt','HeightPt'):
            before,after=a[axis],b[axis]
            if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<=0 for v in (before,after)):
                raise ValueError('Invalid physical dimension for object '+key)
            absolute=abs(after-before);ratio=absolute/before
            axes.append({'axis':axis,'before_pt':before,'after_pt':after,'absolute_delta_pt':absolute,'relative_delta':ratio,
                         'status':'passed' if absolute<=absolute_pt+1e-9 and ratio<=relative+1e-12 else 'failed'})
        records.append({'Figure':key,'status':'passed' if all(x['status']=='passed' for x in axes) else 'failed','axes':axes,
                        'aspect_ratio_before':a['WidthPt']/a['HeightPt'],'aspect_ratio_after':b['WidthPt']/b['HeightPt']})
    return {'dimensions':summarize(records),'tolerance':{'absolute_pt':absolute_pt,'relative':relative,'combination':'both must pass'},
            'boundary':'Physical dimensions only. ScaleWidth/ScaleHeight are not used. Effective source bounds, cache mapping, molecular display size and visual/native consistency require separate evidence.'}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('measurements',type=Path);p.add_argument('--output',type=Path)
    p.add_argument('--absolute-pt',type=float,default=0.2);p.add_argument('--relative',type=float,default=0.002)
    a=p.parse_args()
    try:
        data=json.loads(a.measurements.read_text(encoding='utf-8-sig'))
        report=compare_sizes(data['Inserted'],data['Reopened'],a.absolute_pt,a.relative)
        safe_report(report,a.output,[a.measurements]);return 1 if report['dimensions']['status']=='failed' else 0
    except (OSError,ValueError,TypeError,KeyError) as e:
        print(json.dumps({'verification':'invalid_input','error':str(e)},ensure_ascii=False));return 2


if __name__=='__main__':sys.exit(main())
