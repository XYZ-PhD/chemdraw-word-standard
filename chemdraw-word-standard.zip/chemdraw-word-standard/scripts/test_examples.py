"""All bundled examples and deliberate counterexamples have explicit expected outcomes."""
import hashlib
import json
from pathlib import Path
import unittest
from cdxml_model import Drawing
from lint_cdxml import lint
from check_correspondence import check
from measure_bond_angles import inventory,audit_plan

EXAMPLES=Path(__file__).resolve().parents[1]/'assets'/'examples'


class Examples(unittest.TestCase):
    def test_all_examples_have_expected_rule_and_angle_outcomes(self):
        matrix={
            'geometry-cases':('pending','passed','passed','not_applicable','incomplete'),
            'geometry-negative-control':('passed','passed','passed','not_applicable','failed'),
            'labels-narrow':('passed','passed','passed','passed','incomplete'),
            'labels-wide':('passed','passed','passed','passed','incomplete'),
            'scope-expanded':('passed','passed','passed','passed','passed_in_scope'),
            'scope-source':('passed','passed','pending','not_applicable','incomplete'),
            'scope-swapped-numbers':('passed','passed','passed','passed','passed_in_scope'),
            'scope-swapped-yields':('passed','passed','passed','passed','passed_in_scope')}
        self.assertEqual(set(matrix),{p.stem for p in EXAMPLES.glob('*.cdxml')})
        for name,expected in matrix.items():
            with self.subTest(name=name):
                d,sha=Drawing.read(EXAMPLES/(name+'.cdxml'))
                roles=json.loads((EXAMPLES/(name+'.roles.json')).read_text(encoding='utf-8'))
                self.assertEqual(roles['source_sha256'],sha)
                observed=tuple(v['status'] for v in lint(d,roles).values())
                observed+=(audit_plan(d.root,sha,inventory(d.root,sha,auto=True))['verification'],)
                self.assertEqual(observed,expected)

    def test_independent_source_manifest_rejects_both_swapped_fixtures(self):
        manifest=json.loads((EXAMPLES/'scope-correspondence.json').read_text(encoding='utf-8'))
        ref,sha=Drawing.read(EXAMPLES/manifest['reference']['file'])
        self.assertEqual(sha,manifest['reference']['sha256'])
        for name,wanted in [('scope-expanded','passed'),('scope-swapped-numbers','failed'),('scope-swapped-yields','failed')]:
            with self.subTest(name=name):
                d,_=Drawing.read(EXAMPLES/(name+'.cdxml'))
                self.assertEqual(check(manifest,ref,d)['correspondence']['status'],wanted)


if __name__=='__main__':unittest.main(verbosity=2)
