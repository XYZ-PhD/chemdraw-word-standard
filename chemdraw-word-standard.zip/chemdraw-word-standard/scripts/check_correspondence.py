"""Compare a candidate figure with an independently confirmed source mapping (read-only)."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
from cdxml_model import Drawing, isomorphic, label_text, safe_report, summarize


def point(obj):
    values=obj.get('p','').split()
    if len(values)!=2: return None
    values=tuple(map(float,values))
    if not all(math.isfinite(x) for x in values):raise ValueError('Nonfinite annotation position')
    return values


def marker_value(drawing,obj):
    text=obj if obj.tag=='t' else obj.find('t')
    return {'tag':obj.tag,'text':label_text(text) if text is not None else None,
            'element':obj.get('Element','6') if obj.tag=='n' else None,
            'isotope':obj.get('Isotope','0') if obj.tag=='n' else None,
            'color':drawing.color(drawing.inherited(obj,'color','0')),
            'text_colors':[r['color'] for r in drawing.runs(text,obj.tag=='n')] if text is not None else []}


def check(expected,reference,candidate,bindings=None):
    if not isinstance(expected,dict) or expected.get('schema_version')!=1 or not isinstance(expected.get('entries'),list):
        raise ValueError('Expected correspondence schema_version 1 and an entries list')
    if not isinstance(expected.get('reference'),dict) or not isinstance(expected['reference'].get('confirmed_by'),str) or not expected['reference']['confirmed_by'].strip():
        raise ValueError('Reference requires a confirmation/provenance statement')
    if any(not isinstance(e,dict) for e in expected['entries']):raise ValueError('Entries must be objects')
    if bindings is not None and not isinstance(bindings,dict):raise ValueError('Bindings must be an object')
    entries=expected['entries']; keys=[e.get('key') for e in entries]
    if not entries or any(not isinstance(k,str) or not k for k in keys) or len(set(keys))!=len(keys):
        raise ValueError('Correspondence keys must be nonempty and unique')
    binds=bindings.get('entries',{}) if bindings else {}
    if not isinstance(binds,dict) or set(binds)-set(keys):raise ValueError('Unknown candidate binding key')
    records=[]; used_fragments=set(); used_labels=set()
    for e in entries:
        key=e['key']; fid=e['fragment_id']; label=e['label_id']; binding=binds.get(key,{})
        if not isinstance(binding,dict):raise ValueError('Each candidate binding must be an object')
        cf=binding.get('fragment_id',fid); cl=binding.get('label_id',label)
        if cf in used_fragments or cl in used_labels:
            raise ValueError('Candidate fragment/label bindings must be one-to-one')
        used_fragments.add(cf);used_labels.add(cl)
        if fid not in reference.fragments or label not in reference.objects or reference.objects[label].tag!='t':
            raise ValueError('Invalid confirmed reference object for '+key)
        number=e.get('number'); yield_text=e.get('yield')
        if not isinstance(number,str) or not number or (yield_text is not None and not isinstance(yield_text,str)):
            raise ValueError('Each entry requires a number string and yield string or null')
        expected_text=number+(', '+yield_text if yield_text is not None else '')
        if label_text(reference.objects[label])!=expected_text:
            raise ValueError('Expected label conflicts with confirmed reference: '+key)
        result={'key':key,'fragment_id':cf,'label_id':cl,'checks':{}}
        checks=result['checks']
        if cf not in candidate.fragments or cl not in candidate.objects or candidate.objects[cl].tag!='t':
            checks['objects']={'status':'failed','reason':'Mapped candidate structure or label is missing'}
        else:
            same=isomorphic(reference.chemical_graph(fid),candidate.chemical_graph(cf))
            checks['structure']={'status':'pending' if same is None else 'passed' if same else 'failed',
                                 'reason':'Attributed graph comparison (Me normalized); unsupported representation requires review'}
            observed=label_text(candidate.objects[cl])
            checks['number_and_yield']={'status':'passed' if observed==expected_text else 'failed',
                                        'expected':expected_text,'observed':observed}
            rp,cp=point(reference.objects[label]),point(candidate.objects[cl])
            if rp is None or cp is None:
                checks['association_position']={'status':'pending','reason':'Missing placement anchor'}
            else:
                rc,cc=reference.fragment_center(fid),candidate.fragment_center(cf)
                delta=math.dist(tuple(rp[i]-rc[i] for i in (0,1)),tuple(cp[i]-cc[i] for i in (0,1)))
                evidence=binding.get('association_review')
                checked=isinstance(evidence,str) and bool(evidence.strip())
                checks['association_position']={'status':'passed' if delta<=0.5 or checked else 'pending',
                    'anchor_delta_pt':delta,'basis':'provided manual association review' if checked else 'preserved source-relative anchor',
                    'evidence':evidence}
            reference_markers=e.get('marker_ids',[]); candidate_markers=binding.get('marker_ids',reference_markers)
            for value in (reference_markers,candidate_markers):
                if not isinstance(value,list) or any(not isinstance(x,str) for x in value) or len(set(value))!=len(value):
                    raise ValueError('Marker IDs must be distinct string lists')
            marker_review=binding.get('association_review')
            marker_reviewed=isinstance(marker_review,str) and bool(marker_review.strip())
            if len(reference_markers)!=len(candidate_markers):
                checks['markers']={'status':'failed','reason':'Marker count differs'}
            else:
                marker_items=[]
                for rm,cm in zip(reference_markers,candidate_markers):
                    if rm not in reference.objects: raise ValueError('Unknown reference marker '+rm)
                    if cm not in candidate.objects:
                        marker_items.append({'status':'failed','marker':cm,'reason':'Missing marker'});continue
                    if reference.objects[rm].tag not in ('n','t') or candidate.objects[cm].tag not in ('n','t'):
                        marker_items.append({'status':'pending','marker':cm,'reason':'Graphic/arrow marker semantics require visual review'});continue
                    equal=marker_value(reference,reference.objects[rm])==marker_value(candidate,candidate.objects[cm])
                    marker_items.append({'status':'passed' if equal else 'failed','marker':cm,'reason':'Text/element/isotope/semantic color comparison'})
                    rp,cp=point(reference.objects[rm]),point(candidate.objects[cm])
                    if rp is None or cp is None:
                        marker_items.append({'status':'pending','marker':cm,'reason':'Missing marker attachment anchor'})
                    if rp and cp:
                        rc,cc=reference.fragment_center(fid),candidate.fragment_center(cf)
                        delta=math.dist(tuple(rp[i]-rc[i] for i in (0,1)),tuple(cp[i]-cc[i] for i in (0,1)))
                        if delta>0.5 and not marker_reviewed:
                            marker_items.append({'status':'pending','marker':cm,'reason':'Marker attachment anchor changed'})
                checks['markers']=summarize(marker_items)
        statuses=[c['status'] for c in checks.values()]
        result['status']='failed' if 'failed' in statuses else 'pending' if 'pending' in statuses else 'passed'
        records.append(result)
    unassigned=set(candidate.fragments)-used_fragments
    if unassigned:
        records.append({'key':None,'status':'pending','reason':'Visible structures without correspondence entries','fragment_ids':sorted(unassigned)})
    return {'correspondence':summarize(records),'scope_fragments':candidate.scope,
            'boundary':'Declared reference associations and supported exact graph representation only. Manual association evidence is recorded, not independently proven. No Word/OLE/PDF conclusion.'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('expected',type=Path);p.add_argument('candidate',type=Path)
    p.add_argument('--bindings',type=Path);p.add_argument('--output',type=Path)
    a=p.parse_args()
    try:
        expected=json.loads(a.expected.read_text(encoding='utf-8-sig'))
        if not isinstance(expected,dict) or not isinstance(expected.get('reference'),dict):raise ValueError('Invalid reference manifest')
        source=(a.expected.parent/expected['reference']['file']).resolve()
        ref,refhash=Drawing.read(source)
        if refhash!=expected['reference'].get('sha256'):
            raise ValueError('Confirmed reference hash mismatch; do not regenerate it from the candidate')
        bind=json.loads(a.bindings.read_text(encoding='utf-8-sig')) if a.bindings else None
        if bind is not None and not isinstance(bind,dict):raise ValueError('Bindings must be an object')
        cand,candhash=Drawing.read(a.candidate,bind.get('scope_fragments') if bind else None)
        if bind and bind.get('source_sha256')!=candhash:raise ValueError('Candidate binding source hash mismatch')
        report=check(expected,ref,cand,bind)
        report.update(reference_sha256=refhash,candidate_sha256=candhash,
                      expected_manifest_sha256=hashlib.sha256(a.expected.read_bytes()).hexdigest())
        safe_report(report,a.output,[a.expected,a.candidate,source]+([a.bindings] if a.bindings else []))
        return {'failed':1,'pending':3}.get(report['correspondence']['status'],0)
    except (OSError,ValueError,TypeError,KeyError,ET.ParseError) as e:
        print(json.dumps({'verification':'invalid_input','error':str(e)},ensure_ascii=False));return 2


if __name__=='__main__':sys.exit(main())
