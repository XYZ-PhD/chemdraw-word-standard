"""The approximate preview must draw every visible bond and text, and must report what it cannot draw."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
from cdxml_model import Drawing
from render_preview import Preview, FOOTER
from temp_probe import probe_temp_parent

ROOT = Path(__file__).resolve().parents[1] / 'assets'
SVG = '{http://www.w3.org/2000/svg}'


class RenderPreview(unittest.TestCase):
    def test_every_example_renders_all_bonds_and_texts(self):
        for path in sorted((ROOT / 'examples').glob('*.cdxml')):
            with self.subTest(name=path.stem):
                d, _ = Drawing.read(path)
                preview = Preview(d)
                svg, skipped = preview.render()
                tree = ET.fromstring(svg.encode('utf-8'))
                lines = tree.findall(SVG + 'line') + tree.findall(SVG + 'polygon')
                self.assertGreaterEqual(len(lines), len(d.bonds))
                self.assertEqual(len(tree.findall(SVG + 'text')), len(d.texts) + 1)
                self.assertEqual(tree.find(SVG + 'title').text, FOOTER)
                self.assertEqual(skipped, {})

    def test_unsupported_objects_are_reported_not_silently_dropped(self):
        source = (ROOT / 'examples' / 'labels-wide.cdxml').read_text(encoding='utf-8')
        source = source.replace('</page>', '<curve id="9001" CurvePoints="0 0 10 10 20 0"/></page>')
        with tempfile.TemporaryDirectory(dir=probe_temp_parent()) as folder:
            src = Path(folder) / 'in.cdxml'; src.write_text(source, encoding='utf-8')
            out = Path(folder) / 'out.svg'
            r = subprocess.run([sys.executable, '-B', str(Path(__file__).with_name('render_preview.py')), str(src), str(out)],
                               capture_output=True, text=True)
            self.assertEqual(r.returncode, 3)
            report = json.loads(r.stdout)
            self.assertEqual(report['not_rendered_elements'], {'curve': 1})
            self.assertEqual(report['verification'], 'preview_only')
            self.assertTrue(out.exists())

    def test_empty_template_and_invalid_input(self):
        d, _ = Drawing.read(ROOT / 'chemdraw-standard.cdxml')
        svg, skipped = Preview(d).render()
        self.assertIn(FOOTER, svg)
        with tempfile.TemporaryDirectory(dir=probe_temp_parent()) as folder:
            bad = Path(folder) / 'bad.cdxml'; bad.write_text('<notcdxml/>', encoding='utf-8')
            r = subprocess.run([sys.executable, '-B', str(Path(__file__).with_name('render_preview.py')), str(bad), str(Path(folder) / 'o.svg')],
                               capture_output=True, text=True)
            self.assertEqual(r.returncode, 2)


if __name__ == '__main__':
    unittest.main(verbosity=2)
