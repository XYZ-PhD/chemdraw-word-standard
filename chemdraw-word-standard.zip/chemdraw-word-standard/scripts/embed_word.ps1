<# Windows PowerShell adapter. New output directory only. Never resizes OLE objects.
Input JSON: {"figures":[{"id":"wide","source":"absolute/file.cdxml"}]}
COM/API checks are not a replacement for final UI double-click and PDF visual QA.
#>
param(
    [Parameter(Mandatory=$true)][string]$InputManifest,
    [Parameter(Mandatory=$true)][string]$OutputDirectory,
    [string]$ChemDrawProgId = 'ChemDraw_x64.Application',
    [string]$DocumentProgId = 'ChemDraw_x64.Document.6.0'
)
$ErrorActionPreference = 'Stop'
$missing = [Type]::Missing
$word = $null; $doc = $null; $chem = $null; $wordOwned = $false
$out = [IO.Path]::GetFullPath($OutputDirectory)
if (Test-Path -LiteralPath $out) { throw 'Use a new output directory; existing files are never overwritten.' }
if ($out -match '[^\x00-\x7F]') { throw 'Use a fully ASCII staging path; copy validated outputs to the final path afterward.' }
$manifestPath = (Resolve-Path -LiteralPath $InputManifest).Path
$inputHash = (Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash
$spec = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
$figures = @($spec.figures)
if ($figures.Count -eq 0) { throw 'Manifest requires at least one figure.' }
$ids = @{}
$sources = @()
foreach ($f in $figures) {
    if (!$f.id -or $f.id -notmatch '^[A-Za-z0-9_-]+$' -or $ids.ContainsKey([string]$f.id)) { throw 'Figure IDs must be distinct ASCII filenames.' }
    $ids[[string]$f.id] = $true
    $source = (Resolve-Path -LiteralPath $f.source).Path
    if ([IO.Path]::GetExtension($source) -notin @('.cdxml','.cdx')) { throw 'Input must be CDX or CDXML.' }
    $sources += [pscustomobject]@{ Figure=[string]$f.id; Path=$source; SHA256=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash }
}
[void](New-Item -ItemType Directory -Path $out)
$report = [ordered]@{ Status='incomplete'; StartedUtc=[DateTime]::UtcNow.ToString('o'); Sources=$sources; InputManifestSHA256=$inputHash; Inserted=@(); Reopened=@(); Native=@(); Boundary='Native API workflow only. UI double-click, cache/page comparison and final PDF visual QA remain required.' }

function Release-Com($item) {
    if ($null -ne $item -and [Runtime.InteropServices.Marshal]::IsComObject($item)) { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($item) }
}
function Confirm-File([string]$path,[string]$kind) {
    if (!(Test-Path -LiteralPath $path -PathType Leaf)) { throw "Save did not create $path" }
    $bytes=[IO.File]::ReadAllBytes($path)
    if ($bytes.Length -eq 0) { throw "Empty output: $path" }
    if ($kind -eq 'cdx' -and ($bytes.Length -lt 8 -or [Text.Encoding]::ASCII.GetString($bytes,0,8) -ne 'VjCD0100')) { throw "Invalid CDX header: $path" }
    if ($kind -eq 'cdxml') {
        $xml=New-Object System.Xml.XmlDocument
        $xml.XmlResolver=$null
        $xml.Load($path)
        # PowerShell's XML adapter maps .Name to ChemDraw's Name attribute.
        if ($xml.DocumentElement.get_LocalName() -ne 'CDXML') { throw "Invalid CDXML root: $path" }
    }
    if ($kind -eq 'pdf' -and ($bytes.Length -lt 5 -or [Text.Encoding]::ASCII.GetString($bytes,0,5) -ne '%PDF-')) { throw "Invalid PDF header: $path" }
}
function Placement($shape,[string]$id) {
    [pscustomobject]@{Figure=$id;WidthPt=[double]$shape.Width;HeightPt=[double]$shape.Height;ScaleWidth=$shape.ScaleWidth;ScaleHeight=$shape.ScaleHeight;ProgID=$shape.OLEFormat.ProgID}
}
function Write-Report {
    $report | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $out 'native-run.json') -Encoding UTF8
}

try {
    $chem=New-Object -ComObject $ChemDrawProgId
    try { $report.ChemDrawVersion=[string]$chem.Version } catch { $report.ChemDrawVersion='unavailable via COM' }
    if (!$report.ChemDrawVersion) { $report.ChemDrawVersion='unavailable via COM; see executable version' }
    $report.ChemDrawExecutables=@(Get-Process -Name ChemDraw* -ErrorAction SilentlyContinue | ForEach-Object { [pscustomobject]@{Path=$_.Path;Version=$_.FileVersion} })
    foreach ($src in $sources) {
        $id=$src.Figure
        $staged=Join-Path $out ($id+'_input'+[IO.Path]::GetExtension($src.Path))
        Copy-Item -LiteralPath $src.Path -Destination $staged
        $cdx=Join-Path $out ($id+'.cdx'); $xml=Join-Path $out ($id+'_reopened.cdxml')
        $drawing=$null
        try {
            $drawing=$chem.Documents.Open($staged)
            $drawing.SaveAs($cdx); Confirm-File $cdx 'cdx'
            $drawing.Close(); Release-Com $drawing; $drawing=$null
            $drawing=$chem.Documents.Open($cdx)
            $drawing.SaveAs($xml); Confirm-File $xml 'cdxml'
            $report.Native += [pscustomobject]@{Figure=$id;CdxSHA256=(Get-FileHash -LiteralPath $cdx -Algorithm SHA256).Hash;ReopenedXmlSHA256=(Get-FileHash -LiteralPath $xml -Algorithm SHA256).Hash}
        } finally { if ($null -ne $drawing) { try { $drawing.Close() } catch {}; Release-Com $drawing } }
        Write-Output "Saved and reopened native figure: $id"
        Write-Report
    }
    $word=New-Object -ComObject 'Word.Application'
    # Refuse a reused application with existing documents; never close them or change its settings.
    if ($word.Documents.Count -ne 0) { throw 'COM returned a Word instance with existing documents; leave it untouched.' }
    $wordOwned=$true
    $word.Visible=$true; $word.DisplayAlerts=0
    $report.WordVersion=[string]$word.Version; $report.WordBuild=[string]$word.Build
    $doc=$word.Documents.Add()
    $doc.PageSetup.PaperSize=7 # A4
    $doc.PageSetup.Orientation=0
    $doc.PageSetup.TopMargin=72; $doc.PageSetup.BottomMargin=72
    $doc.PageSetup.LeftMargin=72; $doc.PageSetup.RightMargin=72
    $doc.Content.Font.Name='Arial'; $doc.Content.Font.Size=10
    $doc.Content.ParagraphFormat.SpaceAfter=8
    [string]$docPath=Join-Path $out 'verification.docx'
    [string]$pdfPath=Join-Path $out 'verification.pdf'
    $report.Stage='saving_empty_shell'; Write-Report
    Write-Output 'Saving the empty Word shell before OLE insertion'
    $doc.SaveAs2([string]$docPath,16)
    $available=[double]$doc.PageSetup.PageWidth-144
    foreach ($src in $sources) {
        $id=$src.Figure
        $tail=$doc.Range($doc.Content.End-1,$doc.Content.End-1)
        $tail.InsertAfter("ChemDraw verification - $id`r")
        Release-Com $tail
        $position=$doc.Range($doc.Content.End-1,$doc.Content.End-1)
        $shape=$doc.InlineShapes.AddOLEObject($DocumentProgId,(Join-Path $out ($id+'.cdx')),$false,$false,$missing,$missing,$missing,$position)
        $placement=Placement $shape $id
        $report.Inserted += $placement
        if ($placement.WidthPt -gt ($available+0.2)) { throw "Default size exceeds the body width for $id; rearrange the native source. No scaling performed." }
        $shape.AlternativeText="Editable ChemDraw $id"
        Release-Com $shape; Release-Com $position
        if ($src -ne $sources[-1]) {
            $tail=$doc.Range($doc.Content.End-1,$doc.Content.End-1); $tail.InsertAfter("`r"); Release-Com $tail
        }
        Write-Output ("Inserted at default size: "+($placement|ConvertTo-Json -Compress))
        Write-Report
    }
    Write-Output 'Saving the new Word document'
    $report.Stage='saving_word'; Write-Report
    $doc.Save()
    $doc.Close(0); Release-Com $doc; $doc=$null
    Confirm-File $docPath 'docx'
    $wordHash=(Get-FileHash -LiteralPath $docPath -Algorithm SHA256).Hash
    $doc=$word.Documents.Open($docPath,$false,$true)
    $report.Stage='reopened_word'; Write-Report
    if ($doc.InlineShapes.Count -ne $sources.Count) { throw 'Saved/reopened object count differs.' }
    $report.Pages=$doc.ComputeStatistics(2)
    $doc.ExportAsFixedFormat($pdfPath,17); Confirm-File $pdfPath 'pdf'
    for ($i=1;$i -le $sources.Count;$i++) {
        $id=$sources[$i-1].Figure; $shape=$doc.InlineShapes.Item($i); $native=$null
        try {
            $report.Reopened += Placement $shape $id
            $shape.OLEFormat.DoVerb(0)
            $native=$shape.OLEFormat.Object
            $opened=Join-Path $out ($id+'_embedded.cdx')
            $native.SaveAs($opened); Confirm-File $opened 'cdx'
            $xml=Join-Path $out ($id+'_embedded.cdxml')
            $native.SaveAs($xml); Confirm-File $xml 'cdxml'
            Write-Output "Activated embedded native object and exported: $id"
        } finally {
            if ($null -ne $native) { try { $native.Close() } catch {}; Release-Com $native }
            Release-Com $shape
        }
    }
    $doc.Close(0); Release-Com $doc; $doc=$null
    if ((Get-FileHash -LiteralPath $docPath -Algorithm SHA256).Hash -ne $wordHash) { throw 'Read-only validation changed the DOCX.' }
    foreach ($src in $sources) { if ((Get-FileHash -LiteralPath $src.Path -Algorithm SHA256).Hash -ne $src.SHA256) { throw "Input changed: $($src.Path)" } }
    if ((Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash -ne $inputHash) { throw 'Input manifest changed.' }
    $report.WordSHA256=$wordHash
    $report.PdfSHA256=(Get-FileHash -LiteralPath $pdfPath -Algorithm SHA256).Hash
    $report.Status='native_api_completed_visual_review_pending'
} catch {
    $report.Status='failed'; $report.Error=$_.Exception.Message
    throw
} finally {
    if ($null -ne $doc) { try { $doc.Close(0) } catch {}; Release-Com $doc }
    if ($null -ne $word) {
        if ($wordOwned) { try { if ($word.Documents.Count -eq 0) { $word.Quit() } } catch {} }
        Release-Com $word
    }
    # ChemDraw may be a shared server. Release only our documents and handle; never Quit it.
    Release-Com $chem
    $report.FinishedUtc=[DateTime]::UtcNow.ToString('o'); Write-Report
}
