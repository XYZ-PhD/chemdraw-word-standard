"""Approximate CDXML -> SVG preview for environments without ChemDraw. Read-only, standard library only.

This is a self-check aid, not ChemDraw rendering: glyph metrics, double-bond
placement, label clipping and unsupported objects are approximated or listed in
the report. It never proves native appearance, Word display or OLE editability.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape
from cdxml_model import Drawing, label_text, order, visible

RENDERED = {'CDXML', 'page', 'fragment', 'n', 'b', 't', 's', 'colortable', 'color', 'fonttable', 'font', 'arrow'}
FOOTER = 'Approximate preview - not ChemDraw rendering'


def num(value, default):
    try:
        x = float(value)
        return x if math.isfinite(x) else default
    except (TypeError, ValueError):
        return default


def rgb(color):
    if color is None:
        return '#000000'
    return '#%02x%02x%02x' % tuple(max(0, min(255, round(c * 255))) for c in color)


def box(text_element):
    parts = (text_element.get('BoundingBox') or '').split()
    if len(parts) != 4:
        return None
    x1, y1, x2, y2 = (num(v, None) for v in parts)
    if None in (x1, y1, x2, y2):
        return None
    return min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2)


def clip(p, q, rect, margin):
    """Move p toward q until it leaves rect expanded by margin (labels are not crossed by bonds)."""
    if rect is None:
        return p
    x1, y1, x2, y2 = rect[0] - margin, rect[1] - margin, rect[2] + margin, rect[3] + margin
    dx, dy = q[0] - p[0], q[1] - p[1]
    t_exit = 0.0
    for d, lo, hi, start in ((dx, x1, x2, p[0]), (dy, y1, y2, p[1])):
        if abs(d) < 1e-12:
            continue
        for bound in (lo, hi):
            t = (bound - start) / d
            if 0 < t < 1:
                x, y = p[0] + dx * t, p[1] + dy * t
                if x1 - 1e-6 <= x <= x2 + 1e-6 and y1 - 1e-6 <= y <= y2 + 1e-6:
                    t_exit = max(t_exit, t)
    return (p[0] + dx * t_exit, p[1] + dy * t_exit)


class Preview:
    def __init__(self, drawing):
        self.d = drawing
        root = drawing.root
        self.bond_length = num(root.get('BondLength'), 14.4)
        self.line = num(root.get('LineWidth'), 0.6)
        self.bold = num(root.get('BoldWidth'), 2.0)
        self.spacing = num(root.get('BondSpacing'), 18) / 100 * self.bond_length
        self.margin = num(root.get('MarginWidth'), 1.6)
        self.hash_spacing = num(root.get('HashSpacing'), 2.5)
        self.items, self.notes, self.points = [], [], []
        self.labels = {}
        for key, data in drawing.nodes.items():
            t = data['node'].find('t')
            if t is not None and label_text(t).strip():
                self.labels[key] = box(t)

    def add_points(self, *pts):
        self.points.extend(pts)

    def seg(self, a, b, width=None, extra=''):
        self.add_points(a, b)
        self.items.append('<line x1="%.2f" y1="%.2f" x2="%.2f" y2="%.2f" stroke="#000" stroke-width="%.2f" stroke-linecap="round"%s/>'
                          % (a[0], a[1], b[0], b[1], width or self.line, extra))

    def ring_side(self, a, z):
        """Sign of the side (relative to a->z) where the ring center lies, or None for acyclic bonds."""
        path = self.d.cyclic_edges().get(frozenset((a, z)))
        if not path:
            return None
        pts = [self.d.nodes[k]['point'] for k in path]
        cx, cy = sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts)
        pa, pz = self.d.nodes[a]['point'], self.d.nodes[z]['point']
        cross = (pz[0] - pa[0]) * (cy - pa[1]) - (pz[1] - pa[1]) * (cx - pa[0])
        return 1 if cross > 0 else -1

    def bond(self, b):
        a, z = b.get('B'), b.get('E')
        pa, pz = self.d.nodes[a]['point'], self.d.nodes[z]['point']
        p = clip(pa, pz, self.labels.get(a), self.margin)
        q = clip(pz, pa, self.labels.get(z), self.margin)
        length = math.dist(p, q)
        if length < 1e-6:
            self.notes.append({'object_id': b.get('id'), 'note': 'bond hidden by label clipping'})
            return
        ux, uy = (q[0] - p[0]) / length, (q[1] - p[1]) / length
        nx, ny = -uy, ux
        display = b.get('Display', 'Solid')
        o = order(b)
        if display.startswith('Wedge') or display.startswith('WedgedHash'):
            narrow, wide = (p, q) if display.endswith('Begin') else (q, p)
            half = self.bold * 1.6
            wx, wy = (wide[0] - narrow[0]), (wide[1] - narrow[1])
            wl = math.hypot(wx, wy); vx, vy = -wy / wl, wx / wl
            if display.startswith('WedgedHash'):
                steps = max(2, int(wl / self.hash_spacing))
                for i in range(1, steps + 1):
                    f = i / steps
                    cx, cy = narrow[0] + wx * f, narrow[1] + wy * f
                    self.seg((cx - vx * half * f, cy - vy * half * f), (cx + vx * half * f, cy + vy * half * f))
            else:
                pts = [narrow, (wide[0] + vx * half, wide[1] + vy * half), (wide[0] - vx * half, wide[1] - vy * half)]
                self.add_points(*pts)
                self.items.append('<polygon points="%s" fill="#000"/>' % ' '.join('%.2f,%.2f' % x for x in pts))
            return
        if display == 'Hash':
            steps = max(2, int(length / self.hash_spacing))
            for i in range(steps + 1):
                cx, cy = p[0] + ux * length * i / steps, p[1] + uy * length * i / steps
                self.seg((cx - nx * self.bold, cy - ny * self.bold), (cx + nx * self.bold, cy + ny * self.bold))
            return
        width = self.bold if display == 'Bold' else self.line
        dash = ' stroke-dasharray="%.2f %.2f"' % (self.hash_spacing, self.hash_spacing) if display in ('Dash', 'Dot') else ''
        if display not in ('Solid', 'Bold', 'Dash', 'Dot'):
            self.notes.append({'object_id': b.get('id'), 'note': 'bond display %s drawn as a plain line' % display})
        if o in (None, 1):
            if o is None:
                self.notes.append({'object_id': b.get('id'), 'note': 'unsupported bond order drawn as single'})
            self.seg(p, q, width, dash)
        elif o == 3:
            self.seg(p, q, width, dash)
            for s in (1, -1):
                off = s * self.spacing
                self.seg((p[0] + nx * off, p[1] + ny * off), (q[0] + nx * off, q[1] + ny * off), width, dash)
        else:  # 2 or aromatic 1.5
            side = self.ring_side(a, z)
            position = b.get('DoublePosition')
            if position in ('Left', 'Right'):
                side = 1 if position == 'Left' else -1  # ChemDraw convention approximated
            terminal = len(self.d.adjacency[a]) == 1 or len(self.d.adjacency[z]) == 1
            if side is None and (terminal or a in self.labels or z in self.labels or position == 'Center'):
                for s in (0.5, -0.5):
                    off = s * self.spacing
                    self.seg((p[0] + nx * off, p[1] + ny * off), (q[0] + nx * off, q[1] + ny * off), width, dash)
                return
            if side is None:
                side = 1
                self.notes.append({'object_id': b.get('id'), 'note': 'acyclic double-bond side approximated'})
            self.seg(p, q, width, dash)
            off = side * self.spacing
            trim = self.spacing * 0.9
            inner_dash = ' stroke-dasharray="1.5 1.5"' if o == 1.5 else dash
            self.seg((p[0] + nx * off + ux * trim, p[1] + ny * off + uy * trim),
                     (q[0] + nx * off - ux * trim, q[1] + ny * off - uy * trim), width, inner_dash)

    def text(self, t, atom):
        x, y = (num(v, None) for v in ((t.get('p') or ' ').split() + [None, None])[:2])
        if x is None or y is None:
            self.notes.append({'object_id': t.get('id'), 'note': 'text without position not drawn'})
            return
        just = t.get('Justification') or t.get('LabelJustification') or t.get('CaptionJustification') or 'Left'
        anchor = {'Right': 'end', 'Center': 'middle'}.get(just, 'start')
        rect = box(t)
        if rect:
            self.add_points((rect[0], rect[1]), (rect[2], rect[3]))
        # Local fonts can be wider than ChemDraw's stored box; widen the canvas by an estimate.
        runs = self.d.runs(t, atom)
        size0 = max([r['size'] or 10.0 for r in runs] or [10.0])
        width = sum(len(r['text']) * (r['size'] or 10.0) * 0.6 for r in runs)
        left = {'end': x - width, 'middle': x - width / 2}.get(anchor, x)
        self.add_points((left, y - size0 * 0.85), (left + width, y + size0 * 0.3))
        spans = []
        for r in runs:
            size = r['size'] or 10.0
            style = ['font-size:%.2fpt' % size]
            if r['face'] & 1:
                style.append('font-weight:bold')
            if r['face'] & 2:
                style.append('font-style:italic')
            fill = rgb(r['color'])
            formula = (r['face'] & 96) == 96
            sub = (r['face'] & 96) == 32
            sup = (r['face'] & 96) == 64
            chunks = []
            if formula:  # digits after letters/brackets are subscripts in ChemDraw formula style
                prev = ''
                for c in r['text']:
                    kind = 'sub' if c.isdigit() and (prev.isalpha() or prev in ')]' or (prev.isdigit() and chunks and chunks[-1][0] == 'sub')) else 'base'
                    if chunks and chunks[-1][0] == kind:
                        chunks[-1][1] += c
                    else:
                        chunks.append([kind, c])
                    prev = c
            else:
                chunks.append(['sub' if sub else 'sup' if sup else 'base', r['text']])
            for kind, content in chunks:
                if kind == 'base':
                    spans.append('<tspan style="%s" fill="%s">%s</tspan>' % (';'.join(style), fill, escape(content)))
                else:
                    shift = 0.3 * size if kind == 'sub' else -0.35 * size
                    small = [s if not s.startswith('font-size') else 'font-size:%.2fpt' % (size * 0.75) for s in style]
                    spans.append('<tspan dy="%.2f" style="%s" fill="%s">%s</tspan><tspan dy="%.2f" style="font-size:%.2fpt"> </tspan>'
                                 % (shift, ';'.join(small), fill, escape(content), -shift, 0.01))
        self.items.append('<text x="%.2f" y="%.2f" text-anchor="%s" font-family="Arial, Liberation Sans, Helvetica, sans-serif" xml:space="preserve">%s</text>'
                          % (x, y, anchor, ''.join(spans)))

    def arrow(self, a):
        head = [num(v, None) for v in (a.get('Head3D') or '').split()[:2]]
        tail = [num(v, None) for v in (a.get('Tail3D') or '').split()[:2]]
        if len(head) != 2 or len(tail) != 2 or None in head + tail:
            self.notes.append({'object_id': a.get('id'), 'note': 'arrow without Head3D/Tail3D not drawn'})
            return
        h, t = tuple(head), tuple(tail)
        L = math.dist(h, t)
        if L < 1e-6:
            return
        ux, uy = (h[0] - t[0]) / L, (h[1] - t[1]) / L
        size = num(a.get('HeadSize'), 1000) / 100 * self.line * 3
        base = (h[0] - ux * size * 1.5, h[1] - uy * size * 1.5)
        self.seg(t, base)
        pts = [h, (base[0] - uy * size * 0.6, base[1] + ux * size * 0.6), (base[0] + uy * size * 0.6, base[1] - ux * size * 0.6)]
        self.add_points(*pts)
        self.items.append('<polygon points="%s" fill="#000"/>' % ' '.join('%.2f,%.2f' % x for x in pts))
        self.notes.append({'object_id': a.get('id'), 'note': 'arrow head style approximated'})

    def render(self, scale=2.0, pad=10.0):
        for b in self.d.bonds.values():
            self.bond(b)
        for key, t, atom in self.d.texts:
            self.text(t, atom)
        skipped = {}
        for e in visible(self.d.root):
            if e.tag == 'arrow':
                self.arrow(e)
            elif e.tag not in RENDERED:
                skipped[e.tag] = skipped.get(e.tag, 0) + 1
        if self.points:
            x1 = min(p[0] for p in self.points) - pad; y1 = min(p[1] for p in self.points) - pad
            x2 = max(p[0] for p in self.points) + pad; y2 = max(p[1] for p in self.points) + pad
        else:
            x1, y1, x2, y2 = 0, 0, 200, 40
        footer_h = 12
        x2 = max(x2, x1 + 155)  # keep the not-ChemDraw footer fully visible
        w, h = x2 - x1, y2 - y1 + footer_h
        svg = ['<?xml version="1.0" encoding="UTF-8"?>',
               '<svg xmlns="http://www.w3.org/2000/svg" width="%.1f" height="%.1f" viewBox="%.2f %.2f %.2f %.2f">'
               % (w * scale, h * scale, x1, y1, w, h),
               '<title>%s</title>' % FOOTER,
               '<rect x="%.2f" y="%.2f" width="%.2f" height="%.2f" fill="#fff"/>' % (x1, y1, w, h)]
        svg += self.items
        svg.append('<text x="%.2f" y="%.2f" font-family="Arial, Liberation Sans, sans-serif" font-size="5pt" fill="#999">%s</text>'
                   % (x1 + 2, y2 + footer_h - 3, FOOTER))
        svg.append('</svg>')
        return '\n'.join(svg) + '\n', skipped


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('cdxml', type=Path)
    p.add_argument('output_svg', type=Path)
    p.add_argument('--report', type=Path, help='Optional JSON report of approximations and unrendered objects')
    p.add_argument('--scale', type=float, default=2.0, help='Pixels per point for the SVG width/height (default 2)')
    a = p.parse_args()
    try:
        if not (math.isfinite(a.scale) and a.scale > 0):
            raise ValueError('Scale must be a positive finite number')
        for out in [a.output_svg] + ([a.report] if a.report else []):
            if out.exists() and out.resolve() == a.cdxml.resolve():
                raise ValueError('Output must not overwrite the input')
        drawing, sha = Drawing.read(a.cdxml)
        preview = Preview(drawing)
        svg, skipped = preview.render(a.scale)
        a.output_svg.write_text(svg, encoding='utf-8')
        report = {'schema_version': 1, 'source_sha256': sha, 'output': str(a.output_svg),
                  'svg_sha256': hashlib.sha256(svg.encode('utf-8')).hexdigest(),
                  'verification': 'preview_only', 'approximations': preview.notes,
                  'not_rendered_elements': skipped,
                  'boundary': 'Approximate standard-library preview. Not ChemDraw rendering; no native, Word, OLE or PDF evidence.'}
        if a.report:
            a.report.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 3 if skipped else 0
    except (OSError, ValueError, TypeError, KeyError, ET.ParseError) as e:
        print(json.dumps({'verification': 'invalid_input', 'error': str(e)}, ensure_ascii=False))
        return 2


if __name__ == '__main__':
    sys.exit(main())
