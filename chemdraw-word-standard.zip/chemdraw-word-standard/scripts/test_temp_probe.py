import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from temp_probe import probe_temp_parent


class TempProbeTests(unittest.TestCase):
    def setUp(self):
        self.parent=probe_temp_parent()

    def test_full_probe_cleans_up(self):
        before=set(self.parent.glob('chemdraw-probe-*'))
        self.assertEqual(probe_temp_parent(self.parent),self.parent)
        self.assertEqual(set(self.parent.glob('chemdraw-probe-*')),before)

    def test_missing_directory_fails_clearly(self):
        with self.assertRaisesRegex(RuntimeError,'CHEMDRAW_TEST_TMP'):
            probe_temp_parent(self.parent/'missing-chemdraw-test-directory')

    def test_write_denial_is_not_a_successful_preflight(self):
        with patch.object(Path,'write_bytes',side_effect=PermissionError('simulated denied write')):
            with self.assertRaisesRegex(RuntimeError,'simulated denied write'):
                probe_temp_parent(self.parent)

    def test_readback_mismatch_is_detected(self):
        with patch.object(Path,'read_bytes',return_value=b'wrong'):
            with self.assertRaisesRegex(RuntimeError,'read-back differs'):
                probe_temp_parent(self.parent)


if __name__=='__main__':
    unittest.main(verbosity=2)
