import copy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile
from check_word_sizes import compare_sizes
from inspect_word_package import inspect
from preflight import inspect_environment
from temp_probe import probe_temp_parent


class WordChecks(unittest.TestCase):
    def test_tolerance_boundary_allows_binary_float_rounding(self):
        a=[{'Figure':'A','WidthPt':100,'HeightPt':100}];b=[{'Figure':'A','WidthPt':100.2,'HeightPt':100.2}]
        self.assertEqual(compare_sizes(a,b)['dimensions']['status'],'passed')

    def test_recorded_hi_height_rounding_and_zero_scale_are_allowed(self):
        a=[{'Figure':'HI','WidthPt':414,'HeightPt':465.35000610351563,'ScaleWidth':0}]
        b=[{'Figure':'HI','WidthPt':414,'HeightPt':465.5,'ScaleWidth':0}]
        self.assertEqual(compare_sizes(a,b)['dimensions']['status'],'passed')

    def test_real_size_change_is_rejected(self):
        a=[{'Figure':'A','WidthPt':100,'HeightPt':200}];b=copy.deepcopy(a);b[0]['WidthPt']=99
        self.assertEqual(compare_sizes(a,b)['dimensions']['status'],'failed')

    def test_relative_limit_protects_small_objects(self):
        a=[{'Figure':'A','WidthPt':1,'HeightPt':1}];b=copy.deepcopy(a);b[0]['HeightPt']=1.15
        self.assertEqual(compare_sizes(a,b)['dimensions']['status'],'failed')

    def test_missing_duplicate_and_nonfinite_dimensions_rejected(self):
        a=[{'Figure':'A','WidthPt':100,'HeightPt':200}]
        for b in ([],a+a,[{'Figure':'A','WidthPt':float('nan'),'HeightPt':200}]):
            with self.assertRaises(ValueError):compare_sizes(a,b)

    def test_negative_tolerance_rejected(self):
        with self.assertRaises(ValueError):compare_sizes([],[],-1)

    def package(self,external=False,missing=False,absolute=False):
        parent=probe_temp_parent()
        with tempfile.TemporaryDirectory(dir=parent) as folder:
            path=Path(folder)/'test.docx'
            with zipfile.ZipFile(path,'w') as z:
                z.writestr('word/document.xml','<w:document xmlns:w="w" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><v:shape id="s1"><v:imagedata r:id="r2"/></v:shape><o:OLEObject Type="Embed" ProgID="ChemDraw_x64.Document.6.0" ShapeID="s1" r:id="r1"/></w:document>')
                mode=' TargetMode="External"' if external else ''
                target='/word/embeddings/ole.bin' if absolute else 'embeddings/ole.bin'
                z.writestr('word/_rels/document.xml.rels','<Relationships><Relationship Id="r1" Target="'+target+'"'+mode+'/><Relationship Id="r2" Target="media/cache.emf"/></Relationships>')
                if not missing:z.writestr('word/embeddings/ole.bin',b'not proof of a valid OLE payload')
                z.writestr('word/media/cache.emf',b'cache')
            before=path.read_bytes();r=inspect(path);self.assertEqual(path.read_bytes(),before);return r

    def test_package_presence_is_separate_from_native_validation(self):
        r=self.package();self.assertEqual(r['objects'][0]['presence_status'],'passed')
        self.assertIn('not validated',r['boundary'])

    def test_external_or_missing_ole_is_rejected(self):
        for r in (self.package(external=True),self.package(missing=True)):
            self.assertEqual(r['objects'][0]['presence_status'],'failed')

    def test_internal_absolute_package_relationship(self):
        self.assertEqual(self.package(absolute=True)['objects'][0]['presence_status'],'passed')

    def test_environment_capabilities_do_not_claim_application_success(self):
        with patch('preflight.registered',return_value=False):
            r=inspect_environment(probe_temp_parent())
        self.assertEqual(r['delivery_capability'],'cdxml_candidate')
        self.assertIn('not an application',r['boundary'])


if __name__=='__main__':unittest.main(verbosity=2)
