"""Regression checks for coverage and numerical behavior; no native app required."""
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
import measure_bond_angles as tool


def drawing(points_by_fragment):
    root = ET.Element('CDXML')
    page = ET.SubElement(root, 'page', id='1')
    for i, points in enumerate(points_by_fragment):
        base = (i+1)*100
        f = ET.SubElement(page, 'fragment', id=str(base))
        for j, p in enumerate(points):
            ET.SubElement(f, 'n', id=str(base+j+1), p=' '.join(map(str, p)))
        for j in range(1,len(points)):
            ET.SubElement(f, 'b', id=str(base+20+j), B=str(base+1), E=str(base+j+1))
    return root


GOOD = [(0,0),(-14.4,0),(7.2,-14.4*math.sqrt(3)/2),(7.2,14.4*math.sqrt(3)/2)]
BAD = [(0,0),(-14.4,0),(0,-14.4),(14.4*math.sqrt(3)/2,7.2)]


class AngleTests(unittest.TestCase):
    def setUp(self):
        parent = Path(os.environ.get('CHEMDRAW_TEST_TMP', tempfile.gettempdir())).resolve()
        self.temp = tempfile.TemporaryDirectory(prefix='chemdraw-angle-test-', dir=parent)
        if not Path(self.temp.name).resolve().is_relative_to(parent):
            raise ValueError('Test directory escaped its intended temporary parent')
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name)/'input.cdxml'

    def cli(self, root, *args):
        ET.ElementTree(root).write(self.path, encoding='utf-8')
        before = self.path.read_bytes()
        result = subprocess.run([sys.executable,'-B',str(Path(tool.__file__)),str(self.path),*args],
                                capture_output=True,text=True,encoding='utf8',timeout=15)
        self.assertEqual(before,self.path.read_bytes())
        self.assertNotIn('Traceback',result.stderr)
        return result.returncode,json.loads(result.stdout)

    def plan(self, root, entries=None):
        data = ET.tostring(root)
        plan = tool.inventory(root,hashlib.sha256(data).hexdigest())
        if entries is not None:
            plan['entries']=entries
        return tool.audit_plan(root,hashlib.sha256(data).hexdigest(),plan)

    def test_correct_n_with_explicit_h(self):
        root=drawing([GOOD]);root.find('.//n[@id="103"]').set('Element','1')
        result=tool.measure(root,['101'],120)[0]
        self.assertTrue(result['within_tolerance']);self.assertEqual(len(result['angles']),3)

    def test_bad_n_fails(self):
        self.assertFalse(tool.measure(drawing([BAD]),['101'],120)[0]['within_tolerance'])

    def test_selected_good_does_not_claim_complete(self):
        code,r=self.cli(drawing([GOOD,BAD]),'--centers','101','--expected-angle','120')
        self.assertEqual(code,0);self.assertEqual(r['verification'],'selected_centers_passed')
        self.assertEqual(r['coverage']['unselected_centers'],['201'])

    def test_missing_entry_is_pending(self):
        r=self.plan(drawing([GOOD,BAD]),{'101':{'method':'angle','expected_angle_deg':120}})
        self.assertEqual(r['verification'],'incomplete');self.assertEqual(r['coverage']['pending_centers'],['201'])

    def test_full_plan_catches_bad_neighbor(self):
        r=self.plan(drawing([GOOD,BAD]),{n:{'method':'angle','expected_angle_deg':120} for n in ['101','201']})
        self.assertEqual(r['verification'],'failed');self.assertEqual(r['coverage']['failed'],1)

    def test_full_good_plan(self):
        self.assertEqual(self.plan(drawing([GOOD]),{'101':{'method':'angle','expected_angle_deg':120}})['verification'],'passed_in_scope')

    def test_linear_and_bent(self):
        for point,expected in [((14.4,0),True),((7.2,12.47),False)]:
            r=tool.measure(drawing([[(0,0),(-14.4,0),point]]),['101'],180)[0]
            self.assertEqual(r['within_tolerance'],expected)

    def test_manual_review_requires_evidence(self):
        entry={'method':'manual','status':'passed','reason':'Special projection'}
        with self.assertRaises(ValueError):self.plan(drawing([GOOD]),{'101':entry})
        entry['evidence']='Reviewed native stereobond and connection directions in current figure'
        r=self.plan(drawing([GOOD]),{'101':entry});self.assertEqual(r['coverage']['manual_reviews'],1)

    def test_stale_plan_rejected(self):
        root=drawing([GOOD]);plan=tool.inventory(root,'old')
        with self.assertRaises(ValueError):tool.audit_plan(root,'new',plan)

    def test_scope_is_explicit(self):
        root=drawing([GOOD,BAD]);plan=tool.inventory(root,'hash',['100'])
        plan['entries']['101']={'method':'angle','expected_angle_deg':120}
        r=tool.audit_plan(root,'hash',plan)
        self.assertEqual(r['scope_fragments'],['100']);self.assertEqual(r['verification'],'passed_in_scope')

    def test_nan_and_infinite_coordinates_rejected(self):
        for value in ('nan','inf','-inf'):
            code,r=self.cli(drawing([[(0,0),(value,0),(0,14.4)]]),'--centers','101')
            self.assertEqual(code,2);self.assertEqual(r['verification'],'invalid_input')

    def test_zero_length_rejected(self):
        with self.assertRaises(ValueError):tool.measure(drawing([[(0,0),(0,0),(1,0)]]),['101'])

    def test_extreme_finite_coordinates_stable(self):
        for length in (1e-200,1e200):
            r=tool.measure(drawing([[(0,0),(length,0),(0,length)]]),['101'],90)[0]
            self.assertAlmostEqual(r['angles'][0]['angle_deg'],90)

    def test_overflow_difference_rejected(self):
        with self.assertRaises(ValueError):tool.measure(drawing([[(-1e308,0),(1e308,0),(0,1)]]),['101'])

    def test_invalid_bonds_rejected(self):
        for kind in ('missing','duplicate'):
            root=drawing([GOOD]);f=root.find('page/fragment')
            if kind=='missing':f.find('b').set('E','999')
            else:f.append(copy.deepcopy(f.find('b')))
            with self.assertRaises(ValueError):tool.graph(root)

    def test_missing_coordinate_rejected(self):
        root=drawing([GOOD]);root.find('.//n').attrib.pop('p')
        with self.assertRaises(ValueError):tool.graph(root)

    def test_hidden_expansion_not_counted(self):
        root=drawing([GOOD]);node=root.find('.//n[@id="102"]')
        hidden=ET.SubElement(node,'fragment',id='999')
        ET.SubElement(hidden,'n',id='888',p='nan nan')
        self.assertEqual(set(tool.inventory(root,'hash')['entries']),{'101'})

    def test_duplicate_center_rejected(self):
        with self.assertRaises(ValueError):tool.measure(drawing([GOOD]),['101','101'])

    def test_invalid_options_rejected(self):
        for expected,tolerance in [(float('nan'),1),(120,float('inf')),(120,-1),(0,1)]:
            with self.assertRaises(ValueError):tool.measure(drawing([GOOD]),['101'],expected,tolerance)

    def test_inventory_plan_cli_and_exit_codes(self):
        root=drawing([GOOD]);code,plan=self.cli(root,'--inventory')
        self.assertEqual(code,0)
        pp=Path(self.temp.name)/'plan.json';pp.write_text(json.dumps(plan),encoding='utf8')
        code,r=self.cli(root,'--plan',str(pp));self.assertEqual(code,3)
        plan['entries']['101']={'method':'angle','expected_angle_deg':120}
        pp.write_text(json.dumps(plan),encoding='utf8')
        code,r=self.cli(root,'--plan',str(pp));self.assertEqual(code,0)
        self.assertEqual(r['verification'],'passed_in_scope')

    def test_source_overwrite_rejected(self):
        code,r=self.cli(drawing([GOOD]),'--inventory','--output',str(self.path))
        self.assertEqual(code,2)

    def test_no_centers_not_reported_as_passed(self):
        self.assertEqual(self.plan(drawing([[(-1,0),(1,0)]]))['verification'],'no_angle_centers')


if __name__=='__main__':
    unittest.main(verbosity=2)
