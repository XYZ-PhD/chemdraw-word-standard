"""Exercise task-local temporary storage without modifying existing files."""
import os
from pathlib import Path
import tempfile


def probe_temp_parent(parent=None):
    parent = Path(parent or os.environ.get('CHEMDRAW_TEST_TMP') or tempfile.gettempdir()).resolve()
    folder = probe = None
    try:
        if not parent.is_dir():
            raise OSError('directory does not exist')
        folder = Path(tempfile.mkdtemp(prefix='chemdraw-probe-', dir=parent)).resolve()
        if not folder.is_relative_to(parent):
            raise OSError('temporary directory escaped the selected parent')
        probe = folder / 'write-read-delete.bin'
        expected = b'ChemDraw temporary storage probe\x00\xff'
        probe.write_bytes(expected)
        if probe.read_bytes() != expected:
            raise OSError('temporary file read-back differs')
        probe.unlink()
        folder.rmdir()
        return parent
    except OSError as error:
        raise RuntimeError(
            f'Temporary storage preflight failed at {parent}: {error}. '
            'Set CHEMDRAW_TEST_TMP to a writable task directory; creation, writing, reading and deletion are required.'
        ) from error
    finally:
        if folder is not None and folder.is_relative_to(parent):
            try:
                if probe is not None:
                    probe.unlink(missing_ok=True)
                if folder.exists():
                    folder.rmdir()
            except OSError:
                pass  # Preserve the original actionable failure.
