"""Bounded Windows adapter launcher. Only the child PowerShell runner is stopped on timeout."""
import argparse
import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys


def execute(command,timeout=180):
    if timeout<=0:raise ValueError('Timeout must be positive')
    try:
        r=subprocess.run(command,capture_output=True,timeout=timeout)
        return {'runner_status':'completed' if r.returncode==0 else 'failed','exit_code':r.returncode,
                'stdout':r.stdout.decode('utf-8',errors='replace'),'stderr':r.stderr.decode('utf-8',errors='replace')}
    except subprocess.TimeoutExpired as e:
        return {'runner_status':'timeout','exit_code':2,'stdout':(e.stdout or b'').decode('utf-8',errors='replace'),
                'boundary':'The child runner was stopped. Word/ChemDraw are NOT terminated by process name. Inspect native-run.json, then close only identified task documents; do not start duplicate runs while those documents are unresolved.'}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('manifest',type=Path);p.add_argument('output_directory',type=Path)
    p.add_argument('--timeout',type=int,default=180);a=p.parse_args()
    try:
        shell=shutil.which('powershell.exe')
        if platform.system()!='Windows' or not shell:raise ValueError('Windows PowerShell and registered native applications are required')
        if a.output_directory.exists():raise ValueError('Use a new output directory')
        manifest=a.manifest.resolve(strict=True)
        r=execute([shell,'-NoProfile','-ExecutionPolicy','Bypass','-File',str(Path(__file__).with_name('embed_word.ps1')),
                   '-InputManifest',str(manifest),'-OutputDirectory',str(a.output_directory.resolve())],a.timeout)
        if a.output_directory.is_dir():
            (a.output_directory/'launcher.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps(r,ensure_ascii=False,indent=2));return r['exit_code']
    except (OSError,ValueError) as e:
        print(json.dumps({'verification':'invalid_input','error':str(e)},ensure_ascii=False));return 2


if __name__=='__main__':sys.exit(main())
