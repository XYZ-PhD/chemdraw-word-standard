"""Conservative visible-CDXML helpers. No ChemDraw/Word validation is implied."""
from collections import deque
import hashlib
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

ORGANIC = {1, 5, 6, 7, 8, 9, 14, 15, 16, 17, 35, 53}


def visible(element):
    yield element
    if element.tag == 'n':
        for child in element.findall('t'):
            yield from visible(child)
        return
    for child in element:
        yield from visible(child)


def label_text(element):
    return ''.join(''.join(s.itertext()) for s in element.findall('s'))


def order(bond):
    value = bond.get('Order', '1')
    try:
        value = float(value)
    except ValueError:
        return None
    return value if math.isfinite(value) and value in (1, 1.5, 2, 3) else None


def native_me(node):
    text = node.find('t')
    if text is None or label_text(text) != 'Me':
        return False
    fragments = node.findall('fragment')
    if (node.get('NodeType') != 'Nickname' or len(fragments) != 1
            or node.get('Isotope','0')!='0' or node.get('Charge','0')!='0'
            or node.get('Radical','0')!='0' or node.get('NumHydrogens','3')!='3'):
        return False
    fragment = fragments[0]
    atoms = fragment.findall('n')
    carbon = [n for n in atoms if n.get('NodeType', 'Element') == 'Element']
    external = [n for n in atoms if n.get('NodeType') == 'ExternalConnectionPoint']
    if len(carbon) != 1 or len(external) != 1 or len(atoms) != 2:
        return False
    c = carbon[0]
    bonds = fragment.findall('b')
    return (c.get('Element', '6') == '6' and c.get('Isotope', '0') == '0'
            and c.get('Charge', '0') == '0' and c.get('Radical','0')=='0' and c.get('NumHydrogens', '3') == '3'
            and len(bonds) == 1 and order(bonds[0]) == 1
            and {bonds[0].get('B'), bonds[0].get('E')} == {c.get('id'), external[0].get('id')})


def element_number(node):
    if node.get('NodeType', 'Element') == 'Element':
        return int(node.get('Element', '6'))
    return 6 if native_me(node) else None


class Drawing:
    def __init__(self, root, scope=None):
        from measure_bond_angles import graph
        if root.tag != 'CDXML':
            raise ValueError('Expected a CDXML document (binary CDX is not supported)')
        self.root = root
        self.nodes, self.adjacency, self.scope = graph(root, scope)
        self.parents = {c: e for e in root.iter() for c in e}
        self.fragments = {f.get('id'): f for f in visible(root) if f.tag == 'fragment' and f.get('id') in self.scope}
        self.bonds = {}
        for fragment in self.fragments.values():
            for bond in fragment.findall('b'):
                self.bonds[frozenset((bond.get('B'), bond.get('E')))] = bond
        self.objects = {}
        for e in visible(root):
            if e.tag in ('font','fonttable','color','colortable'):
                continue  # Font/color IDs occupy separate lookup namespaces.
            key = e.get('id')
            if key and key != '0':
                if key in self.objects:
                    raise ValueError('Duplicate visible object ID: ' + key)
                self.objects[key] = e
        self.fonts = {f.get('id'): f.get('name') for f in root.findall('fonttable/font')}
        self.texts = []
        for t in visible(root):
            if t.tag != 't':
                continue
            parent = self.parents.get(t)
            if parent is not None and parent.tag == 'n':
                if parent.get('id') not in self.nodes:
                    continue
                key = 'node:' + parent.get('id')
            else:
                key = t.get('id')
                ancestor = parent
                while ancestor is not None and ancestor.tag != 'fragment':
                    ancestor = self.parents.get(ancestor)
                if ancestor is not None and ancestor.get('id') not in self.scope:
                    continue
            self.texts.append((key, t, parent is not None and parent.tag == 'n'))

    @classmethod
    def read(cls, path, scope=None):
        data = Path(path).read_bytes()
        return cls(ET.fromstring(data), scope), hashlib.sha256(data).hexdigest()

    def inherited(self, e, attribute, default=None):
        while e is not None:
            if e.get(attribute) is not None:
                return e.get(attribute)
            e = self.parents.get(e)
        return default

    def runs(self, text, atom=False):
        prefix = 'Label' if atom else 'Caption'
        out = []
        for s in text.findall('s'):
            font = self.inherited(s, 'font') or self.inherited(s, prefix + 'Font')
            size = self.inherited(s, 'size') or self.inherited(s, prefix + 'Size')
            face = self.inherited(s, 'face') or self.inherited(s, prefix + 'Face', '96' if atom else '0')
            color = self.inherited(s, 'color', '0')
            out.append({'text': ''.join(s.itertext()), 'font': self.fonts.get(font),
                        'size': None if size is None else float(size), 'face': int(face),
                        'color': self.color(color)})
        return out

    def color(self, index):
        if index == '0': return (0.0, 0.0, 0.0)
        if index == '1': return (1.0, 1.0, 1.0)
        colors = self.root.findall('colortable/color')
        try:
            i = int(index) - 2
            if i < 0: return None
            return tuple(float(colors[i].get(c)) for c in ('r', 'g', 'b'))
        except (ValueError, TypeError, IndexError):
            return None

    def shortest(self, start, end, excluded):
        queue = deque([(start, [start])]); seen = {start}
        while queue:
            node, path = queue.popleft()
            for other in self.adjacency[node]:
                if frozenset((node, other)) == excluded or other in seen:
                    continue
                if other == end: return path + [other]
                seen.add(other); queue.append((other, path + [other]))
        return None

    def cyclic_edges(self):
        if not hasattr(self, '_cycles'):
            self._cycles = {pair: self.shortest(*tuple(pair), pair) for pair in self.bonds}
        return self._cycles

    def special_fragment(self, fid):
        for n in self.fragments[fid].findall('n'):
            element = element_number(n)
            if element is not None and element not in ORGANIC:
                return 'metal_or_coordination_fragment'
            if element == 5:
                return 'boron_or_cluster_review'
            if len(self.adjacency[n.get('id')]) > 4:
                return 'high_connectivity_projection'
        for b in self.fragments[fid].findall('b'):
            if order(b) is None or b.get('Display', 'Solid') in ('Dash', 'Dot', 'Dative'):
                return 'unsupported_or_coordination_bond'
        return None

    def recommend(self, key):
        n = self.nodes[key]['node']; neighbors = self.adjacency[key]
        fid = self.nodes[key]['fragment']
        reason = self.special_fragment(fid)
        if reason: return {'method': 'pending', 'reason': reason}
        incident = [self.bonds[frozenset((key, x))] for x in neighbors]
        if any('Wedge' in b.get('Display', '') or b.get('Display', '').startswith('Hash') for b in incident):
            return {'method': 'pending', 'reason': 'stereochemical_projection'}
        if any(element_number(self.nodes[x]['node']) is None for x in [key] + neighbors):
            return {'method': 'pending', 'reason': 'unresolved_nickname_or_query'}
        if any(self.nodes[x]['node'].get('NodeType', 'Element') not in ('Element', 'Nickname') for x in [key] + neighbors):
            return {'method': 'pending', 'reason': 'query_or_generic_node'}
        cycles = self.cyclic_edges()
        touching = [cycles[frozenset((key, x))] for x in neighbors if cycles[frozenset((key, x))]]
        if touching:
            cycle_sets = {frozenset(p) for p in touching}
            ring_component={key}; queue=[key]
            while queue:
                x=queue.pop()
                for y in self.adjacency[x]:
                    if cycles[frozenset((x,y))] and y not in ring_component:
                        ring_component.add(y);queue.append(y)
            if len(ring_component)!=6:
                return {'method':'pending','reason':'small_fused_bridged_or_non_six_ring'}
            if len(cycle_sets) != 1 or any(len(p) != 6 for p in touching):
                return {'method': 'pending', 'reason': 'small_fused_bridged_or_non_six_ring'}
            ring = next(iter(cycle_sets))
            ring_bonds = [b for pair,b in self.bonds.items() if pair <= ring]
            aromatic = (len(ring_bonds) == 6 and all(element_number(self.nodes[x]['node']) == 6 for x in ring)
                        and (all(order(b) == 1.5 for b in ring_bonds) or
                             all(sorted(order(self.bonds[frozenset((x,y))]) for y in self.adjacency[x] if y in ring) == [1,2] for x in ring)))
            if not aromatic:
                return {'method': 'pending', 'reason': 'ring_requires_template_review'}
            expected, why = 120, 'isolated_six_member_carbon_aromatic_ring'
        elif len(neighbors) == 2 and element_number(n) == 6 and sorted(order(b) for b in incident) == [1,3]:
            expected, why = 180, 'carbon_single_plus_triple_bond'
        elif len(neighbors) in (2,3) and element_number(n) in (6,7) and all(order(b) in (1,2) for b in incident):
            if n.get('Charge','0') != '0' or n.get('Radical','0') != '0':
                return {'method': 'pending', 'reason': 'charged_or_radical_center'}
            expected, why = 120, 'ordinary_acyclic_C_or_N_2D_layout'
        else:
            return {'method': 'pending', 'reason': 'unsupported_center_geometry'}
        return {'method': 'angle', 'expected_angle_deg': expected, 'tolerance_deg': 1.0,
                'suggestion_basis': why, 'suggestion_version': 1}

    def fragment_center(self, fid):
        points=[self.nodes[n.get('id')]['point'] for n in self.fragments[fid].findall('n')]
        if not points: raise ValueError('Empty fragment has no placement anchor')
        return tuple((min(p[i] for p in points)+max(p[i] for p in points))/2 for i in (0,1))

    def chemical_graph(self, fid):
        """Exact attributed graph; IDs/positions omitted, Me expanded, unsupported cases explicit."""
        atoms={}; edges={}; unsupported=[]
        fragment=self.fragments[fid]
        for n in fragment.findall('n'):
            key=n.get('id'); e=element_number(n)
            if e is None or e not in ORGANIC or n.get('NodeType','Element') not in ('Element','Nickname'):
                unsupported.append(key)
            vals=tuple((a,n.get(a,d)) for a,d in [('Charge','0'),('Isotope','0'),('Radical','0')])
            stereo=n.get('AS','N')
            # A CIP label may be calculated only after OLE activation. Do not treat
            # its absence as proof of achirality or claim a stereochemical identity test.
            if stereo!='N' or n.get('Geometry') not in (None,'Unknown'): unsupported.append(key)
            bond_orders=[order(self.bonds[frozenset((key,x))]) for x in self.adjacency[key]]
            h=n.get('NumHydrogens')
            if native_me(n): h='3'
            elif h is None and e in (6,7,8) and all(v is not None and v.is_integer() for v in bond_orders):
                h=str(max(0,{6:4,7:3,8:2}[e]-int(sum(bond_orders))))
            atoms[key]=(e,vals,h,stereo)
        for b in fragment.findall('b'):
            if order(b) is None: unsupported.append(b.get('id'))
            # Directional wedge identity is retained. Rewritten stereo representation needs review.
            a,z=b.get('B'),b.get('E'); display=b.get('Display','Solid')
            if 'Wedge' in display or display.startswith('Hash') or b.get('BS','N')!='N':
                unsupported.append(b.get('id'))
            if order(b)==2 and len(self.adjacency[a])>1 and len(self.adjacency[z])>1:
                path=self.cyclic_edges()[frozenset((a,z))]
                if path is None or len(path)!=6 or any(element_number(self.nodes[x]['node'])!=6 for x in path):
                    unsupported.append(b.get('id'))  # Potential alkene E/Z needs explicit stereo review.
            edges[(a,z)]=(order(b),display)
            edges[(z,a)]=(order(b),display.replace('Begin','TEMP').replace('End','Begin').replace('TEMP','End'))
        return atoms,edges,unsupported


def isomorphic(left, right, limit=100000):
    la,le,lu=left; ra,re,ru=right
    if lu or ru: return None
    if len(la)!=len(ra) or len(le)!=len(re): return False
    candidates={a:[b for b in ra if la[a]==ra[b] and sum(x==a for x,y in le)==sum(x==b for x,y in re)] for a in la}
    if any(not c for c in candidates.values()): return False
    sequence=sorted(la,key=lambda a:len(candidates[a])); steps=0
    def search(mapping,used):
        nonlocal steps
        steps+=1
        if steps>limit: raise RuntimeError('graph comparison budget exceeded')
        if len(mapping)==len(sequence): return True
        a=sequence[len(mapping)]
        for b in candidates[a]:
            if b in used: continue
            if any(le.get((a,x))!=re.get((b,y)) or le.get((x,a))!=re.get((y,b)) for x,y in mapping.items()): continue
            mapping[a]=b
            if search(mapping,used|{b}): return True
            del mapping[a]
        return False
    try: return search({},set())
    except RuntimeError: return None


def safe_report(report, output, inputs):
    if output:
        out=Path(output)
        for p in map(Path,inputs):
            if out.resolve()==p.resolve() or (out.exists() and p.exists() and out.samefile(p)):
                raise ValueError('Report must not overwrite any input file')
        out.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False))


def summarize(items):
    counts={s:sum(x['status']==s for x in items) for s in ('passed','failed','pending','not_applicable')}
    status='failed' if counts['failed'] else 'pending' if counts['pending'] else 'passed' if counts['passed'] else 'not_applicable'
    return {'status':status,'counts':counts,'items':items}
