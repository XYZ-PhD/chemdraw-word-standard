import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
from cdxml_model import Drawing,isomorphic,native_me
from lint_cdxml import lint,draft_roles
from check_correspondence import check
from measure_bond_angles import inventory,audit_plan
from temp_probe import probe_temp_parent

ASSETS=Path(__file__).resolve().parents[1]/'assets'/'examples'


def scope():
    return Drawing(ET.parse(ASSETS/'scope-expanded.cdxml').getroot())


def mapping():
    return {'schema_version':1,'reference':{'confirmed_by':'Bundled source definitions: 26 para-Me 75%; 27 para-F 60%'},
            'entries':[{'key':'para_me','fragment_id':'2','label_id':'34','number':'26','yield':'75%','marker_ids':['18']},
                       {'key':'para_f','fragment_id':'35','label_id':'63','number':'27','yield':'60%','marker_ids':[]}]}


class CDXMLChecks(unittest.TestCase):
    def test_native_me_cannot_hide_a_radical(self):
        d=scope();n=d.nodes['27']['node'];n.set('Radical','2')
        self.assertFalse(native_me(n));self.assertEqual(lint(d)['methyl_representation']['status'],'failed')

    def test_atom_label_cannot_be_declared_a_compound_caption(self):
        d=scope();key=d.nodes['15']['node'].find('t').get('id')
        with self.assertRaises(ValueError):lint(d,{'number_ids':[key]})

    def test_stereochemistry_with_or_without_calculated_cip_is_pending(self):
        d=Drawing(ET.parse(ASSETS/'geometry-cases.cdxml').getroot());a=d.chemical_graph('84')
        d.nodes['97']['node'].set('AS','S')
        self.assertIsNone(isomorphic(a,d.chemical_graph('84')))

    def test_potential_alkene_ez_cannot_silently_pass_identity(self):
        d=scope();d.fragments['2'].find('b').set('BS','E')
        self.assertIsNone(isomorphic(d.chemical_graph('2'),d.chemical_graph('2')))

    def test_font_ids_have_a_separate_namespace(self):
        d=scope();self.assertIn('3',d.fonts);self.assertIn('3',d.objects)

    def test_qualified_yield_is_preserved_and_marked_for_review(self):
        d=scope();d.objects['34'].findall('s')[-1].text=' <5% (NMR)'
        self.assertEqual(lint(d,{'number_ids':['34','63']})['number_formats']['status'],'pending')

    def test_cd3_is_not_an_ordinary_methyl_conversion(self):
        d=scope();n=d.nodes['27']['node'];n.find('t/s').text='CD3'
        self.assertEqual(lint(d)['methyl_representation']['status'],'pending')

    def test_malformed_roles_and_manifest_rejected(self):
        with self.assertRaises(ValueError):lint(scope(),{'number_ids':'34'})
        with self.assertRaises(ValueError):check([],scope(),scope())
        with self.assertRaises(ValueError):check({'schema_version':1,'entries':[1],'reference':{'confirmed_by':'source'}},scope(),scope())
        m=mapping();m['reference']['confirmed_by']=True
        with self.assertRaises(ValueError):check(m,scope(),scope())
        m=mapping();m['entries'][0]['marker_ids']='18'
        with self.assertRaises(ValueError):check(m,scope(),scope())

    def test_ordinary_example_rules_pass_with_declared_roles(self):
        results=lint(scope(),{'number_ids':['34','63']})
        self.assertTrue(all(x['status']=='passed' for x in results.values()))

    def test_coordinates_override_document_bond_default(self):
        d=scope();n=d.nodes['27']['node'];n.set('p','20 51.53')
        self.assertEqual(lint(Drawing(d.root))['bond_lengths']['status'],'failed')

    def test_actual_font_override_detected(self):
        d=scope();d.nodes['15']['node'].find('t/s').set('size','8')
        self.assertEqual(lint(d)['text_styles']['status'],'failed')

    def test_inherited_font_and_size_are_resolved(self):
        d=scope();run=d.nodes['15']['node'].find('t/s');run.attrib.pop('font');run.attrib.pop('size')
        results=lint(d,{'number_ids':['34','63']})
        self.assertEqual(results['text_styles']['status'],'passed')

    def test_chemical_superscript_smaller_size_is_allowed(self):
        d=Drawing(ET.parse(ASSETS/'geometry-cases.cdxml').getroot())
        d.nodes['126']['node'].find('t/s').set('size','7')
        result=lint(d)
        self.assertEqual(result['text_styles']['counts']['failed'],0)
        self.assertEqual(result['methyl_representation']['counts']['failed'],0)

    def test_arbitrary_small_formula_label_is_not_subscript_exception(self):
        d=scope();s=d.nodes['15']['node'].find('t/s');s.set('size','7');s.set('face','96')
        self.assertEqual(lint(d)['text_styles']['status'],'failed')

    def test_terminal_methyl_requires_native_nickname(self):
        d=scope();n=d.nodes['27']['node'];n.attrib.pop('NodeType');n.remove(n.find('fragment'));n.remove(n.find('t'))
        self.assertEqual(lint(Drawing(d.root))['methyl_representation']['status'],'failed')

    def test_fake_me_does_not_hide_isotope(self):
        d=scope();n=d.nodes['27']['node'];carbon=[x for x in n.find('fragment').findall('n') if x.get('NodeType')!='ExternalConnectionPoint'][0]
        carbon.set('Isotope','13')
        self.assertFalse(native_me(n));self.assertEqual(lint(d)['methyl_representation']['status'],'failed')

    def test_alkene_alkyne_nitrile_isotope_are_not_methyl(self):
        d=Drawing(ET.parse(ASSETS/'geometry-cases.cdxml').getroot())
        self.assertEqual(lint(d)['methyl_representation']['counts']['failed'],0)

    def test_number_comma_bold_and_yield_regular(self):
        d=scope();t=d.objects['34'];t.find('s').set('face','0')
        self.assertEqual(lint(d,{'number_ids':['34','63']})['number_formats']['status'],'failed')

    def test_no_yield_number_no_comma_and_idempotent_read(self):
        d=scope();t=d.objects['34'];t.find('s').text='26'
        for s in list(t.findall('s'))[1:]:t.remove(s)
        before=ET.tostring(d.root)
        self.assertEqual(lint(d,{'number_ids':['34','63']})['number_formats']['status'],'passed')
        self.assertEqual(ET.tostring(d.root),before)
        t.find('s').text='26, '
        self.assertEqual(lint(d,{'number_ids':['34','63']})['number_formats']['status'],'failed')

    def test_unknown_caption_is_not_automatically_a_compound_number(self):
        result=lint(scope())
        self.assertEqual(result['number_formats']['status'],'pending')

    def test_same_mapping_passes(self):
        d=scope();self.assertEqual(check(mapping(),d,d)['correspondence']['status'],'passed')

    def test_swapped_yields_fail_while_format_passes(self):
        ref=scope();d=scope();a=d.objects['34'].findall('s')[-1];b=d.objects['63'].findall('s')[-1]
        a.text,b.text=b.text,a.text
        self.assertEqual(lint(d,{'number_ids':['34','63']})['number_formats']['status'],'passed')
        self.assertEqual(check(mapping(),ref,d)['correspondence']['status'],'failed')

    def test_swapped_numbers_fail_while_format_passes(self):
        ref=scope();d=scope();a=d.objects['34'].find('s');b=d.objects['63'].find('s');a.text,b.text=b.text,a.text
        self.assertEqual(lint(d,{'number_ids':['34','63']})['number_formats']['status'],'passed')
        self.assertEqual(check(mapping(),ref,d)['correspondence']['status'],'failed')

    def test_swapped_label_positions_require_review(self):
        ref=scope();d=scope();a=d.objects['34'];b=d.objects['63'];ap=a.get('p');a.set('p',b.get('p'));b.set('p',ap)
        self.assertEqual(check(mapping(),ref,d)['correspondence']['status'],'pending')

    def test_changed_isotope_is_a_different_structure(self):
        ref=scope();d=scope();d.fragments['35'].find('n').set('Isotope','13')
        self.assertEqual(check(mapping(),ref,d)['correspondence']['status'],'failed')

    def test_marker_color_change_is_detected(self):
        ref=scope();d=scope();d.nodes['18']['node'].find('t/s').set('color','4')
        self.assertEqual(check(mapping(),ref,d)['correspondence']['status'],'failed')

    def test_reference_cannot_be_silently_reinterpreted(self):
        m=mapping();m['entries'][0]['yield']='60%'
        with self.assertRaisesRegex(ValueError,'conflicts'):check(m,scope(),scope())

    def test_ids_and_translation_are_not_chemical_identity(self):
        d=scope();f=copy.deepcopy(d.fragments['35'])
        for n in f.findall('n'):
            n.set('id','x'+n.get('id'));n.set('p',' '.join(str(float(v)+20) for v in n.get('p').split()))
        for b in f.findall('b'):
            b.set('B','x'+b.get('B'));b.set('E','x'+b.get('E'));b.set('id','x'+b.get('id'))
        r=ET.Element('CDXML');page=ET.SubElement(r,'page',id='page');page.append(f)
        other=Drawing(r)
        self.assertTrue(isomorphic(d.chemical_graph('35'),other.chemical_graph('35')))

    def test_inventory_reduces_manual_entries_without_claiming_pass(self):
        d=Drawing(ET.parse(ASSETS/'labels-wide.cdxml').getroot())
        p=inventory(d.root,'hash',auto=True)
        self.assertEqual(p['verification'],'inventory_only')
        self.assertEqual(sum(e['method']=='angle' for e in p['entries'].values()),34)
        self.assertEqual(audit_plan(d.root,'hash',p)['verification'],'incomplete')

    def test_auto_angles_still_catch_wrong_n(self):
        d=Drawing(ET.parse(ASSETS/'geometry-negative-control.cdxml').getroot())
        report=audit_plan(d.root,'hash',inventory(d.root,'hash',auto=True))
        self.assertEqual(report['verification'],'failed')
        self.assertEqual([c['center'] for c in report['centers'] if c['status']=='failed'],['9'])

    def test_geometry_special_cases_remain_pending_and_sp_is_linear(self):
        d=Drawing(ET.parse(ASSETS/'geometry-cases.cdxml').getroot())
        p=inventory(d.root,'hash',auto=True)
        self.assertEqual(sum(e['method']=='pending' for e in p['entries'].values()),4)
        self.assertTrue(any(e.get('expected_angle_deg')==180 for e in p['entries'].values()))

    def test_cli_lint_does_not_overwrite_input(self):
        parent=probe_temp_parent()
        with tempfile.TemporaryDirectory(dir=parent,prefix='lint-test-') as name:
            path=Path(name)/'input.cdxml';path.write_bytes((ASSETS/'scope-expanded.cdxml').read_bytes());before=path.read_bytes()
            r=subprocess.run([sys.executable,'-B',str(Path(__file__).with_name('lint_cdxml.py')),str(path),'--output',str(path)],capture_output=True,text=True,encoding='utf-8',timeout=15)
            self.assertEqual(r.returncode,2);self.assertEqual(path.read_bytes(),before)

class DraftRolesAndEmptyDrawing(unittest.TestCase):
    def test_draft_roles_match_confirmed_roles_where_patterns_are_unambiguous(self):
        for name in ('labels-wide','labels-narrow','scope-expanded','scope-source'):
            with self.subTest(name=name):
                d,sha=Drawing.read(ASSETS/(name+'.cdxml'))
                confirmed=json.loads((ASSETS/(name+'.roles.json')).read_text(encoding='utf-8'))
                draft=draft_roles(d,sha)
                self.assertTrue(draft['draft']);self.assertEqual(draft['source_sha256'],sha)
                for field in ('number_ids','ordinary_text_ids','test_label_ids'):
                    self.assertEqual(sorted(draft[field]),sorted(confirmed[field]))

    def test_letter_prefixed_numbers_and_tagged_notes_are_flagged(self):
        d,sha=Drawing.read(ASSETS/'labels-wide.cdxml')
        notes={r['text']:r.get('note') for r in draft_roles(d,sha)['review']}
        self.assertIn('Letter prefix',notes['P8, 43%']);self.assertIsNone(notes['1a, 75%'])
        d,sha=Drawing.read(ASSETS/'geometry-cases.cdxml')
        draft=draft_roles(d,sha)
        self.assertEqual(draft['number_ids'],[]);self.assertEqual(len(draft['unassigned_ids']),6)

    def test_lint_refuses_unconfirmed_or_incomplete_drafts(self):
        d,sha=Drawing.read(ASSETS/'labels-wide.cdxml');draft=draft_roles(d,sha)
        with self.assertRaises(ValueError):lint(d,draft)
        draft.pop('draft');draft['unassigned_ids']=['33']
        with self.assertRaises(ValueError):lint(d,draft)
        draft['unassigned_ids']=[]
        self.assertEqual(lint(d,draft)['number_formats']['status'],'passed')

    def test_draft_cli_does_not_overwrite_existing_files(self):
        with tempfile.TemporaryDirectory(dir=probe_temp_parent()) as folder:
            out=Path(folder)/'roles.json';out.write_text('{}',encoding='utf-8')
            r=subprocess.run([sys.executable,'-B',str(Path(__file__).with_name('cdx_lint.py')),str(ASSETS/'labels-wide.cdxml'),
                              '--draft-roles',str(out)],capture_output=True,text=True)
            self.assertEqual(r.returncode,2);self.assertEqual(out.read_text(encoding='utf-8'),'{}')

    def test_empty_template_is_not_applicable_rather_than_invalid(self):
        template=Path(__file__).resolve().parents[1]/'assets'/'chemdraw-standard.cdxml'
        d,sha=Drawing.read(template)
        self.assertEqual({v['status'] for v in lint(d).values()},{'not_applicable'})
        self.assertEqual(audit_plan(d.root,sha,inventory(d.root,sha,auto=True))['verification'],'no_angle_centers')
        with self.assertRaises(ValueError):inventory(scope().root,'x',[])


if __name__=='__main__':unittest.main(verbosity=2)
