# 环境预检与原生交付流程

## 能力先实测

```text
python -B scripts/preflight.py --temp-dir TASK_TEMP --output environment.json
```

预检真正创建、写入、读回并删除本次测试文件，检查应用注册与可用导出程序；它不启动应用或证明授权/许可证可用。临时路径不可写时一开始明确失败；可将当前进程的 `CHEMDRAW_TEST_TMP` 指向任务可写目录，不修改全局环境。

环境承诺见 [入口](../SKILL.md)。无原生软件时只能交付候选 CDXML 和未验证清单，利用可用可信渲染器提供预览；没有渲染器就明确预览亦缺失，不能伪造截图或把阶段成果叫最终原生文件。仅有 ChemDraw 时完成原生保存重开；Word 缺失不凭 ZIP 文件宣称 OLE 可编辑。两者都有时继续以下流程。

## 制作与嵌入

1. 在独立目录保存源副本，记录哈希、图号、对象和结构—编号—产率—标记对应关系。检查实际值；保留原件和原有数据。
2. ChemDraw 保存为 CDX，验证存在、非空、格式签名，再实际重开并导出 CDXML，重新核验语义和实际几何。必要时使用整个路径均为 ASCII 的暂存目录，最终复制后核对哈希。
3. 用真实嵌入式 ChemDraw OLE 放入 Word，遵守 [默认插入尺寸](word-display-and-qa.md#默认插入尺寸)。不依赖本地外链，不把整幅光栅图包装成可编辑结构。更新同版显示缓存。
4. 保存并关闭 Word 后检查文件，再只读重开，复核对象数、宽高、分页并导出 PDF。正常激活每个范围内的 OLE，取得原生内容；检查源、原生内容和缓存指向同一版。
5. 从最终 Word 双击对象，对照页面预览、原生图及最终 PDF。逐页检查完整性、比例、文字、箭头、标记、裁剪和分页。内容、缓存、激活、页面是独立证据。只读复核结束后确认交付文件哈希未变。

首次制作或排障读 [实测易错点](native-authoring-pitfalls.md)。缺少 LibreOffice 时记录原因，使用 Word 原生 PDF 导出，再渲染 PDF 检查；缺少视觉验收能力就标未验证。

## Windows 复用工具

工具 `run_native.py` 调用系统 Windows PowerShell 与 COM，不依赖 pywin32。`embed_word.ps1` 当前验证组合为 Windows 11、64 位 ChemDraw **25.0.2.14**、Word **16.0.14334**。应用注册类型为 `ChemDraw_x64.Application` 与 `ChemDraw_x64.Document.6.0`；其他版本需运行同样的实测，不自动继承通过结论。

输入清单使用实际文件路径：

```json
{"figures":[{"id":"wide","source":"C:/task/figure.cdxml"},{"id":"narrow","source":"C:/task/second.cdx"}]}
```

```text
python -B scripts/run_native.py figures.json C:/task/new-output --timeout 180
python -B scripts/check_word_sizes.py C:/task/new-output/native-run.json
python -B scripts/inspect_word_package.py C:/task/new-output/verification.docx
```

输出目录必须不存在且完整路径为 ASCII。工具复制输入、保存重开原生文件、新建 A4/正常页边距的测试/组图 Word，以默认宽高插入，记录宽高与软件版本，保存关闭后只读重开、激活 OLE 导出原生内容并生成 PDF。该工具用于新建文档；已有论文须在工作副本中定位相应对象更新，不能用新建测试稿替代原稿返修。

工具先建立 Word 文件再插入 OLE，COM 文件路径显式转换为字符串；Word 关闭后才读取字节或计算哈希。不会设置对象宽高/缩放；过宽时失败并要求回原生图重排。分页和可能的自动适配仍需最终显示核验，不能因为“没有写 Width”就宣称比例正确。

API 成功状态为 `native_api_completed_visual_review_pending`；随后必须做 UI 双击和 PDF 页面检查。报告不自动升级成全部通过。只关闭本次打开的文档；ChemDraw 可能是共享服务，释放句柄而不 Quit 全应用。新 Word 若已有其他文档则拒绝复用；清理时仅在本次实例无文档时退出。

调用失败记录 `native-run.json` 的阶段和错误，保留部分输出供诊断。默认 180 秒超时只停止自己的 PowerShell 子进程，不按应用名杀 Word/ChemDraw；先定位任务文档与提示、确认归属再清理，不继续启动重复实例。不改变用户安全设置、模板、插件或其他文档来强行通过测试。

输出可以复制到中文交付目录，复制前后比对哈希。交付说明分别记录原生标准化、布局变化、Word 放置尺寸变化、已完成及未完成的证据；不能用“没有拖拽”代替尺寸证明。
