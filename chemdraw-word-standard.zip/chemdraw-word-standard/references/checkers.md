# 只读检查工具与证据边界

Python 工具只用标准库（Python 3.10+），不修改输入；报告不能覆盖源、计划、角色或对应表。二进制 CDX 需先由 ChemDraw 导出 CDXML。以下命令从技能根目录运行；实际任务的文件路径自行替换。

## 四项 CDXML 检查

```text
python -B scripts/cdx_lint.py drawing.cdxml --roles roles.json --output lint.json
```

`cdx_lint.py` 为公开入口，`lint_cdxml.py` 为实现。报告分别列出键长、字体、甲基表示、编号格式的 `passed / failed / pending / not_applicable`。不输出整图“全部合格”，不评价 Word 缓存、OLE 或 PDF。退出码：0 为所运行规则无失败/待复核，1 为失败，2 为输入无效，3 为待复核；不适用不算已检查通过。

普通 C–C 实际中心距目标 14.4 pt，默认工程容差 ±0.15 pt，可用 `--bond-tolerance` 覆盖。投影、簇、配位及楔线片段不按普通键长直接判定。字体读取继承与局部覆盖，普通文字按基线检查；显式上下标允许较小字号，Formula 样式本身不免除全部字号检查。Me 核对隐藏原生 CH3 片段和连接，保留烯/炔/腈及同位素例外。其他缩写、查询和复杂同位素表示不能自动证明时标待复核。

自动识别特殊片段只是保守启发式，不能识别所有椅式/透视画法或用默认碳节点画出的图形化簇。执行前结合图像确认这些对象，在角色表 `excluded_fragments` 中给出片段 ID 和具体理由，使其列为待复核；不能只看 C 元素身份就把投影边解释为普通键。

角色表绑定确切文件哈希，例如：

```json
{"source_sha256":"本次源文件SHA256","number_ids":["34","63"],"ordinary_text_ids":[],"test_label_ids":[],"excluded_fragments":{}}
```

各列表明确声明文字角色，不能把条件数字或 E1 测试标识误当化合物编号。排除片段必须附具体理由，仍显示待复核。保留产率限定信息（如 `<5%`、NMR），复杂格式留人工核对，不为了通过脚本删掉限定。源文件重存后角色表也需重新核实并绑定。

## 独立对应关系检查

```text
python -B scripts/check_correspondence.py expected.json drawing.cdxml --output correspondence.json
```

参考 [对应表示例](../assets/examples/scope-correspondence.json)。先从可信原稿/编号表确认每个结构的连接位点、编号、产率及标记，记录 `reference.file / sha256 / confirmed_by`；`entries` 指向参考结构片段、标签和标记 ID。禁止把待验收图自动抄成“正确答案”。示例数据不是用户实验数据。

支持普通元素连接图、键级、电荷、同位素、氢数和已验证 Me 展开；忽略对象 ID 与整体平移。复杂缩写、立体中心、潜在 E/Z、配位或无法唯一比较的图保留待复核，不冒充通用化学身份判定器。原生保存补算 CIP 字段不应被解释成已经证明结构改变；需比较连接、楔线/构型及实际几何。

默认复用对象 ID，并核对标签相对结构的锚点。重新排版或 ID 改变时提供 `--bindings candidate-bindings.json`，包含候选源 `source_sha256` 与按对应表 key 编写的 `entries`，每项可给新的 `fragment_id / label_id / marker_ids`。改变锚点须独立人工核对并写 `association_review`。该文字是所提供的人工证据，脚本不证明它真实。重复绑定、缺失对象、参考哈希变化会拦截；未分配结构和改变的位置仍待复核。文本/原子标记比较内容和实际颜色，图形或箭头标记需视觉复核。

编号或产率对调的两份反例故意让格式和角度检查通过，由对应检查判失败。位置对调也会阻止自动通过。这三类证据不能互相替代。

## 角度与 Word 检查

- [角度工具与自动建议](bond-geometry.md)：清单、执行计划和局部测量有不同结论；平均值不能替代逐中心结果。
- `check_word_sizes.py native-run.json --output sizes.json`：只比较实际宽高及容差，不使用缩放字段，不证明有效边界/缓存尺度。
- `inspect_word_package.py final.docx --output package.json`：只盘点嵌入关系、缓存关联和哈希；OLE 声明和二进制文件存在不能证明可编辑。
- [原生嵌入流程](native-workflow.md)：必须另做重开、对象激活和 Word/PDF 视觉验收。
