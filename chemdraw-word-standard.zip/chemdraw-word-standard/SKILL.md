---
name: chemdraw-word-standard
description: "绘制、返修或检查可编辑 ChemDraw 化学结构图（CDX/CDXML）及其 Word 排版。用于画结构式、化学结构图、反应式/scheme、底物拓展、放进 Word、统一键长、键角、字号、Me、编号与产率、原生 OLE 和图间显示一致性。Draw, normalize or audit native ChemDraw structures, reaction schemes and editable Word figures. 不用于选择期刊风格、设计反应路线、预测产率或一般 Word 文字排版。"
---

# ChemDraw 与 Word 基础绘图标准

## 先界定修改与验收范围

使用用户最新指定的正确版本；保留原件，在工作副本上处理。只读审查不修改文件。局部返修按实际影响扩展验证，发现范围外旧问题时定位报告。

| 实际变化 | 必要检查范围 |
| --- | --- |
| 新绘、全篇规范化、跨图统一 | 全部目标图的结构、实际几何/文字、图内及图间显示 |
| 局部文字、编号、颜色或位置 | 修改对象及关联结构/数据；核对其他对象内容、缓存和放置参数未受影响 |
| 有效边界、缓存、宽高、裁剪或变换改变 | 重新校准所有受影响图，并与已验证参照比较 |
| 共享页设置或全局布局改变 | 所有受影响对象与页面 |

缩小范围不能省掉修改对象的必要验证。Me、标点、加粗也可能改变有效边界；“未改变其他对象”不等于“全篇合格”。Word 交付仍检查最终全部页面。

## 规则的优先层级

1. **硬性边界**：保持连接、键级、立体信息、电荷、同位素及数据归属；不猜造结构或产率，不遗漏原有内容。原生交付包含真实可编辑节点、键和文字。保留原件，如实记录未验证项。
2. **用户已明确的默认要求**：新绘或获准原生规范化使用 [绘图基线](references/baseline.md)；涉及 [Me、编号和通式展开](references/structure-representation.md) 或 [Word 默认插入尺寸](references/word-display-and-qa.md#默认插入尺寸) 时先读对应完整规则。这些不能当作随意调整的排版偏好；当次用户明确要求优先。
3. **可灵活排版**：按 [布局与内容](references/layout.md) 调整行列、位置和留白，保持规范分子的几何及其标记归属。特殊投影按科学含义处理。

## 按当前能力承诺交付

| 环境 | 可承诺成果 |
| --- | --- |
| 无 ChemDraw/Word | 候选 CDXML、近似预览、未验证清单；只是阶段成果 |
| 有 ChemDraw | 保存、格式核验并实际重开后的原生文件；Word/OLE 仍未验证 |
| ChemDraw 与 Word 均可用 | 按请求完成原生文件、真实嵌入 OLE、Word/PDF 页面验收 |

登记软件不等于实际可用；运行 [环境与原生流程](references/native-workflow.md) 的预检。仅要求独立原生图时不强加 Word；只读审查交付报告。各项检查分别能证明什么，见 [证据边界](references/evidence.md)。

**运行位置**：只读检查和近似预览只需 Python 3.10+ 标准库，任何环境都能运行，包括没有 ChemDraw 的云端工作区。原生保存、嵌入和 Word/PDF 验收必须在装有 ChemDraw 与 Word 的 Windows 电脑上运行；当前会话只能远程连接那台电脑时，就在那台电脑上执行，再把结果取回核对。

## 快速路径

以下命令在技能根目录运行，文件名替换为本次任务的实际路径。

**所有环境：只读检查与近似预览**

```text
python -B scripts/cdx_lint.py fig.cdxml --draft-roles roles.json
python -B scripts/cdx_lint.py fig.cdxml --roles roles.json --output lint.json
python -B scripts/measure_bond_angles.py fig.cdxml --inventory --auto-plan --output plan.json
python -B scripts/measure_bond_angles.py fig.cdxml --plan plan.json --output angles.json
python -B scripts/check_correspondence.py expected.json fig.cdxml --output correspondence.json
python -B scripts/render_preview.py fig.cdxml preview.svg --report preview.json
```

1. 第一条生成角色表草稿。逐项核对后删除 `draft` 字段，才能用于第二条。
2. `plan.json` 中仍为 `pending` 的中心需要人工判定。
3. `expected.json` 只能来自可信原稿或编号表，不能从待验收图生成。
4. 预览 SVG 只用于自查明显缺漏，不是 ChemDraw 渲染。

**Windows + ChemDraw + Word：原生交付**

```text
python -B scripts/preflight.py --temp-dir TASK_TEMP --output environment.json
python -B scripts/run_native.py figures.json C:/task/new-output --timeout 180
python -B scripts/check_word_sizes.py C:/task/new-output/native-run.json --output sizes.json
python -B scripts/inspect_word_package.py C:/task/new-output/verification.docx --output package.json
```

随后从最终 Word 双击打开每个对象，核对原生内容、页面预览和 PDF。`run_native.py` 只用于新建文档；返修已有论文的步骤见 [原生流程](references/native-workflow.md)。

## 执行顺序

1. 确认源哈希、允许修改范围和独立的结构—编号—产率—标记对应关系。数据有矛盾先保留待确认项。
2. 在 [CDXML 模板](assets/chemdraw-standard.cdxml) 或 [CDX 模板](assets/chemdraw-standard.cdx) 基础上制作；使用真实节点和实际文字样式。[检查工具](references/checkers.md) 分项给出结果，不替代原生打开。
3. 用 [键角清单](references/bond-geometry.md) 覆盖全部候选中心和显式 N–H；特殊中心保留人工复核。重新保存后重新绑定计划。
4. 核实原生保存落盘并重开。首次制作或遇到 Ar、13CH3、中文路径、锁定、缓存问题时读 [实测易错点](references/native-authoring-pitfalls.md)。
5. Word 图稿核对最终页面预览、从 Word 双击打开的原生图、同版 PDF；按 [显示校验](references/word-display-and-qa.md) 记录尺寸与证据，需要换算缓存比例时读 [显示校准](references/display-calibration.md)。交付可编辑 Word、对应 PDF 及原生源文件。

## 交付摘要

详细记录留在任务目录；给用户的回复只用下面五项，每项写实际证据：

```text
范围：修改了哪些图/对象；哪些未动
已验证：每项注明证据（如 lint 四项通过、键角 passed_in_scope、Word 双击与 PDF 已核）
发现问题：位置，以及是否已修
未验证：缺什么证据、原因
文件：可编辑 Word / PDF / 原生源文件
```

维护本技能时读取 [测试与发布](references/testing.md) 和 [CHANGELOG](CHANGELOG.md)；版本实测数据见 [实测记录](references/evidence-log.md)。日常局部任务不重建全部测试稿。
