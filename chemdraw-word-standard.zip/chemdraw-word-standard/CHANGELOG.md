# Changelog

## 2.1.0 — 2026-11-07

基于 2.0.0 安装版备份修改；逐条迁移记录与备份哈希在发布证据中，不随包分发。

- 修复：structure-representation.md 与 testing.md 中 61 处 `\r\r\n` 换行损坏；全部文档统一为 LF。
- 修复：清单升级为 schema 2，文档类文件按规范化换行计算哈希，技能同步改写 SKILL.md 换行后不再误报损坏；CDXML、CDX、JSON 和脚本仍按原始字节。新增 `build_manifest.py`。
- 修复：空白模板或无结构的图在 lint 中返回 not_applicable（报告带 `nothing_checked`），键角返回 no_angle_centers，不再报 invalid_input；有片段的图仍拒绝空范围。
- 新增：`cdx_lint.py --draft-roles` 按文字形式生成角色表草稿，带 `draft` 或未分配项的角色表被拒绝，需人工确认后使用。
- 新增：`render_preview.py` 生成近似 SVG 预览（标准库，非 ChemDraw 渲染），报告近似处理和未渲染的对象类型。
- 新增：入口的快速路径、运行位置和交付摘要模板；native-workflow 增加运行位置表。
- 重组：新建 evidence.md 汇总各项证据的证明范围，替换多处重复的证据边界句；版本、日期和原始读数移入 evidence-log.md；word-display-and-qa.md 拆出 display-calibration.md；rule-migration.md 移入发布证据。
- 触发描述增补 CDX/CDXML、反应式/scheme；触发核对增至 9 句（人工核对，未做自动路由评测）。
- 未做：常用片段库需先在 ChemDraw 中保存重开验证，本版未加入；本版无原生软件变更，未重跑 Windows 原生集成测试。

## 2.0.0 — 2026-11-05

基于本机已安装且已备份的无版本号版本；不虚构历史版本号。本次发布以本目录、VERSION 和文件哈希清单为交付单位，保留 agents/openai.yaml。另一端应导入同一完整包并核对哈希；长期仓库主版本/双端自动同步策略不在本次本机更新中擅自决定。

- 修复 `--plan` 静默忽略命令行容差：显式容差只用于 `--centers`；计划在每条记录声明实际容差。
- 临时目录预检改为实际写入、读回、删除。
- 增加只读 CDXML 四项检查、独立结构/编号/产率/标记对应检查、对调反例和拓扑角度建议。
- 增加环境预检、Word 实际宽高容差、OLE/缓存包清单、Windows 原生保存嵌入工具与有限等待。
- 原生实测修正 PowerShell XML Name 属性歧义、COM 路径类型、Word 文件锁校验次序及测试文档空白页。
- 结构比较对楔线/CIP/E-Z 等复杂立体信息保留待复核，避免把未检查的构型当作已证明相同。
- 入口前置影响范围、规则层级和环境承诺；完整 Me/编号/插入尺寸各只有一个规范来源。测试说明移入 testing.md，保留逐条迁移记录。
- 加入中文触发词、版本和内容哈希。保留真实失败形成的 Ar、13CH3、保存重开、候选覆盖、源哈希、显式 N–H 及 Word/原生/PDF 对照规则。
- 可选 SMILES → CDXML 生成器本版不加入；先保证返修、语义和交付验证可靠，避免新依赖扩大未经验证的结构生成能力。
