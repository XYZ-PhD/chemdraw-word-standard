# chemdraw-word-standard 2.1.0 发布证据

| 文件 | 内容 |
| --- | --- |
| backup-2.0.0-installed.zip / .sha256 | 修改起点：2.0.0 安装版备份及哈希 |
| rule-migration-2.0.0.md | 2.0.0 逐条迁移表（从技能包移出，原样保存；其中相对链接按旧目录结构） |
| migration-2.1.0.md | 2.1.0 逐条迁移记录：273 条中 250 条原文保留，23 条改写或移位并写明去向 |
| unittest-2.1.0.log | 88 个 Python 回归测试结果 |
| quick-validate-2.1.0.log | skill-creator 基本校验 |
| links-2.1.0.json / check_links.py | 72 条内部链接与锚点检查 |
| chemdraw-word-standard-2.1.0.zip.sha256 | 发布包哈希（清单不哈希自身） |
| preview-scope-expanded.png | 快速路径端到端运行时的近似预览样张 |

未做：本版没有原生软件相关改动，未重跑 Windows ChemDraw/Word 集成测试；触发描述只做了人工核对，未做自动路由评测。
