# 2.1.0 条款迁移记录

基于 2.0.0 安装版备份（ZIP SHA256 见 backup-2.0.0-installed.sha256）。覆盖旧 SKILL.md、CHANGELOG 与 references 下除 rule-migration.md 以外的每一非空内容行；标题、空行、表格分隔行与代码围栏不作为独立条款。旧 rule-migration.md 原样移入本目录 rule-migration-2.0.0.md。比较前把换行统一为 LF。

共 273 行：原文保留 250 行，改写或移位 23 行。

## 改写或移位的条款

| 旧位置 | 原条款摘录 | 新位置 | 处理 |
| --- | --- | --- | --- |
| SKILL.md:3 | description: "绘制、返修或检查可编辑 ChemDraw 化学结构图及其 Word 排版。用于画结构式、化学结构图、反应式、底物拓展、放进 Word、统一键长、键角、字… | SKILL.md description | 增补触发词 CDX/CDXML、反应式/scheme、reaction schemes；排除项不变 |
| SKILL.md:31 | \| 无 ChemDraw/Word \| 候选 CDXML、可取得的预览、未验证清单；只是阶段成果 \| | SKILL.md 能力表 | “可取得的预览”改为“近似预览”，对应新增 render_preview.py |
| SKILL.md:43 | 5. Word 图稿核对最终页面预览、从 Word 双击打开的原生图、同版 PDF；按 [显示校验](references/word-display-and-qa.md) 记录尺寸… | SKILL.md 执行顺序第 5 步 | 原文保留，追加缓存换算时读 display-calibration.md |
| SKILL.md:45 | 维护本技能时读取 [测试与发布](references/testing.md)、[条款迁移表](references/rule-migration.md) 和 [CHANGELOG… | SKILL.md 末段 | 迁移表移入发布证据，入口改指 testing.md、CHANGELOG 和 evidence-log.md |
| references/checkers.md:42 | - `check_word_sizes.py native-run.json --output sizes.json`：只比较实际宽高及容差，不使用缩放字段，不证明有效边界/缓存尺… | evidence.md 表格 check_word_sizes 行；checkers.md 保留工具用途 | “不证明有效边界/缓存尺度”并入证据边界表 |
| references/checkers.md:43 | - `inspect_word_package.py final.docx --output package.json`：只盘点嵌入关系、缓存关联和哈希；OLE 声明和二进制文件存… | evidence.md 表格 inspect_word_package 行；checkers.md 保留工具用途 | “不能证明可编辑”并入证据边界表 |
| references/checkers.md:44 | - [原生嵌入流程](native-workflow.md)：必须另做重开、对象激活和 Word/PDF 视觉验收。 | checkers.md 同条 | 原意保留，措辞改为正面表述“另做…验收” |
| references/native-authoring-pitfalls.md:27 | 2026-11-05 在 ChemDraw 25.0.2.14 用同一测试文件保存 CDX、关闭重开并导出 CDXML：独立文字 `7 ` 变为 `7`，而 `1a, 75%` 保… | pitfalls.md 规则 + evidence-log.md#编号分隔符的原生保存 | 规则结论保留在易错点；日期、版本、读数与 spacing.json 指针移入实测记录 |
| references/native-authoring-pitfalls.md:49 | 最终 Word 中执行正常 ChemDraw 编辑操作并取得原生内容，才证明嵌入对象的打开路径有效。源 CDX 单独能开、OLE 声明存在、显示缓存清晰，均不能单独替代此验证。只读… | pitfalls.md 同段 + evidence.md 表格（源 CDX 单独能开、inspect_word_package、双击打开三行） | “源 CDX 能开/OLE 声明/缓存清晰均不能替代”并入证据边界表 |
| references/native-workflow.md:11 | 环境承诺见 [入口](../SKILL.md)。无原生软件时只能交付候选 CDXML 和未验证清单，利用可用可信渲染器提供预览；没有渲染器就明确预览亦缺失，不能伪造截图或把阶段成果… | native-workflow.md 同段 | 预览途径具体化为 render_preview.py 近似预览并须注明非原生；“不能伪造截图或把阶段成果叫最终原生文件”保留 |
| references/native-workflow.md:19 | 5. 从最终 Word 双击对象，对照页面预览、原生图及最终 PDF。逐页检查完整性、比例、文字、箭头、标记、裁剪和分页。内容、缓存、激活、页面是独立证据。只读复核结束后确认交付文… | native-workflow.md 同条 + evidence.md 第二段 | “内容、缓存、激活、页面是独立证据”移入证据边界表下的说明 |
| references/native-workflow.md:25 | 工具 `run_native.py` 调用系统 Windows PowerShell 与 COM，不依赖 pywin32。`embed_word.ps1` 当前验证组合为 Wind… | native-workflow.md 同段 + evidence-log.md#已验证软件组合 | 版本号和注册类型移入实测记录；“其他版本需同样实测，不自动继承通过结论”保留 |
| references/testing.md:74 | 本版对这 8 句按入口语义逐项人工核对（4 正、4 反）。关键词存在检查只能验证文本配置，不能证明实际模型路由。当前未运行多模型自动触发评测；维护者有评测环境时另记模型、提示与实际… | testing.md 同段 | 核对句数更新为 9 句（5 正、4 反），新增 CDXML 只读检查的正例；其余原文保留 |
| references/testing.md:82 | 本次以当前 Codex 安装版的备份为修改起点，完整新包是此次可同步单元；Claude 端可导入同一包并核对哈希。长期主仓库及自动双向同步不在本次更新中擅自设置，也不自动发布网络仓… | testing.md 同段 | 去掉 2.0.0 专属的“本次”叙述；保留“完整包为同步单元、两端核对、不擅自设置自动同步或发布” |
| references/testing.md:84 | 本版不增加可选 build_cdxml.py。未来只用于身份明确的新分子，不用于返修已有图；如使用 RDKit，单列可选依赖和立体/芳香性/布局验证。不得让生成器取代原生软件验证。 | testing.md 同段 | “本版不增加”改为“暂不增加”，追加片段库须先原生验证的要求 |
| references/word-display-and-qa.md:3 | 在跨图统一、定位大小差异、更新 OLE 缓存或说明尺寸变更时读取。本文件讲测量与易错点，不增加期刊视觉风格。 | word-display-and-qa.md 开头 | 读取时机与范围更新，指向拆出的 display-calibration.md |
| references/word-display-and-qa.md:15 | 2026-11-05 本机 ChemDraw 25.0.2.14 / Word 16.0.14334：宽幅、窄幅、几何三对象默认宽高分别为 355×95.5、83.5×249、38… | evidence-log.md#word-尺寸容差的依据 | 原始读数整段移入实测记录，word-display 留指针 |
| references/word-display-and-qa.md:17 | 尺寸通过只证明读取到的外框稳定。新增文字导致有效源边界变化、缓存缩放或初次插入自动适配仍可能发生，须另作下述校准及三视图对照。保留每次源/Word/PDF 哈希、原始读数和应用版本… | word-display-and-qa.md#尺寸容差 | 原文保留，“下述校准”改为链接 display-calibration.md |
| references/word-display-and-qa.md:23 | 以下公式用于测量现有对象和核对默认插入结果。在无变形且原始可见画布宽度已正确校准时： | word-display-and-qa.md#两个坐标空间 | 原文保留，追加“有效宽度取得方法见 display-calibration.md” |
| references/word-display-and-qa.md:125 | - 对未改动页面，条件允许时做像素比较或其他可靠对照，避免局部修改带动其他页变化。缓存检查、结构检查、原生打开检查、页面可视检查是不同的证据，不互相替代。 | word-display-and-qa.md 同条 + evidence.md | 像素对照要求保留；“各类证据不互相替代”改为链接证据边界表 |
| references/word-display-and-qa.md:145 | 尺寸数值使用明确单位；证据状态分为已验证、发现问题、未验证。比例或校准来源不可靠时保留未验证状态，不能用填入精确小数来代替校准。 | word-display-and-qa.md 同段 + evidence.md#状态与记录 | 三态状态保留并链接；“不能用精确小数代替校准”移入证据边界表状态说明 |
| references/word-display-and-qa.md:147 | 局部修改且已有可靠基线时，可以通过未改图的原生内容、缓存、Word 尺寸及裁剪/变换信息未变来复用其测量记录，再检查最终页面。不能仅凭文件名相同、对象编号相同或图片看起来相近就复用… | word-display-and-qa.md 同段 + evidence.md#状态与记录 | 复用条件保留；“不能仅凭文件名、编号或相似图片复用”移入状态与记录 |
| references/word-display-and-qa.md:155 | Word 图稿默认配套 PDF；独立原生图和只读审查按其实际请求交付。需要列出例外时具体说明是哪些谱图、位图文字或自动下标，不将局部例外夸大为全部分子无需规范化。检查未完成时指出缺… | word-display-and-qa.md 同段 + SKILL.md#交付摘要 + evidence.md#状态与记录 | “指出缺少的证据”保留；“不能用可编辑/已统一掩盖”移入状态与记录，回复格式指向交付摘要 |

## 原文保留的条款

| 旧位置 | 新位置 |
| --- | --- |
| CHANGELOG.md:5 | CHANGELOG.md |
| CHANGELOG.md:7 | CHANGELOG.md |
| CHANGELOG.md:8 | CHANGELOG.md |
| CHANGELOG.md:9 | CHANGELOG.md |
| CHANGELOG.md:10 | CHANGELOG.md |
| CHANGELOG.md:11 | CHANGELOG.md |
| CHANGELOG.md:12 | CHANGELOG.md |
| CHANGELOG.md:13 | CHANGELOG.md |
| CHANGELOG.md:14 | CHANGELOG.md |
| CHANGELOG.md:15 | CHANGELOG.md |
| SKILL.md:2 | SKILL.md |
| SKILL.md:10 | SKILL.md |
| SKILL.md:12 | SKILL.md |
| SKILL.md:14 | SKILL.md |
| SKILL.md:15 | SKILL.md |
| SKILL.md:16 | SKILL.md |
| SKILL.md:17 | SKILL.md |
| SKILL.md:19 | SKILL.md |
| SKILL.md:23 | SKILL.md |
| SKILL.md:24 | SKILL.md |
| SKILL.md:25 | SKILL.md |
| SKILL.md:29 | SKILL.md |
| SKILL.md:32 | SKILL.md |
| SKILL.md:33 | SKILL.md |
| SKILL.md:35 | SKILL.md |
| SKILL.md:39 | SKILL.md |
| SKILL.md:40 | SKILL.md |
| SKILL.md:41 | SKILL.md |
| SKILL.md:42 | SKILL.md |
| references/baseline.md:3 | references/baseline.md |
| references/baseline.md:5 | references/baseline.md |
| references/baseline.md:7 | references/baseline.md |
| references/baseline.md:8 | references/baseline.md |
| references/baseline.md:9 | references/baseline.md |
| references/baseline.md:10 | references/baseline.md |
| references/baseline.md:11 | references/baseline.md |
| references/baseline.md:12 | references/baseline.md |
| references/baseline.md:13 | references/baseline.md |
| references/baseline.md:15 | references/baseline.md |
| references/baseline.md:17 | references/baseline.md |
| references/baseline.md:19 | references/baseline.md |
| references/baseline.md:21 | references/baseline.md |
| references/baseline.md:23 | references/baseline.md |
| references/bond-geometry.md:3 | references/bond-geometry.md |
| references/bond-geometry.md:7 | references/bond-geometry.md |
| references/bond-geometry.md:8 | references/bond-geometry.md |
| references/bond-geometry.md:9 | references/bond-geometry.md |
| references/bond-geometry.md:10 | references/bond-geometry.md |
| references/bond-geometry.md:14 | references/bond-geometry.md |
| references/bond-geometry.md:16 | references/bond-geometry.md |
| references/bond-geometry.md:18 | references/bond-geometry.md |
| references/bond-geometry.md:20 | references/bond-geometry.md |
| references/bond-geometry.md:24 | references/bond-geometry.md |
| references/bond-geometry.md:27 | references/bond-geometry.md |
| references/bond-geometry.md:28 | references/bond-geometry.md |
| references/bond-geometry.md:31 | references/bond-geometry.md |
| references/bond-geometry.md:33 | references/bond-geometry.md |
| references/bond-geometry.md:35 | references/bond-geometry.md |
| references/bond-geometry.md:37 | references/bond-geometry.md |
| references/bond-geometry.md:39 | references/bond-geometry.md |
| references/bond-geometry.md:40 | references/bond-geometry.md |
| references/bond-geometry.md:41 | references/bond-geometry.md |
| references/bond-geometry.md:43 | references/bond-geometry.md |
| references/bond-geometry.md:45 | references/bond-geometry.md |
| references/bond-geometry.md:49 | references/bond-geometry.md |
| references/bond-geometry.md:51 | references/bond-geometry.md |
| references/bond-geometry.md:53 | references/bond-geometry.md |
| references/checkers.md:3 | references/checkers.md |
| references/checkers.md:8 | references/checkers.md |
| references/checkers.md:11 | references/checkers.md |
| references/checkers.md:13 | references/checkers.md |
| references/checkers.md:15 | references/checkers.md |
| references/checkers.md:17 | references/checkers.md |
| references/checkers.md:20 | references/checkers.md |
| references/checkers.md:23 | references/checkers.md |
| references/checkers.md:28 | references/checkers.md |
| references/checkers.md:31 | references/checkers.md |
| references/checkers.md:33 | references/checkers.md |
| references/checkers.md:35 | references/checkers.md |
| references/checkers.md:37 | references/checkers.md |
| references/checkers.md:41 | references/checkers.md |
| references/layout.md:3 | references/layout.md |
| references/layout.md:5 | references/layout.md |
| references/layout.md:7 | references/layout.md |
| references/layout.md:9 | references/layout.md |
| references/layout.md:11 | references/layout.md |
| references/layout.md:13 | references/layout.md |
| references/layout.md:15 | references/layout.md |
| references/native-authoring-pitfalls.md:3 | references/native-authoring-pitfalls.md |
| references/native-authoring-pitfalls.md:7 | references/native-authoring-pitfalls.md |
| references/native-authoring-pitfalls.md:9 | references/native-authoring-pitfalls.md |
| references/native-authoring-pitfalls.md:11 | references/native-authoring-pitfalls.md |
| references/native-authoring-pitfalls.md:15 | references/native-authoring-pitfalls.md |
| references/native-authoring-pitfalls.md:17 | references/native-authoring-pitfalls.md |
| references/native-authoring-pitfalls.md:21 | references/native-authoring-pitfalls.md |
| references/native-authoring-pitfalls.md:23 | references/native-authoring-pitfalls.md |
| references/native-authoring-pitfalls.md:31 | references/native-authoring-pitfalls.md |
| references/native-authoring-pitfalls.md:35 | references/native-authoring-pitfalls.md |
| references/native-authoring-pitfalls.md:37 | references/native-authoring-pitfalls.md |
| references/native-authoring-pitfalls.md:41 | references/native-authoring-pitfalls.md |
| references/native-authoring-pitfalls.md:43 | references/native-authoring-pitfalls.md |
| references/native-authoring-pitfalls.md:47 | references/native-authoring-pitfalls.md |
| references/native-authoring-pitfalls.md:51 | references/native-authoring-pitfalls.md |
| references/native-authoring-pitfalls.md:55 | references/native-authoring-pitfalls.md |
| references/native-authoring-pitfalls.md:57 | references/native-authoring-pitfalls.md |
| references/native-workflow.md:6 | SKILL.md, references/native-workflow.md, references/testing.md |
| references/native-workflow.md:9 | references/native-workflow.md |
| references/native-workflow.md:15 | references/native-workflow.md |
| references/native-workflow.md:16 | references/native-workflow.md |
| references/native-workflow.md:17 | references/native-workflow.md |
| references/native-workflow.md:18 | references/native-workflow.md |
| references/native-workflow.md:21 | references/native-workflow.md |
| references/native-workflow.md:27 | references/native-workflow.md |
| references/native-workflow.md:30 | references/native-workflow.md |
| references/native-workflow.md:34 | SKILL.md, references/native-workflow.md |
| references/native-workflow.md:35 | SKILL.md, references/native-workflow.md |
| references/native-workflow.md:36 | SKILL.md, references/native-workflow.md |
| references/native-workflow.md:39 | references/native-workflow.md |
| references/native-workflow.md:41 | references/native-workflow.md |
| references/native-workflow.md:43 | references/native-workflow.md |
| references/native-workflow.md:45 | references/native-workflow.md |
| references/native-workflow.md:47 | references/native-workflow.md |
| references/structure-representation.md:3 | references/structure-representation.md |
| references/structure-representation.md:7 | references/structure-representation.md |
| references/structure-representation.md:8 | references/structure-representation.md |
| references/structure-representation.md:9 | references/structure-representation.md |
| references/structure-representation.md:10 | references/structure-representation.md |
| references/structure-representation.md:11 | references/structure-representation.md |
| references/structure-representation.md:15 | references/structure-representation.md |
| references/structure-representation.md:17 | references/structure-representation.md |
| references/structure-representation.md:19 | references/structure-representation.md |
| references/structure-representation.md:21 | references/structure-representation.md |
| references/structure-representation.md:23 | references/structure-representation.md |
| references/structure-representation.md:27 | references/structure-representation.md |
| references/structure-representation.md:29 | references/structure-representation.md |
| references/structure-representation.md:30 | references/structure-representation.md |
| references/structure-representation.md:32 | references/structure-representation.md |
| references/structure-representation.md:34 | references/structure-representation.md |
| references/structure-representation.md:37 | references/structure-representation.md |
| references/testing.md:3 | references/testing.md |
| references/testing.md:6 | references/testing.md |
| references/testing.md:7 | SKILL.md, references/native-workflow.md, references/testing.md |
| references/testing.md:10 | references/testing.md |
| references/testing.md:14 | references/testing.md |
| references/testing.md:15 | references/testing.md |
| references/testing.md:16 | references/testing.md |
| references/testing.md:17 | references/testing.md |
| references/testing.md:18 | references/testing.md |
| references/testing.md:19 | references/testing.md |
| references/testing.md:21 | references/testing.md |
| references/testing.md:25 | references/testing.md |
| references/testing.md:27 | references/testing.md |
| references/testing.md:28 | references/testing.md |
| references/testing.md:29 | references/testing.md |
| references/testing.md:31 | references/testing.md |
| references/testing.md:35 | references/testing.md |
| references/testing.md:37 | references/testing.md |
| references/testing.md:41 | references/testing.md |
| references/testing.md:43 | references/testing.md |
| references/testing.md:44 | references/testing.md |
| references/testing.md:45 | references/testing.md |
| references/testing.md:46 | references/testing.md |
| references/testing.md:47 | references/testing.md |
| references/testing.md:48 | references/testing.md |
| references/testing.md:52 | references/testing.md |
| references/testing.md:54 | references/testing.md |
| references/testing.md:55 | references/testing.md |
| references/testing.md:56 | references/testing.md |
| references/testing.md:57 | references/testing.md |
| references/testing.md:58 | references/testing.md |
| references/testing.md:63 | references/testing.md |
| references/testing.md:65 | references/testing.md |
| references/testing.md:66 | references/testing.md |
| references/testing.md:67 | references/testing.md |
| references/testing.md:68 | references/testing.md |
| references/testing.md:69 | references/testing.md |
| references/testing.md:70 | references/testing.md |
| references/testing.md:71 | references/testing.md |
| references/testing.md:72 | references/testing.md |
| references/testing.md:78 | references/testing.md |
| references/testing.md:80 | references/testing.md |
| references/word-display-and-qa.md:7 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:9 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:13 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:21 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:26 | references/display-calibration.md, references/word-display-and-qa.md |
| references/word-display-and-qa.md:27 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:28 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:29 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:32 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:34 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:36 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:40 | references/display-calibration.md |
| references/word-display-and-qa.md:41 | references/display-calibration.md |
| references/word-display-and-qa.md:42 | references/display-calibration.md |
| references/word-display-and-qa.md:43 | references/display-calibration.md |
| references/word-display-and-qa.md:47 | references/display-calibration.md |
| references/word-display-and-qa.md:49 | references/display-calibration.md |
| references/word-display-and-qa.md:52 | references/display-calibration.md |
| references/word-display-and-qa.md:53 | references/display-calibration.md |
| references/word-display-and-qa.md:54 | references/display-calibration.md |
| references/word-display-and-qa.md:57 | references/display-calibration.md |
| references/word-display-and-qa.md:59 | references/display-calibration.md |
| references/word-display-and-qa.md:63 | references/display-calibration.md |
| references/word-display-and-qa.md:66 | references/display-calibration.md |
| references/word-display-and-qa.md:67 | references/display-calibration.md |
| references/word-display-and-qa.md:70 | references/display-calibration.md |
| references/word-display-and-qa.md:74 | references/display-calibration.md |
| references/word-display-and-qa.md:75 | references/display-calibration.md |
| references/word-display-and-qa.md:76 | references/display-calibration.md |
| references/word-display-and-qa.md:77 | references/display-calibration.md |
| references/word-display-and-qa.md:78 | references/display-calibration.md |
| references/word-display-and-qa.md:79 | references/display-calibration.md |
| references/word-display-and-qa.md:80 | references/display-calibration.md |
| references/word-display-and-qa.md:82 | references/display-calibration.md |
| references/word-display-and-qa.md:86 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:88 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:90 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:92 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:96 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:97 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:98 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:99 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:100 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:102 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:106 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:108 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:110 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:112 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:113 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:114 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:118 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:119 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:120 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:121 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:122 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:123 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:124 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:129 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:130 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:131 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:135 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:137 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:139 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:140 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:141 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:142 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:143 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:149 | references/word-display-and-qa.md |
| references/word-display-and-qa.md:153 | references/word-display-and-qa.md |
