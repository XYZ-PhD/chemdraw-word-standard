"""Check relative Markdown links and #anchors (GitHub-style slugs) inside a skill directory."""
import re,sys,json
from pathlib import Path
root=Path(sys.argv[1]).resolve()
def slugs(md):
    out=set();inside=False
    for line in md.read_text(encoding='utf-8').splitlines():
        if line.startswith('```'): inside=not inside; continue
        m=re.match(r'^(#{1,6})\s+(.*)$',line)
        if m and not inside:
            h=re.sub(r'[*`]','',m.group(2)).strip().lower()
            out.add(re.sub(r'[^\w\- ]','',h).replace(' ','-'))
    return out
problems=[];count=0
for md in root.rglob('*.md'):
    text=md.read_text(encoding='utf-8')
    text=re.sub(r'```.*?```','',text,flags=re.S)
    for target in re.findall(r'\]\(([^)\s]+)\)',text):
        if re.match(r'https?://',target): continue
        count+=1
        path,_,anchor=target.partition('#')
        dest=(md.parent/path).resolve() if path else md
        if not dest.exists(): problems.append((str(md.relative_to(root)),target,'missing file')); continue
        if anchor and dest.suffix=='.md' and anchor.lower() not in slugs(dest): problems.append((str(md.relative_to(root)),target,'missing anchor'))
print(json.dumps({'links_checked':count,'problems':problems},ensure_ascii=False,indent=1))
sys.exit(1 if problems else 0)
