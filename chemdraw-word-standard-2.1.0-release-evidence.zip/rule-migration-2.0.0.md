# 旧条款 → 新位置

基于修改前 ZIP 建立；覆盖旧入口和四份 references 的每一非空内容行。标题、空行和 Markdown 围栏不作为独立条款。完整原文与哈希见发布证据中的 migration.json；这张表按需读取。

| 旧位置 | 原条款摘录 | 新位置 | 处理 |
| --- | --- | --- | --- |
| references/bond-geometry.md:3 | 绘制或修正普通二维结构、显式氢和支链方向，或测试本技能时读取。这里规定二维结构的规范画法，不将示意角度当作实验测得的三维键角。 | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:7 | - 普通非环碳链采用常用的约 120° 折线，保持同一套常规方向，不将连续链随意压成直角或过钝的转折。芳环、羰基及其他常规平面片段按相应模板处理。 | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:8 | - 本技能通式与展开样例中的三配位 N，在二维图中采用三向约 120° 的排布，显式 N–H 与两条 N–C 或 N–R 键一起安排。先考虑已有键方向，再决定 H 的位置；不能一律把 N–H 竖直向上… | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:9 | - 常规炔烃、腈等线性片段按其连接关系画直；不能把同一套 120° 折线套到三键中心。 | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:10 | - 小环、稠环、桥环、金属配位中心和立体投影按其真实拓扑及所需表达处理。楔线、虚线、双键构型与指定构象保留；普通二维折线的角度不是这些对象的强制标准。 | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:14 | 对中心原子取得全部直接相邻原子的坐标，计算中心到各邻点的向量和夹角。双键按一个邻接方向计算；跳过缩写内部的隐藏展开片段。显式 H 不能被当作普通说明文字略过。用节点坐标，不能用标签边框、被文字截短的线… | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:16 | 三向平面排布检查各个扇区，不以全图的角度平均数代替。例如中心位于 (0,0)，左侧连接点在 180°、H 在 270°、另一连接点在 30°，得到的三个扇区是 90°、120°、150°；即使平均数为… | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:18 | 可用 坐标检查工具 对明确选定的原子测量。先从当前 CDXML 确认目标节点 ID，再运行 python scripts/measure_bond_angles.py input.cdxml --ce… | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:20 | 在同一例子中保留左侧方向，可将 H 调到 300°、右侧键调到 60°，三向均为 120°。右侧链的后续方向相应重排，保持其常规折线及原有键长；不能只转动 H 或只改文档默认参数。角度允许原生保存的坐… | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:24 | 需要对本次目标图作完整键角验收时，先生成清单，再按结构指定检查方法。局部任务只圈定受影响片段；不能通过缩小检查范围来宣称全图通过。未修改的图按已有的影响范围规则处理，不强制重测。 | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:27 | python scripts/measure_bond_angles.py input.cdxml --inventory --output plan.json | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:28 | python scripts/measure_bond_angles.py input.cdxml --plan plan.json --output report.json | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:31 | 首次命令自动收集可见结构中有至少两个不同邻接原子的中心，包括显式氢所连接的中心，跳过缩写内部隐藏展开。清单包含源文件 SHA256、片段范围、邻接信息和全部待处理项。局部检查可在生成时加 --frag… | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:33 | entries 按中心 ID 填写，保留清单的源哈希和范围： | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:35 | - 常规角度：{"method":"angle","expected_angle_deg":120,"tolerance_deg":1}。按真实片段选择角度；线性片段可选 180，不能统一填 120。… | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:36 | - 特殊结构：{"method":"manual","status":"passed","reason":"小环或指定立体投影等具体原因","evidence":"本次原生图或页面的核对位置及结论"}… | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:37 | - 尚未处理：{"method":"pending"}。删除条目仍算待处理，不能靠删行使检查通过。 | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:39 | 结果 selected_centers_passed 仅表示所选中心通过；measured_only 和 inventory_only 不作合格判断。计划结果 passed_in_scope 只证明声… | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:41 | 坐标缺失、非有限数、零长度键或无效连接应明确阻止计算。向量分别归一化，避免极小或极大有限数的乘积导致数值错误；数值稳定不代表键长符合绘图基线。计划绑定确切输入文件；原生重新保存改变文件后，重新生成清单… | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:45 | 按当次授权调整相关片段；改角度时保持连接关系、键级、立体信息、实际键长与原生字号。根据新边界移动编号或条件文字，并重新检查 Word 显示比例。不通过拉伸 Word 图片修正角度。 | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:47 | 可使用适用的 ChemDraw 整理结构功能辅助普通二维排布，但须复核结果，不能未经检查对整篇或复杂立体图统一整理。保存后重开，检查目标角度、相邻折线、标签间距和原生结构；再核对最终 Word/PDF… | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| references/bond-geometry.md:49 | 检验技能时至少包含此三配位 N 和显式 N–H 的例子，逐原子保留结果；还应核对常规链、平面片段与线性片段是否按其各自规则排布。具体任务未涉及的结构不因这条测试说明而扩大修改范围。 | [testing.md](testing.md) | 移入测试说明 |
| references/bond-geometry.md:51 | 修改检查器后运行 python scripts/test_bond_angles.py，覆盖正确/错误 N 共存、缺项、无效坐标、线性片段、特殊中心人工复核和旧计划失效。原生保存及 Word 验收另用… | [testing.md](testing.md) | 移入测试说明 |
| references/bond-geometry.md:53 | 测试文件仅写入独立临时目录；系统临时目录不可写时，可将 CHEMDRAW_TEST_TMP 指向本次任务可写目录，不修改用户全局环境。完成后清理该测试自己创建的临时子目录。 | [testing.md](testing.md) | 移入测试说明 |
| references/native-authoring-pitfalls.md:3 | 首次组装原生 Word 图稿、排查保存/打开问题或测试本技能时读取。这些来自实际制作中的失败条件；按条件处理，不把某次环境行为当作所有版本的固定限制。 | [native-authoring-pitfalls.md](native-authoring-pitfalls.md) | 保留含义 |
| references/native-authoring-pitfalls.md:7 | ChemDraw 的保存调用可能返回而目标文件未生成。每次关键导出后检查文件存在、非空、格式签名或内容正确，随后实际重开。不能只凭调用未抛出异常就继续向 Word 嵌入。 | [native-authoring-pitfalls.md](native-authoring-pitfalls.md) | 保留含义 |
| references/native-authoring-pitfalls.md:9 | 本机曾出现 CDX 直接保存到中文路径未生成文件，而保存到 ASCII 路径正常的情况。遇到同类问题，使用本次任务的可写暂存位置，确保完整临时路径仅含 ASCII 字符，核验并重开后，再复制到最终中文… | [native-authoring-pitfalls.md](native-authoring-pitfalls.md) | 保留含义 |
| references/native-authoring-pitfalls.md:11 | 应用接口和导出类型以当前安装版本为准。保留 CDX/CDXML 中真实节点、键、文字及正确引用，避免用一幅截图替代原生结构。 | [native-authoring-pitfalls.md](native-authoring-pitfalls.md) | 保留含义 |
| references/native-authoring-pitfalls.md:15 | 普通名称和纯数字编号可能被误作化学式，触发 Chemical Interpretation is not possible for this label。只对已经确认是非化学说明的独立文字，使用普通文… | [native-authoring-pitfalls.md](native-authoring-pitfalls.md) | 保留含义 |
| references/native-authoring-pitfalls.md:17 | 真实原子标签、基团缩写、同位素、电荷仍保留化学解释和自动上下标。不能通过全局关闭化学检查来掩盖结构错误。 | [native-authoring-pitfalls.md](native-authoring-pitfalls.md) | 保留含义 |
| references/native-authoring-pitfalls.md:21 | 在本机实测中，连接到结构上的 Ar 标签曾在保存时被解析成氩（Element 18），仅写入 GenericNickname 或关闭该标签的解释仍未得到正确的通式节点。核对保存并重开后的节点类型及化学… | [native-authoring-pitfalls.md](native-authoring-pitfalls.md) | 保留含义 |
| references/native-authoring-pitfalls.md:23 | 这只是一种保留含义的表示办法，不是要求将所有 Ar 改为 R。现有图需保留 Ar 字样时，应验证当前软件支持的原生表示；未验证则说明该项。真实氩原子按其元素身份保留。 | [native-authoring-pitfalls.md](native-authoring-pitfalls.md) | 保留含义 |
| references/native-authoring-pitfalls.md:27 | 有产率时，重开后核对加粗编号及逗号与产率之间的一个半角空格。本机此前对 1a, 75% 的实测保留了分隔空格。无产率时，原生文字仅含加粗编号，如 **7**。遇到旧版无产率标签留下的末尾逗号或空格，按… | [structure-representation.md](structure-representation.md)；[native-authoring-pitfalls.md](native-authoring-pitfalls.md) | 完整规范单源；实测行为仍放易错点 |
| references/native-authoring-pitfalls.md:31 | 本机测试中，给碳节点设置 Isotope="13"，但将 13CH3 全部写成普通化学文字，保存后仍出现无法解析的标签并丢失元素身份。改为原生碳的质量数属性、上标 13 文字片段和正常化学 CH3 片… | [native-authoring-pitfalls.md](native-authoring-pitfalls.md) | 保留含义 |
| references/native-authoring-pitfalls.md:35 | Word 内置或本地默认模板可能在 Title 等样式中带有段落下边框，主题字体也可能覆盖手动写入的字体名。检查实际使用样式、继承关系、直接格式和 w:rFonts 主题属性，按目标设置处理冲突。 | [native-authoring-pitfalls.md](native-authoring-pitfalls.md) | 保留含义 |
| references/native-authoring-pitfalls.md:37 | 新图稿标题采用黑色、无装饰横线。标题横线、表格边框、坐标线和反应箭头是不同元素，不能批量删除所有线。规范化字体时保留正确的中文后备字体与化学上下标。 | [native-authoring-pitfalls.md](native-authoring-pitfalls.md) | 保留含义 |
| references/native-authoring-pitfalls.md:41 | 串行控制本次任务的 Word/ChemDraw。只读验证时用只读方式打开；需要修改时采用独立工作副本，避免重复打开同一底稿产生文件锁。 | [native-authoring-pitfalls.md](native-authoring-pitfalls.md) | 保留含义 |
| references/native-authoring-pitfalls.md:43 | 长时间无进展时先检查当前步骤、文件状态和应用提示，不盲目启动更多实例。只释放本次任务创建的文档和句柄。确需清理失败的任务进程时，先核对进程身份、创建时间及任务归属；不能按应用名关闭所有 Word 或 … | [native-authoring-pitfalls.md](native-authoring-pitfalls.md) | 保留含义 |
| references/native-authoring-pitfalls.md:47 | 环境缺少文档技能所用的 LibreOffice 时，记录具体原因，使用可用的 Microsoft Word 原生导出 PDF，再将 PDF 渲染为页面图检查。不需要为了渲染而修改用户环境，也不能把渲染… | [native-authoring-pitfalls.md](native-authoring-pitfalls.md) | 保留含义 |
| references/native-authoring-pitfalls.md:49 | 最终 Word 中执行正常 ChemDraw 编辑操作并取得原生内容，才证明嵌入对象的打开路径有效。源 CDX 单独能开、OLE 声明存在、显示缓存清晰，均不能单独替代此验证。只读验证后核对最终交付文… | [native-authoring-pitfalls.md](native-authoring-pitfalls.md) | 保留含义 |
| references/native-authoring-pitfalls.md:51 | 单幅图内部的比例统一不能覆盖跨图问题。需要多图检验时，按 显示尺度与校验 使用不同有效宽度的独立对象，逐图校准，不以同一 Word 插入宽度作为统一尺度的证据。 | [native-authoring-pitfalls.md](native-authoring-pitfalls.md) | 保留含义 |
| references/structure-representation.md:3 | 涉及甲基显示、化合物编号或底物拓展表示方式时读取。当次明确要求优先，修改范围按当次任务执行。 | [structure-representation.md](structure-representation.md) | 保留含义 |
| references/structure-representation.md:7 | - 普通甲基 CH3 明确显示为 Me，包括连接在芳环、碳链、羰基碳或杂原子上的裸露甲基末端，不只留一个无标签的线端。结合连接关系、键级、氢数与电荷判断其是否确为甲基，不能仅凭图形是“线端”就替换。 | [structure-representation.md](structure-representation.md) | 保留含义 |
| references/structure-representation.md:8 | - Me 使用化学可识别、可编辑的原生缩写，保持其真实甲基连接；普通字体 Arial 10 pt，Word 中与其他普通标签采用同一显示比例。需要给标签腾位置时调整布局，不通过拉长键或单独缩小 Me … | [structure-representation.md](structure-representation.md) | 保留含义 |
| references/structure-representation.md:9 | - 已有正确的 OMe、NMe2、COOMe 等缩写可按其化学含义保留；展开底物的芳环骨架不要求把这些常用官能团缩写全部拆成逐原子标签。 | [structure-representation.md](structure-representation.md) | 保留含义 |
| references/structure-representation.md:10 | - 亚甲基 CH2、次甲基 CH、末端烯烃 CH2、末端炔烃 CH、氰基等保持真实结构。CD3、13CH3 等同位素信息按原有标记保留，不能用未注明同位素的 Me 覆盖。未知 R 基团也不能推定为 M… | [structure-representation.md](structure-representation.md) | 保留含义 |
| references/structure-representation.md:11 | - 验收时核对底层化学结构和最终显示；只叠加一个普通文本 Me 遮盖线端，不算合格的原生表示。 | [structure-representation.md](structure-representation.md) | 保留含义 |
| references/structure-representation.md:15 | 为使底物拓展整齐、紧凑、易于比较，可以把共享结构中写 Ar/R，再在旁边列取代基、编号和产率的形式，改为各个底物独立绘出真实结构，并在各自下方标对应编号和产率。此类保留全部化学信息的表示调整已获用户授… | [structure-representation.md](structure-representation.md) | 保留含义 |
| references/structure-representation.md:17 | 转换前先建立逐底物对应：编号、通式连接位点、Ar/R 的确切定义及取代位置、产率和其他相关注释。逐条生成，保留每一项。已知的芳基在独立底物中绘出对应环骨架，使用统一的默认键长和字号；空间不足时重排列数… | [structure-representation.md](structure-representation.md) | 保留含义 |
| references/structure-representation.md:19 | 转换只改变表达方式；源数据中的每条定义、编号、产率及其归属分别落实到完整结构。示范文件的取代基和数值不能移植到用户的其他底物。 | [structure-representation.md](structure-representation.md) | 保留含义 |
| references/structure-representation.md:21 | 检验转换时，按每个底物的展开结构逐一比对原通式和其取代基定义，核对区域异构、连接原子、键级、立体信息、电荷及同位素；再检查编号、产率和标记归属。Me 等缩写按其展开后的化学含义比较。展开会增加图元和原… | [structure-representation.md](structure-representation.md) | 保留含义 |
| references/structure-representation.md:23 | 如果通式或取代基定义不足以唯一确定结构，先定位缺失信息，保留待确认项；不要凭排版需要猜画。通用反应式或机制图中代表一类未知基团的 Ar/R，按其用途保留，不因这条底物拓展规则被强行具体化。 | [structure-representation.md](structure-representation.md) | 保留含义 |
| references/structure-representation.md:27 | 编号采用 Arial、原生 10 pt、黑色、加粗。新分配的独立产物编号用数字。按该处是否标有产率选择格式。 | [structure-representation.md](structure-representation.md) | 保留含义 |
| references/structure-representation.md:29 | - 有产率时，编号和紧跟的英文半角逗号一起加粗，逗号后留恰好一个半角空格，随后写常规字重的产率，例如 **43,** 70%。保留源产率的数值和限定信息。 | [structure-representation.md](structure-representation.md) | 保留含义 |
| references/structure-representation.md:30 | - 无产率时，标签只写加粗的编号，例如 **43**。末尾不留逗号或空格，不添加占位产率。已有名称、构型说明等必要信息保留为独立注释。 | [structure-representation.md](structure-representation.md) | 保留含义 |
| references/structure-representation.md:32 | 同一编号体系内先建立化合物与编号的对应关系。同一化合物跨反应路线、底物范围、表征图和正文复用已确认的编号，即使各处绘图方向、缩写或产率不同。例如同一产物在底物范围中标为 **43,** 70%，在只引… | [structure-representation.md](structure-representation.md) | 保留含义 |
| references/structure-representation.md:34 | 只处理已确认为化合物编号的标签。已有且已确认的 1a、P8 等编号完整保留并加粗，例如 **1a,** 75% 或 **P8**。真实原子标签、条件数字和测试用例标识各有自己的语义。规范已有分隔符，例… | [structure-representation.md](structure-representation.md) | 保留含义 |
| references/structure-representation.md:38 | 以下全部是格式测试数据，不是用户实验数据；日常绘图不得自动套用这些编号、结构或产率。 | [testing.md](testing.md) | 移入测试与示例说明 |
| references/structure-representation.md:40 | - 宽幅结构与编号（CDX）与 窄幅同结构（CDX）含相同的乙酰苯胺、N,N-二甲基苯甲酰胺和展开苯环的三苯基膦，编号依次为 1a、2b、P8，示例产率为 75%、82%、43%。前两者的裸露甲基用 … | [testing.md](testing.md) | 移入测试与示例说明 |
| references/structure-representation.md:41 | - 通式及定义（CDX）的通式为 R–NH–CH2–CH=CH2，此例中的 R 均由旁注定义为芳基。26 对应 R = 4-Me-C6H4、75%；27 对应 R = 4-F-C6H4、60%。芳基通… | [testing.md](testing.md) | 移入测试与示例说明 |
| references/structure-representation.md:42 | - 展开结果（CDX）分别绘出上述两种完整结构，保留相同编号与示例产率。核对用连接式为 Cc1ccc(NCC=C)cc1 和 Fc1ccc(NCC=C)cc1，分子式分别为 C10H13N、C9H10… | [testing.md](testing.md) | 移入测试与示例说明 |
| references/structure-representation.md:44 | 示例用于复用原生表示和构造测试，不把其行列数、画布或 Word 宽度当作所有任务的固定模板。 | [testing.md](testing.md) | 移入测试与示例说明 |
| references/structure-representation.md:48 | 几何与特殊表示（CDX）包含正确的 N–H 排布、苯乙炔、苯甲腈、甲基环丙烷、带楔线/虚线的 1-苯基乙醇及甲基碳为 13C 的甲苯。前两种线性三键片段检查 180°；小环按环内几何检查；立体中心复核… | [testing.md](testing.md) | 移入测试与示例说明 |
| references/structure-representation.md:50 | 一正一误的 N–H 对照（CDX）故意保留一个 90°/120°/150° 的错误 N，旁边为正确约 120° 的 N。该文件仅用于失败拦截测试，不能作为合格结构模板复用。全范围检查必须发现错误；只选… | [testing.md](testing.md) | 移入测试与示例说明 |
| references/structure-representation.md:54 | 仅在修改相关规则或明确测试技能时运行相应样例，不要求每次局部绘图任务重建整份测试稿。 | [testing.md](testing.md) | 移入测试与示例说明 |
| references/structure-representation.md:56 | 1. Me：检查真实甲基与原生缩写的连接；确认 CH2、末端烯/炔碳、氰基和带同位素的甲基不会被误改。保存后重开，核对缩写展开后的化学含义。 | [testing.md](testing.md) | 移入测试与示例说明 |
| references/structure-representation.md:57 | 2. 编号：分别核对有产率的 **43,** 70% 和无产率的 **43**。检查编号与逗号的实际字重、分隔空格、无产率时的标签末尾，以及同一化合物跨图复用编号。覆盖旧逗号、重复空格和既有字母后缀，… | [testing.md](testing.md) | 移入测试与示例说明 |
| references/structure-representation.md:58 | 3. 通式展开：逐条核对芳基连接位置、取代基、连接关系、编号和产率；信息不足的通式保持待确认，不猜测。 | [testing.md](testing.md) | 移入测试与示例说明 |
| references/structure-representation.md:59 | 4. 跨图显示：宽窄两个独立对象使用相同简单和复杂分子，按 显示尺度与校验 校准，检查同图内部及图间大小。 | [testing.md](testing.md) | 移入测试与示例说明 |
| references/structure-representation.md:60 | 5. 按 键角与二维几何 检查实际键角；本例通式及展开结构的三配位 N 使用约 120° 的二维三向排布，显式 N–H 也包括在内。检查相邻烯丙基折线，不能只改 N–H 而留下不协调的 N–C 方向。 | [testing.md](testing.md) | 移入测试与示例说明 |
| references/structure-representation.md:61 | 6. 将上述原生图保存重开，嵌入测试 Word；从最终 Word 逐个打开并读取原生内容，导出 PDF 逐页检查。记录实际测试文件的哈希、规则覆盖项、结果和未验证项。格式校验通过不等于这些行为通过；新… | [testing.md](testing.md) | 移入测试与示例说明 |
| references/word-display-and-qa.md:3 | 在跨图统一、定位大小差异、更新 OLE 缓存或说明尺寸变更时读取。本文件讲测量与易错点，不增加期刊视觉风格。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:7 | 画完的 ChemDraw 图粘贴或以 OLE 嵌入 Word 时，默认保留对象的原始插入宽高。插入时读取宽高和可读取的比例属性，保存并重开后复核。手动拖拽、设置“大小”面板、脚本写入宽高或缩放属性、复… | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:9 | 优先在可容纳原图的正文区域插入。发现自动适配页宽或单元格时，核对有效源宽高与最终实际比例，回到 ChemDraw 重排各行列和分区或调整放置位置，再按默认大小插入。按用户已明确的纸张、页边距和整图保留… | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:13 | 原生结构与最终页面分别验收。常规二维结构在 ChemDraw 内使用同一文档键长、普通 10 pt 标签；在 Word 中还要使用一致的实际显示尺度。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:15 | 以下公式用于测量现有对象和核对默认插入结果。在无变形且原始可见画布宽度已正确校准时： | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:18 | s = Word 显示宽度 / 原图有效宽度 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:19 | Word 键长 = 原生键长 × s | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:20 | Word 原子字号 = 原生字号 × s | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:21 | Word 显示高度 = 原图有效高度 × s | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:24 | 例如，审查旧稿时测得显示比例约 0.69，原生 14.4 pt 键长和 10 pt 标签在该页上分别约为 9.9 pt 和 6.9 pt。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:26 | 采用共同的 s 时，所有图的常规键长和字母才可同时接近。若两张原图的有效宽度不同，同一个 Word 显示宽度通常意味着不同 s。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:28 | 实际调用前应分清用户要统一的是原生设置、Word 实际显示，还是两者。涉及 Word 的常规绘图任务同时检查两者；单纯只读检查不构成修改授权。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:32 | - 记录最新源文件、哈希、图号、对应原生对象、Word 显示缓存和 Word 中实际宽高。不要误用旧预览或旧 CDX。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:33 | - 有透明边缘、留白、EMF 物理边界、图像裁剪或旋转时，不能只拿 CDX 的 page 宽度除以 Word 宽度。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:34 | - PNG 的 DPI/pHYs 仅在与原生几何和实际渲染相符时用于物理换算。ChemDraw 某些导出图的分辨率元数据与绘制比例可能不一致；矛盾未消除前不报告伪精确的字号或键长。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:35 | - 先用已知普通结构、原子字母或经过验证的矢量源校准对应关系，再对整个图批量测量。无法可靠校准时，给相同页面缩放下的相对比较，并注明估算性质。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:39 | 从当前 Word 使用的实际 EMF 读取 rclFrame、szlDevice、szlMillimeters 及绘图记录。跟踪字体和世界变换/映射设置；不要无条件假定每个 CDX 坐标都对应两个 E… | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:41 | 当记录已验证为常见设备坐标、没有额外映射时： | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:44 | frame_width_device = (frame.right - frame.left) / 100 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:45 |                      × device_width_px / device_width_mm | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:46 | Word_pt_per_device_x = Word_width_pt / frame_width_device | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:49 | 纵向同理。字体的逻辑高度须经过有效变换后再乘纵向显示比例。核对原生标签与 EMF 标签的位置、字号或匹配的几何，证明本次映射成立；有额外映射时必须计入。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:51 | 校准应允许一个经测量确认的整体平移项。实际缓存可能因像素对齐产生小量位置偏差；先用多个已知节点/键拟合横纵比例与平移，再检查残差。不能把整体平移误判为键变长，也不能直接套用上一次得到的倍数或偏移量。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:55 | 分辨率元数据经过校准后： | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:58 | native_width_pt = pixel_width × 72 / verified_dpi_x | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:59 | scale_x = Word_width_pt / native_width_pt | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:62 | 纵向同理。用源图里的已知几何/文字定位与最终页面渲染复核。不要把全部位图都假定为 600 dpi。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:66 | - 主要比较普通苯环、其他平面六元环或普通脂肪环中的同类 C–C 键，以及普通原子字母。三维簇、碳硼烷笼、透视投影、配位键、反应箭头、超长连接线与上下标不作为普通键长或字号的基准。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:67 | - 结构解析时跳过隐藏的缩写展开片段，避免重复计数。图形化簇顶点可能以默认碳节点存储；结合连接度、图例及图像识别投影核心，不能仅凭 Element=C 就当作普通环。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:68 | - 按图、分区、分子分别记录，不能只算全篇平均数。一个较大的模型结构可能掩盖同图中被缩小的复杂底物。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:69 | - 分子原子数不同，整体外接框大小本来就会不同。统一的是相同标准下的局部键长与普通文字，不是所有分子的占地面积。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:70 | - 同一比例下做页面对照；不能把每张截图自动放大到填满屏幕，再凭肉眼说其大小一致。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:71 | - 文档默认值与已绘对象的实际值分别读取。检查坐标算出的键长、实际文字片段使用的字体/字号，以及对象上的线宽等覆盖；不要只读取根节点的 BondLength、LabelSize 或一个平均字号。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:72 | - 键长、字号或化学价态检查通过，仍可能有不规范的二维键角。按 键角与二维几何 检查相关原子的全部相邻键，包含显式氢；无化学警告不能替代键角检查。Word 长宽比和横纵映射也须保持，以免角度在最终显示… | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:74 | 工程校验可把普通二维结构的显示差异尽量控制在约 5% 内，超过约 10% 时列出定位，超过约 15% 时优先处理。这是辅助阈值，不是用户另行规定的精确容差，也不替代视觉检查或科学投影判断。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:78 | ／ 任务或实际变化 ／ 尺寸检查范围 ／ | [SKILL.md](../SKILL.md) | 前移范围表，详细条件在原文件保留 |
| references/word-display-and-qa.md:80 | ／ 新绘、全篇标准化或明确要求跨图统一 ／ 所有目标图；同时比较图间和各图内部的结构 ／ | [SKILL.md](../SKILL.md) | 前移范围表，详细条件在原文件保留 |
| references/word-display-and-qa.md:81 | ／ 局部文字、编号、颜色或位置修改 ／ 修改对象；对其他对象核对内容、缓存和放置参数是否受到影响 ／ | [SKILL.md](../SKILL.md) | 前移范围表，详细条件在原文件保留 |
| references/word-display-and-qa.md:82 | ／ 有效边界、缓存映射、Word 宽高、裁剪或变换变化 ／ 重新校准所有受影响图，并与指定参考或已验证的同批结构比较 ／ | [SKILL.md](../SKILL.md) | 前移范围表，详细条件在原文件保留 |
| references/word-display-and-qa.md:83 | ／ 共享页设置、样式或全局布局变化 ／ 扩展至实际受到影响的对象与页面 ／ | [SKILL.md](../SKILL.md) | 前移范围表，详细条件在原文件保留 |
| references/word-display-and-qa.md:85 | 新增 Me、逗号、加粗或文字重排都可能改变可见边界。原生键长未变、Word 宽度未变，并不能单独证明显示比例未变；比较本次原生有效边界与缓存映射。存在变化或无法证明映射保持时，测量受影响图的最终键长和… | [SKILL.md](../SKILL.md) | 前移范围表，详细条件在原文件保留 |
| references/word-display-and-qa.md:87 | 局部任务中，未改对象若内容、缓存、宽高及裁剪/变换均未变，可以报告“本次未改变其显示”，不要求为了缺少旧测量记录而逐键重测全篇；也不能报告这些对象已符合统一标准。若无法证明未受影响，检查该对象。发现授… | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:89 | 检查范围缩小不取消交付验收：从最终 Word 打开修改对象，核对原生内容；导出最终 PDF，逐页查看整体显示和分页。局部内容检查与整份文档的页面检查分开记录。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:93 | 1. 确认当次适用的原生文档样式、默认键长和字号。只有新绘或已获准原生标准化时，才将不合格的普通结构按基线规范化；仅调整 Word 显示大小时保留合格的原生几何，报告授权范围外的原生异常。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:94 | 2. 选定已经规范的普通结构作为测量参照。源图自身不一致时，先识别局部异常，再选基准。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:95 | 3. 在原生图内调整位置、单元宽度、行列、条件文字与分区，保持分子的键和标签作为整体；不要在“排版”步骤中又单独缩放结构。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:96 | 4. 若需要所有图在 Word 中同宽，规划共同的有效画布宽度，并通过有用的内容排布填充空间。画布扩展是布局选择，不是无条件推荐的唯一方法。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:97 | 5. 让每张新图以自身的默认插入尺寸进入 Word。记录插入时的宽高，保存并重开后复核。纸张和边距遵循用户要求，重新导出 PDF 验证。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:99 | 原生标准化与排版平移要分开说明：前者可能确实改变旧图里不规范的原生键长；后者不应改变已规范分子的相对坐标。不能不分情况保证“所有任务都绝不改原生尺寸”。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:103 | 同一版源图的原始长宽比 r 与 Word 中 H/W 应一致，允许单位换算和舍入误差。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:105 | 原生重排可以改变图幅和原始长宽比。复核时用当前这一版原图比较，分别核对默认插入宽高、保存后的宽高和显示映射。长宽比一致仍可能存在等比缩放。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:107 | 如实记录三件事： | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:109 | - 原生键长或字体是否改变；若仅平移，检验键向量与字号保持。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:110 | - 原生画布、分区和位置是否改变。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:111 | - 每个对象默认插入时与保存后的 Word 宽高，以及实测显示比例和长宽比。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:115 | - 原生 CDX/CDXML 中应有真实原子和键，不把光栅截图包装为整幅“可编辑结构”。Word 对象类型、原生内容与当前缓存都要核对。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:116 | - 化学标注可能同时存在于 CDX 的 0x0700/0x0709 文字记录；编辑时避免只改一套。复制对象后保证非零对象 ID 唯一，保留正确引用。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:117 | - ChemDraw 原生保存可能展开 CF3、OMe 等隐藏缩写、重排内部对象或平移页面原点。验证科学含义和相对几何，不因内部计数或整体原点变化就误报结构变化，也不借此放过真实的连接或键级错误。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:118 | - 将裸露甲基改为原生 Me，或将通式加取代基列表展开为独立底物时，图元/节点计数可以变化。按 甲基缩写与底物展开规则 比较缩写展开后的化学含义，并逐一核对底物、取代位置、编号和产率，不能只以原始对象… | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:119 | - 保持实验数值、谱线、编号和反应条件，检查缺字、重叠、化学上下标。新警告须调查；旧警告若本次未处理，不能宣称已全部消除。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:120 | - 按 编号规则 核对标签和编号映射。有产率时检查加粗编号、加粗逗号、一个半角空格及原产率。无产率时核对标签仅为加粗编号。同一化合物跨图复用编号，重复规范化应保持已合格的标签原样。 | [structure-representation.md](structure-representation.md)；[native-authoring-pitfalls.md](native-authoring-pitfalls.md) | 完整规范单源；实测行为仍放易错点 |
| references/word-display-and-qa.md:121 | - 跨图复制时按实际颜色值和语义映射，不直接沿用颜色索引；不同 CDX/CDXML 的同一索引可能指向不同颜色。模板内有某种颜色不等于要求使用它。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:122 | - 对未改动页面，条件允许时做像素比较或其他可靠对照，避免局部修改带动其他页变化。缓存检查、结构检查、原生打开检查、页面可视检查是不同的证据，不互相替代。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:126 | 1. 保存并重开最终 Word。对每个验收范围内的对象，先在普通页面视图查看预览，再从 Word 双击打开对应的 ChemDraw 对象，核对所见原生内容。检查结构与键级、箭头形状和方向、编号与产率、… | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:127 | 2. 比较前统一观察比例，区分显示粗细、抗锯齿等渲染差异与实质差异。发现旧版内容、缺字、箭头变形或裁剪时，核对原生版本和预览边界，用同一版已核实的原图刷新预览；必要时按默认尺寸重新嵌入，或按本次明确指… | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:128 | 3. 修正后保存并再次重开 Word，复查受影响对象的页面预览与双击视图，并从这一版 Word 重新导出 PDF 核对。按图记录双击打开结果、两种视图是否一致，以及待核实的差异。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:132 | 跨图统一或大小审查时，在任务工作目录保留一份简短记录，格式可为表格或 JSON；最终回复只概括有用的结果。记录内容包括： | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:134 | ／ 层面 ／ 需要保留的证据 ／ | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:136 | ／ 身份和范围 ／ 源文件版本/哈希、图号及对象对应关系、允许修改的范围 ／ | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:137 | ／ 原生实际值 ／ 代表性普通结构的键长范围、普通文字实际字体/字号、局部异常；不能仅记文档默认值 ／ | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:138 | ／ 最终显示 ／ 默认插入和保存重开时的 Word 宽高、已校准有效源宽高、横纵比例、参考对象、最终键长/字号或注明为估算的相对比较 ／ | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:139 | ／ 内容与操作 ／ 结构/数值核对结果、原生几何是否变动、画布或布局是否变动、Word 尺寸是否变动 ／ | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:140 | ／ 交付验证 ／ 最终 Word 中原生对象的打开结果、页面预览与双击视图的一致性、对应 PDF 的页面视觉检查、具体例外或待验证项 ／ | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:142 | 尺寸数值使用明确单位；证据状态分为已验证、发现问题、未验证。比例或校准来源不可靠时保留未验证状态，不能用填入精确小数来代替校准。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:144 | 局部修改且已有可靠基线时，可以通过未改图的原生内容、缓存、Word 尺寸及裁剪/变换信息未变来复用其测量记录，再检查最终页面。不能仅凭文件名相同、对象编号相同或图片看起来相近就复用。若原生保存只改变内… | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:146 | 没有旧记录时，按上文“按影响确定检查范围”判断哪些对象需要测量；“未变化”和“已符合基线”是不同结论。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:150 | 检验技能或明确进行跨图测试时，安排多个独立 ChemDraw 对象，选取网格、横条、窄幅或分区等不同布局，并让至少两图的有效源宽度明显不同。重复放入同一个简单结构和一个展开的复杂结构作为参照；这是测试… | [testing.md](testing.md) | 移入测试说明 |
| references/word-display-and-qa.md:152 | - 分别测量每个对象的原生实际键长与字体、当前 Word 尺寸、当前缓存映射及最终显示值，不能把整份 Word 只记一个缩放倍数。 | [testing.md](testing.md) | 移入测试说明 |
| references/word-display-and-qa.md:153 | - 逐图保留各自的默认插入宽高。若用户要求整图同宽，先在原生图中重排有效内容，再按默认尺寸嵌入并复核实测宽度。 | [testing.md](testing.md) | 移入测试说明 |
| references/word-display-and-qa.md:154 | - 同时比较跨图中位数和同图内各分子的差异，保留最大/最小值和参照结构的结果；不得只报全篇平均值。 | [testing.md](testing.md) | 移入测试说明 |
| references/word-display-and-qa.md:155 | - 从最终 Word 逐个打开测试对象，并导出原生内容核对。逐页查看实际 Word PDF，以相同页面缩放比较参照结构。 | [testing.md](testing.md) | 移入测试说明 |
| references/word-display-and-qa.md:156 | - 只做了单幅合图时，报告为单图验证；不得宣称已验证多个独立图之间的显示一致性。 | [testing.md](testing.md) | 移入测试说明 |
| references/word-display-and-qa.md:160 | 使用当前环境提供的文档、PDF、原生应用能力，避免将临时项目路径当成永久依赖。应用控制串行执行，释放任务对象；保留源文件。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| references/word-display-and-qa.md:162 | Word 图稿默认配套 PDF；独立原生图和只读审查按其实际请求交付。需要列出例外时具体说明是哪些谱图、位图文字或自动下标，不将局部例外夸大为全部分子无需规范化。检查未完成时指出缺少的证据，不能用“可… | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| SKILL.md:2 | name: chemdraw-word-standard | [SKILL.md](../SKILL.md) | 保留含义 |
| SKILL.md:3 | description: "Draw, normalize, or audit editable ChemDraw structures and their placement in Word usi… | [SKILL.md](../SKILL.md) | 保留含义 |
| SKILL.md:8 | 这是一套化学图的底层制作要求。服务于结构准确、原生标准一致、Word 最终显示一致和可编辑交付，不规定图必须像某本期刊。 | [SKILL.md](../SKILL.md) | 保留含义 |
| SKILL.md:10 | 当次用户明确要求优先。只审查时不改文件；局部返修不自动扩展成全篇重画。基于用户最新指定或刚交付的正确版本操作，保留原件。 | [SKILL.md](../SKILL.md) | 保留含义 |
| SKILL.md:12 | 新绘或明确要求原生标准化时应用下述基线。只调整排版时，保留已经合格的原生键长、字号和化学结构。按当次授权处理原生异常。用户明确要求调整已有 Word 对象的大小时，才按指定尺寸或比例处理对应对象。 | [SKILL.md](../SKILL.md) | 保留含义 |
| SKILL.md:16 | ／ 项目 ／ 本用户的默认要求 ／ | [baseline.md](baseline.md) | 保留含义 |
| SKILL.md:18 | ／ 普通二维结构的默认 C–C 键长 ／ 采用同一 ChemDraw 默认文档样式；当前工作基线为 **14.40 pt（0.20 in）** ／ | [baseline.md](baseline.md) | 保留含义 |
| SKILL.md:19 | ／ 线宽、双键间距等 ／ 跟随同一默认样式，具体值见基础模板（普通线宽 **0.60 pt**）；不另造“期刊参数”，不混用多个文档设置 ／ | [baseline.md](baseline.md) | 保留含义 |
| SKILL.md:20 | ／ 普通原子标签、基团缩写、反应条件 ／ 未另行指定时用 **Arial，原生 10 pt** ／ | [baseline.md](baseline.md) | 保留含义 |
| SKILL.md:21 | ／ 化合物编号 ／ **Arial，原生 10 pt，黑色，加粗**。有产率时，编号后接加粗的英文逗号、一个半角空格及产率，如 **43,** 70%。无产率时只写加粗编号，如 **43**。不加深蓝… | [structure-representation.md](structure-representation.md) | 保留含义 |
| SKILL.md:22 | ／ 自动化学下标、上标、电荷、同位素 ／ 保留正确的化学排印规则；自动小字号不算普通字体不统一 ／ | [baseline.md](baseline.md) | 保留含义 |
| SKILL.md:24 | 可从 CDXML 基础模板 或 原生 CDX 基础模板 开始新图。模板来自本用户已接受文档的原生设置；14.40 pt 是此工作基线，不宣称所有 ChemDraw 版本或所有预设的出厂值都相同。用户指… | [baseline.md](baseline.md) | 保留含义 |
| SKILL.md:26 | - 同一基线贯穿所有普通分子，包括苯环和膦试剂。复杂分子通过更宽单元、换行、调整位置等方式排布，不单独缩小某个分子或拉长部分键以塞进格子。 | [baseline.md](baseline.md) | 保留含义 |
| SKILL.md:27 | - 普通二维结构同时检查键角和键方向：沿用常规折线、芳环及官能团的布局，显式 N–H 等键也须纳入检查，不能为对齐而随手竖画或横画。按 键角与二维几何 区分常规二维排布与真实立体投影；不将所有原子、环… | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| SKILL.md:28 | - 键角验收先列出本次范围内的候选中心，逐项记录通过、问题或待复核；特殊结构需写明复核依据。局部测量通过不能代表整图通过，尚有漏项或无效坐标时不作完整通过结论。检查工具只读，不自动整理结构；操作与结果… | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| SKILL.md:29 | - 裸露的甲基统一明确显示为 **Me**，包括原先仅用末端短线表示的甲基；使用 ChemDraw 可识别的原生甲基缩写，字体沿用 Arial 10 pt。按真实原子环境识别甲基，不能把亚甲基、末端烯… | [structure-representation.md](structure-representation.md) | 保留含义 |
| SKILL.md:30 | - 核对节点坐标形成的实际键长和键角、文字片段字号及局部样式覆盖。只把文档默认 BondLength 或 LabelSize 改成目标值，不足以证明已有分子和文字已经规范。 | [bond-geometry.md](bond-geometry.md) | 保留含义 |
| SKILL.md:31 | - 同一编号体系中，同一化合物在不同图、表和段落中使用同一编号，是否显示产率只影响标注格式。保留已确认的原编号及其字母后缀。具体规则与例子见 结构表示与编号。 | [structure-representation.md](structure-representation.md) | 保留含义 |
| SKILL.md:32 | - 名称、编号、图题等非化学说明文字按普通文本处理，避免误触发化学解析警告；不能为此关闭真实原子标签的化学解释。 | [baseline.md](baseline.md) | 保留含义 |
| SKILL.md:33 | - 膦相关结构的键、括号、重复次数与编号要成组布局；只移动整个结构时，保留其相对坐标、键长及原生字号。 | [baseline.md](baseline.md) | 保留含义 |
| SKILL.md:34 | - 金属簇、碳硼烷、透视构型及立体投影按其科学含义绘制；不把投影中的每条线强制拉成普通二维默认键长。 | [baseline.md](baseline.md) | 保留含义 |
| SKILL.md:35 | - 保留连接关系、键级、立体标记、电荷、同位素、取代基、编号、反应物、条件和产率。遇到源图矛盾，明确指出，不凭外观猜改化学含义。 | [baseline.md](baseline.md) | 保留含义 |
| SKILL.md:36 | - 保留用户要求展开的苯环等结构，保留已指定的语义颜色（如本项目的紫色反应标记和氢）。这些是已有图的约束，不要求每张新图都添加同样的标记。不给所有元素套新颜色，不把色板排列顺序当作颜色优先级。 | [layout.md](layout.md) | 仅删除项目专属紫色例举；保留语义颜色、颜色映射和指定展开的通用约束 |
| SKILL.md:40 | **将画完的 ChemDraw 图粘贴或嵌入 Word 时，保持该图的默认插入宽高。** 手动粘贴和脚本插入都适用。默认保留原生对象的插入尺寸，避免为适配正文、栏宽或占位框而缩放。不要拖动改变大小，不… | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| SKILL.md:42 | 1. 先统一同批图的原生键长与字号，在 ChemDraw 中排好各分区、行列及留白，使有效图幅适合正文。装不下时回到 ChemDraw 重排内容，保留单个分子的键长与字号。仍放不下时说明页面约束，按已… | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| SKILL.md:43 | 2. 插入时记录对象的默认宽高。保存并重开 Word 后复核宽高、缩放和长宽比。若 Word 在粘贴时因页宽、栏宽或表格单元格而自动缩放，改用容纳原始尺寸的放置位置，或调整原生排版后重新插入。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| SKILL.md:44 | 3. 核对同类 C–C 键与普通标签在最终页面上的实际显示大小。图幅不同的图可以各自保留不同的默认宽高。原生 **10 pt** 与 Word 实测字号分别记录。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| SKILL.md:46 | 涉及多图比较、显示尺度计算或异常图定位时，读 显示尺度与校验。 | [word-display-and-qa.md](word-display-and-qa.md) | 保留含义 |
| SKILL.md:50 | - 新文档默认 A4 竖向、正常页边距（2.54 cm）；修改已有文档先保留现有页设置，除非用户要求调整。不能为了塞下图而擅自缩小边距。 | [layout.md](layout.md) | 保留含义 |
| SKILL.md:51 | - 新建测试稿或普通图稿的标题不自动加横线；检查模板继承的段落边框和主题字体，确保实际显示符合设定。返修现有图时只按授权处理标题样式。 | [layout.md](layout.md) | 保留含义 |
| SKILL.md:52 | - 对齐行列、分区边界、编号与产率基线；用一致的列中心和标签位置安排间距，分子、所属标记及说明一起移动。圆标中的文字按实际字形视觉居中。间距紧凑但不相互挤压，不给所有任务预设固定三行、五行或某种底物表… | [layout.md](layout.md) | 保留含义 |
| SKILL.md:53 | - 排底物拓展时，允许为整齐紧凑将“通式结构 + Ar/R 取代基列表”展开为“各底物的独立完整结构 + 对应编号和产率”。这项表达形式调整已获用户授权；逐个保留取代位置、连接关系及数据，不把示例图中… | [structure-representation.md](structure-representation.md) | 保留含义 |
| SKILL.md:54 | - 不为“统一风格”删除分子、谱图、雷达图、敏感性实验、图例或其他原有元素。数据图保持原始数据及标注语义，不凭形状重造实验数据。 | [layout.md](layout.md) | 保留含义 |
| SKILL.md:55 | - 不默认拆分完整图片。先尝试有效重排；确有纸张、字号、内容量之间的冲突时，说明具体冲突并依据已有授权处理，必要时再询问取舍。已明确授权的排版选择不重复确认。 | [layout.md](layout.md) | 保留含义 |
| SKILL.md:56 | - 不自动调用 nature-*、Science 或其他期刊风格技能，不内置其配色、标题样式或版式。期刊风格要求不属于本技能的默认规则。 | [layout.md](layout.md) | 保留含义 |
| SKILL.md:60 | - 分子必须是可编辑的真实原子、键与文字。整幅位图放进 CDX 或 OLE 外壳不算原生化学结构；原有光谱等确需保留的位图另列例外。 | [native-workflow.md](native-workflow.md) | 保留含义 |
| SKILL.md:61 | - Word 用真实、嵌入式 ChemDraw OLE 对象，并同步更新其显示缓存；不能依赖本机某个外部文件路径才能编辑。原生内容与 Word 所见必须来自同一版，不能只改预览图。 | [native-workflow.md](native-workflow.md) | 保留含义 |
| SKILL.md:62 | - 原生保存后核对目标文件存在、格式有效且能重开，再进行嵌入；应用调用无报错不等于文件已生成。遇到中文路径兼容问题时，可用本次任务的 ASCII 临时路径保存并验证，再复制为用户需要的文件名。 | [native-workflow.md](native-workflow.md) | 保留含义 |
| SKILL.md:63 | - 按实际影响验收：新绘或全篇统一检查全部目标图；局部返修检查修改对象，并确认其他对象未受影响。新增 Me、逗号或加粗也可能改变有效边界，须据此决定是否重新校准显示比例。未改图缺少旧测量不强制触发全篇… | [SKILL.md](../SKILL.md) | 保留含义 |
| SKILL.md:64 | - 制作或修改 Word 图稿时，保存并重开最终 Word，先看页面上的预览，再双击打开每个验收范围内的对象，按 Word 预览与原生图一致性 逐项对照。再从最终 Word 导出 PDF，逐页检查显示… | [native-workflow.md](native-workflow.md) | 保留含义 |
| SKILL.md:65 | - 控制本机 Word/ChemDraw 时串行操作任务文件，关闭并释放自己打开的对象，不关闭用户其他文档。使用当前环境已有的文档、PDF、原生应用工具或相应技能，不依赖某个旧项目的临时脚本路径。 | [native-workflow.md](native-workflow.md) | 保留含义 |
| SKILL.md:66 | - Word 图稿交付默认同时给 **可编辑 Word 与对应 PDF**，保留原生 CDX/CDXML 源文件。用户只要独立 ChemDraw 文件时交付原生文件，不强制增做 Word；只读审查交付… | [native-workflow.md](native-workflow.md) | 保留含义 |
| SKILL.md:67 | - 简短说明改了什么、默认键长/原生字号、Word 显示比例是否调整、是否完成原生打开及 PDF 检查。不能把“没有手动拖拽”说成“Word 显示尺寸完全没变”。 | [native-workflow.md](native-workflow.md) | 保留含义 |
| SKILL.md:69 | 首次组装原生 Word 图稿、遇到保存/锁定/警告问题，或检验技能本身时，读 原生制作的实测易错点。多图一致性测试须使用多个独立嵌入对象和不同有效宽度，不能用同一幅合图内部的等大代替跨图验证。 | [native-workflow.md](native-workflow.md) | 保留含义 |
| SKILL.md:71 | 涉及甲基、编号或底物通式展开时，读 结构表示与编号。检验或修改这些规则时，使用其中自带的原生例子及测试要求；旧版通过的检查不能自动证明新增规则通过。 | [native-workflow.md](native-workflow.md) | 保留含义 |
